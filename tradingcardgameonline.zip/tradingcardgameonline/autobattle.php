<?php
/**
 * Created by Bryant Frankford
 * nathanielfrankford@gmail.com
 * Date: 2/3/24
 * Time: 11:00 PM
 * To change this template use File | Settings | File Templates.
 */
if ($_SERVER["HTTPS"] != "on") {
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

if (!isset($_SESSION['login_info'])) {
    header("Location: index.php");
    die();
}

?>

<html>

<head>
    <title>Card Clash</title>
    <script src="js/jquery.js"></script>
    <script src="js/autobattle.js"></script>

    <link rel="stylesheet" type="text/css" href="css/autobattle.css">
    <link rel="stylesheet" href="css/card.css">
    <link rel="stylesheet" href="css/fontawesome-free-6.5.1-web/css/all.css">
    <script src="css/fontawesome-free-6.5.1-web/js/fontawesome.js"></script>

    <link rel="icon" type="image/png" href="images/favicon.png" />
</head>

<body>
<div class='left-cards-container displayCards'></div>
<?php
include 'db.php';
include 'abilities.php'; // Include the file containing the applyAbilities function

try {
    // Get the attacker's owner_id
    $attackerOwnerId = $_SESSION['login_info'][0]['id'];

    // SQL statement to select a random row from the trading_cards table excluding cards owned by the attacker
    $sql = "SELECT id FROM trading_cards WHERE owner_id != ? and isDust = 0 ORDER BY RAND() LIMIT 1";

    // Prepare the statement
    $stmt = $dbo->prepare($sql);

    // Bind the attacker's owner_id parameter
    $stmt->bindParam(1, $attackerOwnerId, PDO::PARAM_INT);

    // Execute the prepared statement
    $stmt->execute();

    // Fetch the result
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Check if any row was returned
    if (count($result) > 0) {
        // Extract the id from the result
        $randomId = $result[0]['id'];

        // Output the id
        $defenderId = $randomId;
    } else {
        echo "No rows found in the trading_cards table.";
    }
} catch (PDOException $e) {
    // Handle database errors
    echo 'Error: ' . $e->getMessage();
}

$attackerId = $_POST['card_id']; // Example ID, replace it with the actual ID of the attacker card

// Function to check if the card_id has been used 5 times within the last 24 hours
function checkCardUsage($cardId)
{
    global $dbo;
    try {
        // Define the SQL query to count the occurrences of the card_id within the last 24 hours
        $sql = "SELECT COUNT(*) AS total_usage FROM card_usage WHERE card_id = ? AND battle_timestamp >= NOW() - INTERVAL 1 DAY";

        // Prepare the statement
        $stmt = $dbo->prepare($sql);

        // Bind the parameter value
        $stmt->bindParam(1, $cardId, PDO::PARAM_INT);

        // Execute the query
        $stmt->execute();

        // Fetch the result
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if the card has been used 5 times within the last 24 hours
        if ($row && $row['total_usage'] >= 5) {
            return true; // Card has been used 5 times within the last 24 hours
        } else {
            return false; // Card has not been used 5 times within the last 24 hours
        }
    } catch (PDOException $e) {
        // Handle any errors that occur during the query execution
        echo "Error: " . $e->getMessage();
        return false; // Failed to execute query
    }
}

if(isset($_POST['card_id'])) {
    $attackerId = $_POST['card_id'];
    $result = checkCardUsage($attackerId);

} else {
    // Provide a default value or handle the situation differently
    echo '<div class="resubmit">Please go back and resubmit.</div>';
    die();
}

if ($result) {
    echo '<p><span class="fiveTimes">This card has clashed 5 times within the last 24 hours and needs to recharge.</span> <a class="homeButton" href="dashboard.php">Return Home</a> <a class="homeButton" href="cardClash.php">Return To Clashboard</a></p>';
    die();
} else {
    //    echo "The card has not been used 5 times within the last 24 hours.";
}

// Prepare and execute a parameterized query to retrieve the attacker's attributes
$statement = $dbo->prepare("SELECT * FROM trading_cards WHERE id = ?");
$statement->execute([$attackerId]);

// Fetch the attacker's attributes as an associative array
$attackerAttributes = $statement->fetch(PDO::FETCH_ASSOC);

// Close the statement
$statement->closeCursor();

// Create the attacker object
$attacker = array(
    'name' => $attackerAttributes['name'], // Add the attacker's name
    'hp' => $attackerAttributes['hp'] * $attackerAttributes['level'], // Increase HP based on level
    'attack_strength' => $attackerAttributes['attack_strength'],
    'level' => $attackerAttributes['level'],
    'ability1' => $attackerAttributes['ability1'],
    'ability2' => $attackerAttributes['ability2'],
    'owner_id' => $attackerAttributes['owner_id'],
    'experience' => $attackerAttributes['experience'],
    'id' => $attackerAttributes['id']
);

// Prepare and execute a parameterized query to retrieve the defender's attributes
$statement = $dbo->prepare("SELECT * FROM trading_cards WHERE id = ?");
$statement->execute([$defenderId]);

// Fetch the defender's attributes as an associative array
$defenderAttributes = $statement->fetch(PDO::FETCH_ASSOC);

// Close the statement
$statement->closeCursor();

// Create the defender object
$defender = array(
    'name' => $defenderAttributes['name'], // Add the defender's name
    'hp' => $defenderAttributes['hp'] * $defenderAttributes['level'], // Increase HP based on level
    'attack_strength' => $defenderAttributes['attack_strength'],
    'level' => $defenderAttributes['level'],
    'ability1' => $defenderAttributes['ability1'],
    'ability2' => $defenderAttributes['ability2'],
    'owner_id' => $defenderAttributes['owner_id'],
    'experience' => $defenderAttributes['experience'],
    'id' => $defenderAttributes['id']
);

// Random dice roll to determine who goes first
$attackerRoll = mt_rand(1, 6);
$defenderRoll = mt_rand(1, 6);

// Check if any card has the "Shadow" ability
$attackerShadow = ($attacker['ability1'] === 'Shadow' || $attacker['ability2'] === 'Shadow');
$defenderShadow = ($defender['ability1'] === 'Shadow' || $defender['ability2'] === 'Shadow');

// Determine who goes first based on abilities or random roll
if ($attackerShadow && !$defenderShadow) {
    $firstCard = 'attacker';
} elseif (!$attackerShadow && $defenderShadow) {
    $firstCard = 'defender';
} else {
    // Compare initiative rolls to determine the first attacker
    $firstCard = ($attackerRoll > $defenderRoll) ? 'attacker' : 'defender';
    // If initiative rolls are equal, choose randomly
    if ($attackerRoll === $defenderRoll) {
        $firstCard = (mt_rand(0, 1) === 0) ? 'attacker' : 'defender';
    }
}

// Define the function to calculate the battle outcome
function calculateBattleOutcome($firstCard, $attacker1, $defender1, $attackerRoll, $defenderRoll)
{
    // Create separate copies of the attacker and defender objects
    $attacker = array_merge([], $attacker1);
    $defender = array_merge([], $defender1);

    // Determine the order of attack based on initiative rolls
    if ($attackerRoll > $defenderRoll || ($attackerRoll === $defenderRoll && mt_rand(0, 1) === 0)) {
        $attackingCard = $attacker1;
        $defendingCard = $defender1;
    } else {
        $attackingCard = $defender1;
        $defendingCard = $attacker1;
    }


    // Initialize variables for attacker and defender attributes
    $attackerHP = $attackingCard['hp'];
    $defenderHP = $defendingCard['hp'];
    $round = 1;

    // Define ability order
    $abilityOrder = ['ability1', 'ability2']; // Updated ability order

    // Display initial initiative rolls
    echo '<h3 class="initiative">' . $attacker1['name'] . ' Initiative: ' . $attackerRoll . '</h3>';
    echo '<h3 class="initiative">' . $defender1['name'] . ' Initiative: ' . $defenderRoll . '</h3>';

    // Loop until one of the cards is out of HP
    while ($attackerHP > 0 && $defenderHP > 0) {
        // Display round number
        echo '<p class="round-number">Round ' . $round . '</p>';
        echo '<div class="abilityUse">';

        // Apply abilities for the attacker and defender before each attack if both have HP greater than 0
        $attacker['attack_modifier'] = 1;
        if ($attackerHP > 0 && $defenderHP > 0) {
            applyAbilities($attackingCard, $defendingCard, $abilityOrder);
        }

        // Apply attack from the attacker to the defender only if the attacker didn't dodge
        if (!$attackingCard['dodged_attack']) {
            $randomFloat = mt_rand(50, 100) / 100; // Generates a random number between 0 and 1 with up to two decimal places

            $damage = $attackingCard['attack_strength'] * ceil($attackingCard['level']*$randomFloat);
            $damage = ceil($damage);
            $defenderHP -= ceil($damage);

            $displayDamage = ceil($damage);

            $displayFloat = $randomFloat * 100;

            // Output attack and defender's HP
            echo "<p class='attack-description'><span class='attacker-name'>{$attackingCard['name']}</span> physically attacks <span class='defender-name'>{$defendingCard['name']}</span> for <span class='damage'>$displayDamage</span> ($displayFloat% Effort) damage.</p>";
            echo "<p class='defender-hp'><span class='defender-name'>{$defendingCard['name']}'s</span> HP after attack: <span class='hp'>$defenderHP</span></p>";
        } else {
            // Output message indicating that the attacker dodged the attack
            echo "<p class='attack-description'><span class='attacker-name'>{$attackingCard['name']}</span> prevented the attack!</p>";
            // Reset the dodged_attack flag for the next round
            $attackingCard['dodged_attack'] = false;
        }

        // Apply abilities for the attacker and defender before each attack if both have HP greater than 0
        if ($attackerHP > 0 && $defenderHP > 0) {
            applyAbilities($defendingCard, $attackingCard, $abilityOrder);
        }

        // Apply attack from the defender to the attacker only if the defender didn't dodge
        if (!$defendingCard['dodged_attack']) {
            $randomFloat = mt_rand(50, 100) / 100; // Generates a random number between 0 and 1 with up to two decimal places

            $damage = $defendingCard['attack_strength'] * ceil($defendingCard['level']*$randomFloat);
            $attackerHP -= ceil($damage);

            $displayFloat = $randomFloat * 100;

            // Ensure attacker's HP doesn't go negative
            if ($attackerHP < 0) {
                $attackerHP = 0;
            }

            $displayDamage = ceil($damage);

            // Output attack and attacker's HP
            echo "<p class='attack-description'><span class='attacker-name'>{$defendingCard['name']}</span> physically attacks <span class='defender-name'>{$attackingCard['name']}</span> for <span class='damage'>$displayDamage</span> ($displayFloat% Effort) damage.</p>";
            echo "<p class='attacker-hp'><span class='attacker-name'>{$attackingCard['name']}'s</span> HP after attack: <span class='hp'>$attackerHP</span></p>";
        } else {
            // Output message indicating that the defender dodged the attack
            echo "<p class='attack-description'><span class='defender-name'>{$defendingCard['name']}</span> prevented the attack!</p>";
            // Reset the dodged_attack flag for the next round
            $defendingCard['dodged_attack'] = false;
        }

        // Increment round counter
        $round++;

        if ($attackerHP > 0 && $defenderHP <= 0) {
            $winner = $attackingCard;
        } else if ($attackerHP <= 0 && $defenderHP > 0) {
            $winner = $defendingCard;
        }

        echo "</div>";
    }

    // Update experience only if there is a definite winner
    if ($winner) {
        echo "<p class='winner'>Winner: <span class='winner-name'>" . $winner['name'] . "</span></p>";
        $winnerId = $winner['id'];
        $ownerId = $winner['owner_id'];

        // Update experience for the appropriate card
        updateExperience($winnerId);
        updateDust($ownerId);
    } else {
        echo "<p class='winner'>No winner</p>";
    }

    echo '<p><a href="#" class="homeButton" onclick="window.location.reload();">Refresh Page</a><a class="homeButton" href="dashboard.php">Return Home</a></p>';

    return $winner;
}

function updateDust($userId)
{
    global $dbo;
    try {
        // Define the SQL statement to update the experience of the card by 1
        $sql = "UPDATE users SET dust = dust + 3 WHERE id = ?";

        // Prepare the statement
        $stmt = $dbo->prepare($sql);

        // Bind the parameter value
        $stmt->bindParam(1, $userId, PDO::PARAM_INT);

        // Execute the query
        $stmt->execute();

        // Check if the query was successful
        if ($stmt->rowCount() > 0) {
            return true; // Experience updated successfully
        } else {
            return false; // Failed to update experience
        }
    } catch (PDOException $e) {
        // Handle any errors that occur during the query execution
        echo "Error: " . $e->getMessage();
        return false; // Failed to update experience
    }
}

// Function to update the experience of a card by 1
function updateExperience($cardId)
{
    global $dbo;
    try {
        // Define the SQL statement to update the experience of the card by 1
        $sql = "UPDATE trading_cards SET experience = experience + 1 WHERE id = ?";

        // Prepare the statement
        $stmt = $dbo->prepare($sql);

        // Bind the parameter value
        $stmt->bindParam(1, $cardId, PDO::PARAM_INT);

        // Execute the query
        $stmt->execute();

        // Check if the query was successful
        if ($stmt->rowCount() > 0) {
            return true; // Experience updated successfully
        } else {
            return false; // Failed to update experience
        }
    } catch (PDOException $e) {
        // Handle any errors that occur during the query execution
        echo "Error: " . $e->getMessage();
        return false; // Failed to update experience
    }
}

// Function to insert a new row into the card_usage table
function insertCardUsage($cardId)
{
    global $dbo;
    try {
        // Prepare the SQL statement with placeholders for parameters
        $sql = "INSERT INTO card_usage (card_id) VALUES (?)";

        // Prepare the statement
        $stmt = $dbo->prepare($sql);

        // Bind the parameter values
        $stmt->bindParam(1, $cardId, PDO::PARAM_INT);

        // Execute the query
        $stmt->execute();

        // Check if the query was successful
        if ($stmt->rowCount() > 0) {
            return true; // Row inserted successfully
        } else {
            return false; // Failed to insert row
        }
    } catch (PDOException $e) {
        // Handle any errors that occur during the query execution
        echo "Error: " . $e->getMessage();
        return false; // Failed to insert row
    }
}

// Calculate battle outcome
$winner = calculateBattleOutcome($firstCard, $attacker, $defender, $defenderRoll, $attackerRoll);

// Example usage:
$cardId = $attackerId; // Replace with the actual card ID
$result = insertCardUsage($cardId);

if ($result) {
    //    echo "Row inserted successfully!";
} else {
    //    echo "Failed to insert row.";
}

?>
<div class="displayNone" id="attackerDetails" data-id="<?php echo $attackerId; ?>"></div>
<div class="displayNone" id="defenderDetails" data-id="<?php echo $defenderId; ?>"></div>
</body>

</html>
