<?php
/**
 * Created by Bryant N Frankford
 * nathanielfrankford@gmail.com
 */

if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

?>
<html>
<head>
    <title>Register Account</title>
    <link rel="stylesheet" href="css/register.css"/>

    <link rel="icon" type="image/png" href="images/favicon.png" />
</head>
<body>
<form class="registerAccountForm" method="post" action="attemptRegister.php">
    <table class="registerTable">
        <tr>
            <td><label for="emailAddress">Email</label></td>
            <td><input id="emailAddress" name="emailAddress" type="email" autofocus required="required" /></td>
        </tr>
        <tr>
            <td><label for="userPassword">Password</label></td>
            <td><input id="userPassword" name="userPassword" type="password" required="required" /></td>
        </tr>
        <tr>
            <td><label for="confirmPassword">Confirm Password</label></td>
            <td><input id="confirmPassword" name="confirmPassword" type="password" required="required" /></td>
        </tr>
        <tr>
            <td><label for="firstName">Username</label></td>
            <td><input id="userName" name="userName" type="text" required="required" /></td>
        </tr>
        <tr>
            <td><input id="swearTo" type="checkbox" required="required" /></td>
            <td class="registerSwear"><label for="swearTo">I swear to do nothing evil or illegal. I also agree to receive emails about my account when appropriate.</label></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit" /> <input type="button" onclick="location.href='index.php'" value="Cancel" /></td>
        </tr>
    </table>
</form>
</body>
</html>