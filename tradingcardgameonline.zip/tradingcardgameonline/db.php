<?php
//if($_SERVER["HTTPS"] != "on")
//{
//    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
//    exit();
//}

//if(!isset($_SESSION['id'])){
//	header("Location:index.php");
//}

/**
 * Created by Bryant N Frankford
 * nathanielfrankford@gmail.com
 */

//$host_name = "localhost";
//$database = "ijteuute_tradingcardgameonline"; // Change your database name
//$username = "ijteuute_bryant"; // Your database user id
//$password = "f7qfxs[pEMy$"; // Your password
//
////////// Do not Edit below /////////
//try {
//    $dbo = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);
//} catch (PDOException $e) {
////    print "Error!: " . $e->getMessage() . "<br/>";
//    echo 'Error Failed to login.';
//    die();
//}
$host_name = "localhost";
$database = "ijteuute_tradingcardgameonline"; // Change your database name
$username = "ijteuute_bryant"; // Your database user id
$password = "f7qfxs[pEMy$"; // Your password

// Establish a connection to the database
try {
    $dbo = new PDO('mysql:host='.$host_name.';dbname='.$database, $username, $password);
    $dbo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set error mode to exception
} catch (PDOException $e) {
    // Handle connection errors
    echo 'Error: Failed to connect to the database.';
    die();
}

// Function to execute parameterized SELECT queries
function executeSelectQuery($sql, $params = array()) {
    global $dbo;
    $stmt = $dbo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to execute parameterized INSERT, UPDATE, DELETE queries
function executeNonQuery($sql, $params = array()) {
    global $dbo;
    $stmt = $dbo->prepare($sql);
    return $stmt->execute($params);
}
?>
