<?php
include 'db.php'; // Include the database connection script

// Check if user_id is provided via GET request
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Fetch cards associated with the user
    $sql = "SELECT * FROM trading_cards WHERE owner_id = ? and isDust = 0";
    $cards = executeSelectQuery($sql, array($user_id));

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($cards);
} else {
    // Handle error if user_id is not provided
    echo 'Error: User ID is required.';
}
?>
