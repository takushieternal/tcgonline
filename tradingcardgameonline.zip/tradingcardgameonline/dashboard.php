<?php
/**
 * Created by Bryant Frankford
 * nathanielfrankford@gmail.com
 * Date: 2/3/24
 * Time: 11:00 PM
 * To change this template use File | Settings | File Templates.
 */
if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

if(!isset($_SESSION['login_info'])){
    header("Location: index.php");
    die();
}
require('db.php');
include 'log_all.php';

// Establish connection to MySQL database
$servername = "localhost";
$username = "ijteuute_bryant";
$password = "f7qfxs[pEMy$";
$dbname = "ijteuute_tradingcardgameonline";



$receiverId = $_SESSION['login_info'][0]['id'];
$userid = $_SESSION['login_info'][0]['id'];

////////////////////////
// Random creator_id
$random_creator_id = $userid; // You can replace this with any random creator_id

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL query with creator_id variable
$sql = "SELECT COUNT(*) AS num_cards FROM `trading_cards` WHERE creator_id = ? AND was_purchased = 0 AND dustGenerated = 0 AND create_date >= NOW() - INTERVAL 23 HOUR";

// Prepare and bind the statement
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $random_creator_id); // 'i' indicates integer data type

// Execute the statement
$stmt->execute();

// Bind result variables
$stmt->bind_result($num_cards);

// Fetch the result
$stmt->fetch();

// Check if the number of cards is 5 or more
$hasEnoughCards = ($num_cards < 5);

///////////////////////

// Function to execute parameterized SELECT queries with additional condition
function executeSelectQueryWithCondition($sql, $params = array()) {
    global $dbo;
    $stmt = $dbo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// SQL query to fetch the latest 50 users with last_checked_in time of 5 minutes ago or less
$sql = "SELECT distinct user_id as id, user_name
        FROM VisitorLogs
        WHERE visit_time >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
        AND user_id is not null
        ORDER BY visit_time DESC
        LIMIT 50";
//$sql = "SELECT id, user_name
//        FROM users
//        WHERE last_checked_in >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
//        ORDER BY last_checked_in DESC
//        LIMIT 50";

// No need for parameters as the time is calculated directly in the query
$params = array();

// Execute the query
$latestUsers = executeSelectQueryWithCondition($sql, $params);

$ip_address = $_SERVER['REMOTE_ADDR'];

$userNames = array();
foreach ($latestUsers as $user) {
    $userNames[] = '<span><a href="viewProfile.php?userid='.htmlspecialchars($user['id']).'">' . htmlspecialchars($user['user_name']) . '#' . htmlspecialchars($user['id']) . '</a></span>';
}

//
//try {
//    // SQL query to update last_checked_in for the user with the given ID
//    $sql = "UPDATE users SET last_checked_in = CURRENT_TIMESTAMP, last_logged_in_ip = :lastloggedin WHERE id = :receiverId";
//
//    // Prepare the SQL statement
//    $stmt = $dbo->prepare($sql);
//
//    // Bind the parameters
//    $stmt->bindParam(':receiverId', $userid, PDO::PARAM_INT);
//    $stmt->bindParam(':lastloggedin', $ip_address, PDO::PARAM_STR);
//
//    // Execute the query
//    $stmt->execute();
//
////    echo "User's last_checked_in updated successfully.";
//} catch (PDOException $e) {
//    // Handle errors
//    echo "Error: " . $e->getMessage();
//}


try {
    // Prepare and execute the SQL query to check the count of acceptedTrade
    $sql = "SELECT COUNT(*) AS count_accepted_trade FROM trade_requests WHERE acceptedTrade = 0 AND receiver_id = :receiver_id";
    $stmt = $dbo->prepare($sql);
    $stmt->bindParam(':receiver_id', $receiverId, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if any rows are found
    if ($result) {
        $countAcceptedTrade = $result['count_accepted_trade'];
        if ($countAcceptedTrade > 0) {
            $tradeCount = $countAcceptedTrade;
        } else {
            $tradeCount = 0;
        }
    } else {
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}


try {
    // Prepare and execute the SQL query to check the count of acceptedTrade
    $sql = "SELECT COUNT(*) AS count_gift FROM trades where status = 'pending' AND receiver_id = :receiver_id";
    $stmt = $dbo->prepare($sql);
    $stmt->bindParam(':receiver_id', $receiverId, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if any rows are found
    if ($result) {
        $countAcceptedTrade = $result['count_gift'];
        if ($countAcceptedTrade > 0) {
            $giftCount = $countAcceptedTrade;
        } else {
            $giftCount = 0;
        }
    } else {
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

try {
    // Prepare and execute the select query to get the dust amount from the users table
    $get_dust_query = "SELECT dust FROM users WHERE id = ?";
    $get_dust_statement = $dbo->prepare($get_dust_query);

    // Assume $user_id contains the ID of the user you want to retrieve the dust amount for
    $user_id = $_SESSION['login_info'][0]['id']; // Change this to the actual user ID

    // Bind the parameter and execute the statement
    $get_dust_statement->execute(array($user_id));

    // Fetch the result
    $result = $get_dust_statement->fetch(PDO::FETCH_ASSOC);

    if($result) {
        // Dust amount retrieved successfully
        $dust_amount = $result['dust'];
//        echo "Dust amount for user with ID $user_id: $dust_amount";
    } else {
        // User not found or no dust amount available
//        echo "No dust amount found for user with ID $user_id";
    }
} catch (PDOException $e) {
    // Handle any errors that occur during the database operation
    echo "Error retrieving dust amount: " . $e->getMessage();
}

try {
    // Prepare and execute the select query to get the dust amount from the users table
    $get_dust_query = "SELECT premiumDust FROM users WHERE id = ?";
    $get_dust_statement = $dbo->prepare($get_dust_query);

    // Bind the parameter and execute the statement
    $get_dust_statement->execute(array($user_id));

    // Fetch the result
    $result = $get_dust_statement->fetch(PDO::FETCH_ASSOC);

    if($result) {
        // Dust amount retrieved successfully
        $premiumDust = $result['premiumDust'];

//        echo "Dust amount for user with ID $user_id: $dust_amount";
    } else {
        // User not found or no dust amount available
//        echo "No dust amount found for user with ID $user_id";
    }
} catch (PDOException $e) {
    // Handle any errors that occur during the database operation
    echo "Error retrieving dust amount: " . $e->getMessage();
}


$username = $_SESSION['login_info'][0]['user_name'].'#'.$_SESSION['login_info'][0]['id'];
$dust = $dust_amount;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $username; ?> | TradingCardGameOnline.Com</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/card.css">
    <link rel="stylesheet" href="css/fontawesome-free-6.5.1-web/css/all.css">
    <script src="css/fontawesome-free-6.5.1-web/js/fontawesome.js"></script>

    <!--    <link rel="stylesheet" href="css/autobattle.css">-->

    <script src="js/jquery.js"></script>

    <link rel="icon" type="image/png" href="images/favicon.png" />

</head>
<body id="dashboardbody" data-userid="<?php echo $_SESSION['login_info'][0]['id']; ?>">
<nav id="navbar">
    <div class="nav-logo"><?php
        echo '<span class="premiumCurrency currency">['.$premiumDust.' Ᵽremium Dust]</span><br /><span class="currency">['.$dust.' Đust]</span><br /> ';
        echo $username;
        ?></div>
    <div class="menu-icon" onclick="toggleMenu()">
        <div class="menu-line"></div>
        <div class="menu-line"></div>
        <div class="menu-line"></div>
    </div>
    <ul class="nav-links" id="navLinks">
        <li><a href="dashboard.php">Latest Cards</a></li>
        <li><a href="cardClash.php">Card Clash</a></li>
<!--        <li><a href="#">Build Deck</a></li>-->
<!--        <li><a href="trade.php">Send Cards</a></li>-->
<!--        <li><a href="trades.php">Check Gifts(--><?php //echo $giftCount; ?><!--)</a></li>-->
        <li><a href="#" id="collectionButton">Collection</a></li>
<!--        <li><a href="#" id="leaderBoardButton">Leaderboard</a></li>-->
        <li><a href="powerupView.php">Power-Up Cards(10Đ)</a></li>
        <li><a href="generateCard.php">Generate Card<?php
            if($hasEnoughCards){
                echo '(Free!)';
            }
            ;?>(20Đ)</a></li>
        <li><a href="generatePCard.php">Generate Premium Card<span class="premiumCurrency">(20Ᵽ)</span></a></li>
        <li><a href="buyPDust.php">Buy Premium Dust</a></li>
<!--        <li><a href="buyCard.php">Buy Cards</a></li>-->
        <li><a href="dust.php">Dust Cards</a></li>
        <li><a href="undust.php">Dustyard</a></li>
        <li><a href="tradesView.php">Trades(<?php echo $tradeCount; ?>)</a></li>
        <li><a href="https://www.facebook.com/profile.php?id=61556594970882"><img class="facebookLogo" src="images/facebook.png" /></a></li>
        <li><a href="https://discord.gg/Yahz9xebQ3"><img class="discordLogo" src="images/discord.svg" /></a></li>
        <li><a href="faq.php">FAQ</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>
<div class="activeUsersList">
    <div class="scroll-container">
        <div class="scroll-content">
    <?php // Output the user names separated by commas
echo '<span class="activeUsers">Active Users: </span>';
echo implode(', ', $userNames);
    ?>
            </div>
        </div>
</div>
<div class="navDiv"></div>
<div class="content-container">
    <!-- Your content here -->
</div>


<script src="js/dashboard.js"></script>
<script src="js/collection.js"></script>
<script src="js/dashboardMenu.js"></script>
<script src="js/card.js"></script>

</body>
</html>
