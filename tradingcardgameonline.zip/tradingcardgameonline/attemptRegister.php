<?php
/**
 * Created by Bryant N Frankford
 * nathanielfrankford@gmail.com
 */

if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

require('db.php');

$email = $_POST['emailAddress'];
$password = md5($_POST['userPassword']);
$confirmPassword = md5($_POST['confirmPassword']);
$userName = $_POST['userName'];

if($password == $confirmPassword){
    $checkIfEmailExistSQL =<<<EOQ
SELECT * FROM users where email = ?
EOQ;

    $qb = $dbo->prepare($checkIfEmailExistSQL);
    $counter = 0;
    try{
//        $qb->execute(array());
        $qb->bindParam(1, $email, PDO::PARAM_STR);
        $qb->execute();
        $result = $qb->fetchAll();

        $rows = array();

        foreach($result as $card){
            $rows[] = $card;
            $counter++;
        }

        if($counter == 0){
            //insert if no duplicate
            $sql =<<<EOQ
INSERT INTO users (email, password, user_name) values(:email, :password, :firstName )
EOQ;

            $q = $dbo->prepare($sql);

            try{
                $q->execute(array(':email'=>$email,':password'=>$password,':firstName'=>$userName));

                $emailMessage =<<<EOQ
Thank you for registering with "TradingCardGameOnline.Com   ".
EOQ;

                // Set content-type header for sending HTML email
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

                mail($email, "Thank you for registering",$emailMessage,$headers);

                echo '<h1><a href="index.php">Thank you for registering. Return home.</a></h1>';
            }catch(exception $e){

            }

        } else{
            echo '<h1>Duplicate email detected.<a href="index.php">Return home.</a></h1>';
        }

    }catch(exception $e){

    }


}else{
    echo '<h1>Password fields do not match.<a href="index.php">Return home.</a></h1>';
}