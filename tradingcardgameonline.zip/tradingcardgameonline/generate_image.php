<?php
die();
// Prompt for the trading card
$cardName = "Adept Resilient Formidable Sword";
$attributes = "Level: 2 HP: 141 Attack Strength: 74 Ability 1: Shadow Ability 2: Fireball";

$prompt = "Generate an image for a trading card named \"$cardName\" with attributes: $attributes";

// URL of the Stable Diffusion API endpoint
$apiUrl = 'https://api.stability.ai/v1/generation/stable-diffusion-v1-6/text-to-image';

// Set the HTTP headers for the request
$headers = array(
    'Content-Type: application/json',
    'Authorization: Bearer sk-aFdLIEog22VNfJ3p69EHtyzpscg3LLGHEqHD1JKnGVus14c3', // Replace with your actual API key
);

// Data to be sent in the request body
$data = array(
    'text_prompts' => array(
        array(
            'text' => $prompt,
        ),
    ),
    'cfg_scale' => 7,
    'height' => 1024,
    'width' => 1024,
    'samples' => 1,
    'steps' => 30,
);

// Initialize curl session
$curl = curl_init();

// Set curl options
curl_setopt_array($curl, array(
    CURLOPT_URL => $apiUrl,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($data),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => $headers,
));

// Execute curl session and get the response
$response = curl_exec($curl);

// Check for curl errors
if (curl_errno($curl)) {
    echo "cURL Error: " . curl_error($curl);
} elseif ($response === false) {
    echo "Error: Empty response from the API.";
} else {
    // Decode the JSON response
    $responseData = json_decode($response, true);

    if (isset($responseData['artifacts'][0]['base64'])) {
        // Image data received from the API response
        $imageData = $responseData['artifacts'][0]['base64'];

        // Directory to save the image
        $imageDirectory = 'images/card_art/';
        // Ensure the directory exists, create if not
        if (!file_exists($imageDirectory)) {
            mkdir($imageDirectory, 0755, true);
        }

        // Save the image data to a file
        $imageFilename = $imageDirectory . 'generated_image_test.png';
        $imagePath = __DIR__ . '/' . $imageFilename; // Absolute file path

        // Attempt to decode base64-encoded image data
        $imageContent = base64_decode($imageData);

        // Check if decoding was successful
        if ($imageContent !== false) {
            // Save the decoded image data to a file
            if (file_put_contents($imagePath, $imageContent) !== false) {
                // Check if the image file exists and is readable
                if (is_readable($imagePath)) {
                    // Display the uploaded image on your web page
                    echo '<html><body><img src="' . $imageFilename . '" alt="Generated Image"></body></html>';
                } else {
                    echo "Error: The generated image file ($imagePath) is not readable.";
                }
            } else {
                echo "Error: Failed to save the generated image to file. Check file permissions.";
            }
        } else {
            echo "Error: Failed to decode the image data.";
        }
    } elseif (isset($responseData['error'])) {
        // Handle API error
        echo "API Error: " . $responseData['error'];
    } else {
        // Handle error if image generation failed
        echo "Error: Failed to generate image.";
        error_log("Failed to generate image: " . print_r($responseData, true)); // Log error
    }
}

// Close curl session
curl_close($curl);
?>
