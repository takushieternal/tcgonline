<?php
include 'db.php'; // Include the database connection script

// Check if sender_id, receiver_id, and card_id are provided via POST request
if (isset($_POST['sender_id'], $_POST['receiver_id'], $_POST['card_id'])) {
    $sender_id = $_POST['sender_id'];
    $receiver_id = $_POST['receiver_id'];
    $card_id = $_POST['card_id'];

    // Insert trade request into the database
    $sql = "INSERT INTO trades (sender_id, receiver_id, card_id) VALUES (?, ?, ?)";
    $success = executeNonQuery($sql, array($sender_id, $receiver_id, $card_id));

    // Return success or failure response
    if ($success) {
        echo 'Trade request initiated successfully.';
    } else {
        echo 'Error: Failed to initiate trade request.';
    }
} else {
    // Handle error if required parameters are not provided
    echo 'Error: Missing parameters.';
}
?>