<html>
<head>
    <title>Password Reset Confirmation</title>
</head>
<body>
<h2>Password Reset Email Sent</h2>
<p>An email with instructions to reset your password has been sent to your email address.</p>
<p><a href="index.php">Return home.</a></p>
</body>
</html>
