<?php
/**
 * Created by Bryant Frankford
 * nathanielfrankford@gmail.com
 * Date: 2/3/24
 * Time: 11:00 PM
 * To change this template use File | Settings | File Templates.
 */
if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

if(!isset($_SESSION['login_info'])){
    header("Location: index.php");
    die();
}

// Establish connection to MySQL database
$servername = "localhost";
$username = "ijteuute_bryant";
$password = "f7qfxs[pEMy$";
$dbname = "ijteuute_tradingcardgameonline";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch latest 100 cards from trading_cards table
$sql = "SELECT * FROM trading_cards where isDust = 0 ORDER BY EXPERIENCE DESC LIMIT 100";
$result = $conn->query($sql);

// Initialize an array to store card data
$cardData = array();

// Check if there are results
if ($result->num_rows > 0) {
    // Loop through each row and add card data to the array
    while($row = $result->fetch_assoc()) {
        $cardData[] = array(
            "id" => $row["id"],
            "name" => $row["name"],
            "level" => $row["level"],
            "hp" => $row["hp"],
            "attack_strength" => $row["attack_strength"],
            "ability1" => $row["ability1"],
            "ability2" => $row["ability2"],
            "signature" => $row["username"],
            "borderRarity" => $row["border_rarity"],
            "image_url" => $row["image_url"],
            "was_purchased" => $row["was_purchased"],
            "owner_id" => $row["owner_id"],
            "experience" => $row["experience"]
        );
    }
}

// Close MySQL connection
$conn->close();

// Convert the card data array to JSON format
$jsonData = json_encode($cardData);

// Output the JSON data
echo $jsonData;
?>