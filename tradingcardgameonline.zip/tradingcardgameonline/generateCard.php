<?php
/**
 * Created by Bryant N Frankford
 * nathanielfrankford@gmail.com
 */

//No SSL Certificate
if ($_SERVER["HTTPS"] != "on") {
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

if (!isset($_SESSION['login_info'])) {
    header("Location: index.php");
    die();
}

include 'creditCheck.php';

include 'db.php';

$userID = $_SESSION['login_info'][0]['id'];
$usedPrompt = '';

// Establish connection to MySQL database
$servername = "localhost";
$username = "ijteuute_bryant";
$password = "f7qfxs[pEMy$";
$dbname = "ijteuute_tradingcardgameonline";

// Function to get the verification token status of a user by ID
function getUserVerificationStatusById($userId)
{
    // Retrieve the verification token status from the database
    $sql = "SELECT verification_token FROM users WHERE id = ?";
    $result = executeSelectQuery($sql, [$userId]);

    if (!empty($result)) {
        $verificationToken = $result[0]['verification_token'];

        if ($verificationToken !== 'complete') {

            function generateVerificationToken()
            {
                return bin2hex(random_bytes(32)); // Generate a random token
            }

            $email = $_SESSION['login_info'][0]['email'];

            // Retrieve user ID associated with the provided email address
            $sql = "SELECT id FROM users WHERE email = ?";
            $result = executeSelectQuery($sql, [$email]);

            if (!empty($result)) {
                $userId = $result[0]['id'];

                // Generate verification token
                $verificationToken = generateVerificationToken();

                // Update the user record with the verification token
                $sql = "UPDATE users SET verification_token = ? WHERE id = ?";
                executeNonQuery($sql, [$verificationToken, $userId]);

                $verificationLink = "http://tradingcardgameonline.com/verify.php?token=$verificationToken"; // Replace with your website URL
                $subject = "Verify Your Email";
                $message = "Click the following link to verify your email: $verificationLink";

// Headers for a "no-reply" email
                $headers = "From: Trading Card Game Online <no-reply@tradingcardgameonline.com>\r\n";
                $headers .= "Reply-To: no-reply@tradingcardgameonline.com\r\n";
                $headers .= "X-Mailer: PHP/" . phpversion();

// Send verification email
                mail($email, $subject, $message, $headers);


                echo "<html><head><title>Verify Email</title><link rel=\"stylesheet\" href=\"css/generateCard.css\"> <link rel=\"icon\" type=\"image/png\" href=\"images/favicon.png\" /></head><body><div class=\"verificationDiv\">Verification email sent. Please check your email to verify your account. Check your spam folder! <a href=\"dashboard.php\">Return Home</a></div>";
                exit();
            } else {
                echo "User with the provided email address not found. <a href=\"dashboard.php\">Return Home</a>";
            }
            die();

        }
    } else {
        return "User not found. <a href=\"dashboard.php\">Return Home</a>";
    }
}

// Random creator_id
$random_creator_id = $userID; // You can replace this with any random creator_id

getUserVerificationStatusById($userID);

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL query with creator_id variable
$sql = "SELECT COUNT(*) AS num_cards FROM `trading_cards` WHERE creator_id = ? AND was_purchased = 0 AND dustGenerated = 0 AND create_date >= NOW() - INTERVAL 23 HOUR";

// Prepare and bind the statement
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $random_creator_id); // 'i' indicates integer data type

// Execute the statement
$stmt->execute();

// Bind result variables
$stmt->bind_result($num_cards);

// Fetch the result
$stmt->fetch();

// Check if the number of cards is 5 or more
$hasEnoughCards = ($num_cards < 5);

//var_dump($num_cards);die();

// Output the result
//echo "Has enough cards: " . ($hasEnoughCards ? 'true' : 'false');
//die();


try {
    // Prepare and execute the select query to get the dust amount from the users table
    $get_dust_query = "SELECT dust FROM users WHERE id = ?";
    $get_dust_statement = $dbo->prepare($get_dust_query);

    // Assume $user_id contains the ID of the user you want to retrieve the dust amount for
    $user_id = $_SESSION['login_info'][0]['id']; // Change this to the actual user ID

    // Bind the parameter and execute the statement
    $get_dust_statement->execute(array($user_id));

    // Fetch the result
    $result = $get_dust_statement->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        // Dust amount retrieved successfully
        $dust_amount = $result['dust'];
//        echo "Dust amount for user with ID $user_id: $dust_amount";
    } else {
        // User not found or no dust amount available
//        echo "No dust amount found for user with ID $user_id";
    }
} catch (PDOException $e) {
    // Handle any errors that occur during the database operation
    echo "Error retrieving dust amount: " . $e->getMessage();
}

// Close statement and connection
$stmt->close();
$conn->close();

$dust = $dust_amount;
$dustGenerated = 0;

if ($hasEnoughCards == false && $dust_amount < 20) {
    header('Location: dashboard.php?cardMax=yes');
    die();
} else if ($hasEnoughCards == false && $dust_amount >= 20) {
    try {
        $userid = $_SESSION['login_info'][0]['id'];

        // Prepare and execute the update query for users table
        $update_users_query = "update users set dust = dust - 20 where id = ?";
        $update_users_statement = $dbo->prepare($update_users_query);
        $update_users_statement->execute(array($userid));
        $dustGenerated = 1;

    } catch (PDOException $e) {
        echo "Error updating database: " . $e->getMessage();
    }
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to generate a random card
function generateRandomCard($rarity)
{
    $card = array();

    // Card attributes
    $level = rand(1, 5); // Restricting the level to a maximum of 5
    $hp = rand(50, 200);
    $attackStrength = rand(20, 100);

    // Call the generateName function and store the result in $nameAndNoun
    $nameAndNoun = generateName($level, $hp, $attackStrength);

// Assign the generated name to $card['name']
    $card['name'] = $nameAndNoun['name'];

// Optionally, you can also assign the randomly chosen noun to another variable if needed
    $randomNoun = $nameAndNoun['noun'];

    // Assign other attributes
    $card['level'] = $level;
    $card['hp'] = $hp;
    $card['attack_strength'] = $attackStrength;

    // List of random abilities
    $abilities = array(
        "Fireball",
        "Healing",
        "Lightning",
        "Shadow",
        "Ice",
        "Earthquake",
        "Wind",
        "Poison",
        "Teleportation",
        "Barrier"
    );

    // Randomly select abilities
    $card['ability1'] = $abilities[array_rand($abilities)];
    $card['ability2'] = $abilities[array_rand($abilities)];

//GENERATE IMAGE

// Prompt for the trading card
    $cardName = $card['name'];
    $attributes = 'Level:' . $card['level'] . ' HP:' . $card['hp'] . ' Attack Strength:' . $card['attack_strength'] . ' Ability 1:' . $card['ability1'] . ' Ability 2:' . $card['ability2'];

    $prompt =  $cardName . " that is highly stylized and has a high resolution.".'Use a highly detailed background. ';
//
//    if (rand(0, 100) > 95) {
//        $prompt = $prompt . 'Make it pixel art.';
//    }

    // Generate a random number between 0 and 100
    $randomNumber = mt_rand(0, 100);

// Determine which section the random number falls into
    $section = floor($randomNumber / 10);

// Switch case based on the section
    switch ($section) {
        case 0:
            // Random number is between 0 and 9
            $prompt = $prompt . 'Make it pixel art.';
            break;
        case 1:
            // Random number is between 10 and 19
            $prompt = $prompt . 'Make it using a really basic style.';
            break;
        case 2:
            // Random number is between 20 and 29
            $prompt = $prompt . 'Make it in the style of realism.';
            break;
        case 3:
            // Random number is between 30 and 39
            $prompt = $prompt . 'Make it in the style of pop art.';
            break;
        case 4:
            // Random number is between 40 and 49
            $prompt = $prompt . 'Make it in the style of fauvism.';
            break;
        case 5:
            // Random number is between 50 and 59
            $prompt = $prompt . 'Make it in a random style.';
            break;
        case 6:
            // Random number is between 50 and 59
            $prompt = $prompt . 'Make it in an anime style.';
            break;
        case 7:
            // Random number is between 50 and 59
            $prompt = $prompt . 'Make it in a famous art style.';
            break;
        case 8:
            // Random number is between 50 and 59
            $prompt = $prompt . 'Make it in the style of minimalism.';
            break;
        case 9:
            // Random number is between 50 and 59
            $prompt = $prompt . 'Make it in a default style.';
            break;
        // Add more cases for sections 6 to 9 as needed
        default:
            break;
    }

    if(rand(0,100) > 95){
        $prompt = $prompt. ', add cyber-punk to the mix';
    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add wild west to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add piracy to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add cyber-punk to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add fantasy to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add love to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add nature to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add portraiture to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add abstract expressionism to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add surrealism to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add mythology to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', sci-fi to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add futurism to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', absurdism to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add exploration to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', ignore half the information for this prompt';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add whimsy to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add chaos to the mix';
//    }
//    if(rand(0,100) > 95){
//        $prompt = $prompt. ', add folklore to the mix';
//    }

// URL of the Stable Diffusion API endpoint
    $apiUrl = 'https://api.stability.ai/v1/generation/stable-diffusion-v1-6/text-to-image';

// Set the HTTP headers for the request
    $headers = array(
        'Content-Type: application/json',
        'Authorization: Bearer sk-aFdLIEog22VNfJ3p69EHtyzpscg3LLGHEqHD1JKnGVus14c3', // Replace with your actual API key
    );

// Data to be sent in the request body
    $data = array(
        'text_prompts' => array(
            array(
                'text' => $prompt,
            ),
        ),
        'cfg_scale' => 12,
        'height' => 512,
        'width' => 512,
        'samples' => 1,
        'steps' => 20
    );

// Initialize curl session
    $curl = curl_init();

// Set curl options
    curl_setopt_array($curl, array(
        CURLOPT_URL => $apiUrl,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => $headers,
    ));

// Execute curl session and get the response
    $response = curl_exec($curl);

// Check for curl errors
    if (curl_errno($curl)) {
        echo "cURL Error: " . curl_error($curl);
    } elseif ($response === false) {
        echo "Error: Empty response from the API.";
    } else {
        // Decode the JSON response
        $responseData = json_decode($response, true);

        if (isset($responseData['artifacts'][0]['base64'])) {
            // Image data received from the API response
            $imageData = $responseData['artifacts'][0]['base64'];

            // Directory to save the image
            $imageDirectory = 'images/card_art/';
            // Ensure the directory exists, create if not
            if (!file_exists($imageDirectory)) {
                mkdir($imageDirectory, 0755, true);
            }

            // Save the image data to a file
            $imageFilename = $imageDirectory . $card['name'] . date('Y-m-d H:i:s') . '.png';
            $imagePath = $imageFilename; // Absolute file path

            // Attempt to decode base64-encoded image data
            $imageContent = base64_decode($imageData);

            // Check if decoding was successful
            if ($imageContent !== false) {
                // Save the decoded image data to a file
                if (file_put_contents($imagePath, $imageContent) !== false) {
                    // Check if the image file exists and is readable
                    if (is_readable($imagePath)) {
                        // Display the uploaded image on your web page
//                    echo '<html><body><img src="' . $imageFilename . '" alt="Generated Image"></body></html>';
                    } else {
//                    echo "Error: The generated image file ($imagePath) is not readable.";
                    }
                } else {
                    echo "Error: Failed to save the generated image to file. Check file permissions.";
                }
            } else {
                echo "Error: Failed to decode the image data.";
            }
        } elseif (isset($responseData['error'])) {
            // Handle API error
            echo "API Error: " . $responseData['error'];
            die();
        } else {
            // Handle error if image generation failed
            echo 'Error: Failed to generate image. Out of credits.<a href="dashboard.php">Return to dashboard</a>';
            error_log("Failed to generate image: " . print_r($responseData, true)); // Log error
            die();
        }
    }

// Close curl session
    curl_close($curl);
//END GENERATE IMAGE
    $card['filepath'] = $imagePath;
    $card['prompt'] = $prompt;
    $card['shortname'] = $randomNoun;

    return $card;
}

// Function to generate a name based on card attributes
function generateName($level, $hp, $attackStrength)
{

    $adjectives = [
        "Pirate-Like","Abandoned", "Adorable", "Aggressive", "Amused", "Bewildered", "Breezy", "Charming", "Clumsy", "Cozy", "Dazzling",
        "Delightful", "Eager", "Enchanting", "Fierce", "Fluffy", "Gentle", "Gloomy", "Graceful", "Hilarious", "Jovial",
        "Lively", "Mysterious", "Playful", "Precious", "Quirky", "Radiant", "Serene", "Silly", "Sleek", "Spooky",
        "Tranquil", "Vibrant", "Whimsical", "Witty", "Zany", "Zealous", "Zesty", "Magic"
    ];

    $adjectives2 = [
        "Adventurous", "Brilliant", "Clever", "Determined", "Energetic", "Fearless", "Genuine", "Happy", "Inquisitive", "Joyful",
        "Kind", "Loyal", "Magnificent", "Noble", "Optimistic", "Passionate", "Radiant", "Sincere", "Thrilling", "Unique",
        "Vibrant", "Wise", "Xenial", "Youthful", "Zesty", "Amiable", "Blissful", "Courageous", "Diligent", "Empathetic",
        "Friendly", "Grateful", "Harmonious", "Inspiring", "Jubilant", "Keen", "Lively", "Mindful", "Nurturing", "Open-minded"
    ];

    $levelDescriptors = ["Beginner", "Adept", "Experienced", "Skilled", "Magic"];
    $hpDescriptors = ["Fragile", "Sturdy", "Stalwart", "Tough", "Super"];
    $attackDescriptors = ["Weak", "Moderate", "Formidable", "Powerful", "Masterful"];
//    $nouns = ["Sword", "Shield", "Staff", "Axe", "Bow", "Hammer", "Scepter", "Person", "Missile", "Penguin", "Book", "Tree", "Apple", "Computer", "River", "Bird", "Mountain", "Dog", "Car", "Sun", "President"];
    $nouns1 = [
        "Apple", "Banana", "Cat", "Dog", "Elephant", "Fish", "Guitar", "Hat", "Ice cream", "Jacket",
        "Kite", "Lion", "Monkey", "Notebook", "Orange", "Penguin", "Quilt", "Rabbit", "Sun", "Table",
        "Umbrella", "Violin", "Watch", "Xylophone", "Yacht", "Zebra", "Ant", "Ball", "Car", "Duck",
        "Egg", "Flower", "Globe", "House", "Ice", "Juice", "Key", "Lamp", "Moon", "Nest", "Owl",
        "Piano", "Queen", "Rain", "Star", "Tree", "Umbrella", "Van", "Window", "X-ray", "Yogurt",
        "Zoo", "Airplane", "Bee", "Cake", "Desk", "Eagle", "Flag", "Guitar", "Horse", "Island",
        "Jellyfish", "Kangaroo", "Lemon", "Map", "Ninja", "Ocean", "Pineapple", "Quail", "Rocket",
        "Snake", "Train", "Umbrella", "Violin", "Wallet", "Xylophone", "Yarn", "Zoo", "Apple", "Ball",
        "Cat", "Dog", "Elephant", "Fish", "Guitar", "Hat", "Ice cream", "Jacket", "Kite", "Lion",
        "Monkey", "Notebook", "Orange", "Penguin", "Quilt", "Rabbit", "Sun", "Table", "Umbrella",
        "Violin", "Watch", "Xylophone", "Yacht", "Zebra", "Ant", "Ball", "Car", "Duck", "Egg",
        "Flower", "Globe", "House", "Ice", "Juice", "Key", "Lamp", "Moon", "Nest", "Owl", "Piano",
        "Queen", "Rain", "Star", "Tree", "Umbrella", "Van", "Window", "X-ray", "Yogurt", "Zoo",
        "Airplane", "Bee", "Cake", "Desk", "Eagle", "Flag", "Guitar", "Horse", "Island", "Jellyfish",
        "Kangaroo", "Lemon", "Map", "Ninja", "Ocean", "Pineapple", "Quail", "Rocket", "Snake", "Train",
        "Umbrella", "Violin", "Wallet", "Xylophone", "Yarn", "Zoo", "Apple", "Ball", "Cat", "Dog",
        "Elephant", "Fish", "Guitar", "Hat", "Ice cream", "Jacket", "Kite", "Lion", "Monkey", "Notebook",
        "Orange", "Penguin", "Quilt", "Rabbit", "Sun", "Table", "Umbrella", "Violin", "Watch", "Xylophone",
        "Yacht", "Zebra", "Ant", "Ball", "Car", "Duck", "Egg", "Flower", "Globe", "House", "Ice", "Juice",
        "Key", "Lamp", "Moon", "Nest", "Owl", "Piano", "Queen", "Rain", "Star", "Tree", "Umbrella", "Van",
        "Window", "X-ray", "Yogurt", "Zoo", "Airplane", "Bee", "Cake", "Desk", "Eagle", "Flag", "Guitar",
        "Horse", "Island", "Jellyfish", "Kangaroo", "Lemon", "Map", "Ninja", "Ocean", "Pineapple", "Quail",
        "Rocket", "Snake", "Train", "Umbrella", "Violin", "Wallet", "Xylophone", "Yarn", "Zoo",
        "Mailbox",
        "Alligator",
        "Bird",
        "Eagle",
        "Hawk",
        "Falcon",
        "Owl",
        "Parrot",
        "Dove",
        "Swan",
        "Pelican",
        "Crane",
        "Heron",
        "Insect",
        "Ant",
        "Bee",
        "Wasp",
        "Butterfly",
        "Moth",
        "Caterpillar",
        "Spider",
        "Fly",
        "Mosquito",
        "Dragonfly",
        "Beetle",
        "Ladybug",
        "Grasshopper",
        "Cricket",
        "Scorpion",
        "Centipede",
        "Millipede",
        "Worm",
        "Snail",
        "Slug",
        "Starfish",
        "Jellyfish",
        "Octopus",
        "Squid",
        "Crab",
        "Lobster",
        "Shrimp",
        "Clam",
        "Oyster",
        "Mussel",
        "Scallop",
        "Coral",
        "Anemone",
        "Sea Urchin",
        "Sea Cucumber",
        "Plankton",
        "Algae",
        "Fungus",
        "Mushroom",
        "Toadstool","Hairless Cat","Tree Person",
        "Pet Monster",
        "Mimic",
        "Dinosaur",
        "Adventurer",
        "Explorer",
        "Inventor",
        "Scientist",
        "Robot",
        "Drone",
        "Gadget",
        "Gizmo",
        "Virtual World",
        "Digital Realm",
        "Cyberspace",
        "Data Miner",
        "Computer Virus",
        "Security Program",
        "Encryption Key",
        "Firewall",
        "Smart Device",
        "Tech Wizard",
        "Social Network",
        "Trendsetter",
        "Viral Post",
        "Livestreamer",
        "Gamer",
        "Streamer",
        "Online Avatar",
        "Chat Room",
        "Message Board",
        "Cyberpunk",
        "Virtual Reality",
        "Augmented Reality",
        "Digital Currency",
        "Crypto Miner",
        "Blockchain",
        "E-Sports",
        "Online Community",
        "Digital Art",
        "E-Pet",
        "AI Assistant",
        "Smartphone",
        "Tablet",
        "Smartwatch",
        "Video Call",
        "Digital Wallet",
        "E-Commerce",
        "Digital Marketplace",
        "Online Auction",
        "Cloud Storage",
        "Streaming Service",
        "Digital Library",
        "Internet Access",
        "Wi-Fi Network",
        "Digital Nomad",
        "Remote Work",
        "Internet Safety",
        "Privacy Settings",
        "Netizen",
        "Internet Celebrity",
        "Content Creator",
        "Digital Content",
        "E-Book",
        "E-Learning",
        "Online Education",
        "Web Browser",
        "Search Engine",
        "Website",
        "Web Developer",
        "Digital Footprint",
        "Online Security",
        "Password Manager",
        "Parental Controls",
        "Data Privacy",
        "Cyberbullying",
        "Digital Detox",
        "Online Gaming",
        "Video Game",
        "Console",
        "PC Gaming",
        "Mobile Gaming",
        "Arcade Game",
        "Game Controller",
        "Virtual Pet",
        "Digital Pet",
        "Avatar",
        "Pixel Art",
        "Tech Support",
        "Tech Enthusiast",
        "Online Store",
        "Digital Camera",
        "Smart Home",
        "Internet of Things",
        "Wearable Tech",
        "Fitness Tracker",
        "Virtual Assistant",
        "Chatbot",
        "Tech Conference",
        "Hackathon",
        "Code",
        "Debugging",
        "Programming",
        "Tech Blog",
        "Social Media Influencer",
        "Webinar",
        "Digital Marketing",
        "Online Banking",
        "Cyber Security",
        "Cloud Computing",
        "Digital Entertainment",
        "Digital Media",
        "Tech Startup",
        "Crowdfunding",
        "Podcast",
        "Virtual Tour",
        "Digital Nomad",
        "Remote Work",
        "Telecommuting",
        "Work From Home",
        "Zoom Meeting",
        "Video Call",
        "Dragon",
        "Wizard",
        "Elf",
        "Orc",
        "Goblin",
        "Fairy",
        "Phoenix",
        "Vampire",
        "Werewolf",
        "Zombie",
        "Ghost",
        "Angel",
        "Demon",
        "Centaur",
        "Griffin",
        "Hydra",
        "Sphinx",
        "Minotaur",
        "Cyclops",
        "Chimera",
        "Gargoyle",
        "Banshee",
        "Specter",
        "Lich",
        "Behemoth",
        "Sorcerer",
        "Warlock",
        "Druid",
        "Necromancer",
        "Shaman",
        "Paladin",
        "Barbarian",
        "Bard",
        "Ranger",
        "Knight",
        "Gladiator",
        "Jester",
        "Siren",
        "Merman",
        "Harpy",
        "Titan",
        "Frost Giant",
        "Fire Elemental",
        "Water Elemental",
        "Earth Elemental",
        "Air Elemental",
        "Djinn",
        "Genie",
        "Leprechaun",
        "Pixie",
        "Satyr",
        "Unicorn",
        "Pegasus",
        "Gryphon",
        "Basilisk",
        "Kobold",
        "Satellite",
        "Asteroid",
        "Meteor",
        "Cosmic Entity",
        "Eldritch Horror",
        "Dimensional Shifter",
        "Time Traveler",
        "Parallel Universe",
        "Dream Walker",
        "Nightmare",
        "Reality Warper",
        "Eternal Being",
        "Celestial Being",
        "Shadow Creature",
        "Ethereal Being",
        "Arcane Entity",
        "Ancient Guardian",
        "Time Guardian",
        "Space Guardian",
        "Elemental Guardian",
        "Spirit Guardian",
        "Mythical Beast",
        "Legendary Creature",
        "Epic Hero",
        "Mythic Champion",
        "Arcane Archer",
        "Master Wizard",
        "Grandmaster",
        "Divine Intervention",
        "Celestial Crusader",
        "Cosmic Conqueror",
        "Dimensional Explorer",
        "Eternal Watcher",
        "Mythical Monarch",
        "Legendary Lord",
        "Primordial Entity",
        "Fabled Warrior",
        "Mythic Mount",
        "Legendary Land",
        "Epic Artifact",
        "Mythical Relic",
        "Legendary Item",
        "Epic Spell",
        "Mythic Ability",
        "Legendary Power",
        "Epic Battle",
        "Mythic Encounter",
        "Legendary Showdown",
        "Epic Clash",
        "Mythic Challenge",
        "Legendary Duel",
        "Epic Journey",
        "Mythic Quest",
        "Legendary Adventure",
        "Epic Saga",
        "Mythic Tale",
        "Legendary Chronicle",
        "Soldier",
        "Horse",
        "Puppet",
        "Castle",
        "Monk",
        "Martial Artist",
        "Plumber",
        "Archipelago",
        "Jack Russell",
        "Dachshund",
        "Tank",
        "Submarine",
        "Battleship",
        "Giant Robot",
        "Stuffed Bear",
        "Pig",
        "Mermaid",
        "Fish Person",
        "Waterfall",
        "Cat",
        "Alien",
        "Samurai",
        "Ninja",
        "Turtle",
        "Savior",
        "Patriot",
        "Portal",
        "Sidekick",
        "Necromancer",
        "Assassin",
        "Anime Protagonist",
        "Zombie",
        "Gymnast",
        "Dark Knight",
        "Super Hero",
        "Elephant",
        "Truck",
        "Spaceship",
        "Space Wizard",
        "Space Knight",
        "Degenerate",
        "Bear",
        "Panda",
        "Sword",
        "Dagger",
        "Rapier",
        "Saber",
        "Blade",
        "Cutlass",
        "Shield",
        "Buckler",
        "Barrier",
        "Armor",
        "Guard",
        "Protection",
        "Staff",
        "Baton",
        "Rod",
        "Cane",
        "Stick",
        "Pole",
        "Axe",
        "Hatchet",
        "Cleaver",
        "Tomahawk",
        "Adze",
        "Chopper",
        "Bow",
        "Archer",
        "Arrow",
        "Quiver",
        "String",
        "Archery",
        "Hammer",
        "Mallet",
        "Sledgehammer",
        "Maul",
        "Gavel",
        "Pounder",
        "Scepter",
        "Wand",
        "Rod",
        "Baton",
        "Staff",
        "Symbol",
        "Person",
        "Individual",
        "Human",
        "Being",
        "Character",
        "Soul",
        "Missile",
        "Rocket",
        "Projectile",
        "Torpedo",
        "Bomb",
        "Warhead",
        "Penguin",
        "Bird",
        "Antarctic",
        "Aeroplane",
        "Aquatic",
        "Tuxedo",
        "Book",
        "Ship",
        "Tome",
        "Volume",
        "Manuscript",
        "Publication",
        "Tree",
        "Forest",
        "Wood",
        "Trunk",
        "Branch",
        "Bark",
        "Apple",
        "Fruit",
        "Orchard",
        "Core",
        "Red",
        "Juicy",
        "Computer",
        "Laptop",
        "Device",
        "Machine",
        "PC",
        "Technology",
        "River",
        "Stream",
        "Brook",
        "Creek",
        "Tributary",
        "Waterway",
        "Bird",
        "Avian",
        "Feathered",
        "Winged",
        "Fowl",
        "Songbird",
        "Mountain",
        "Peak",
        "Summit",
        "Range",
        "Hill",
        "Summit",
        "Dog",
        "Canine",
        "Pet",
        "Pooch",
        "Hound",
        "Animal",
        "Car",
        "Automobile",
        "Vehicle",
        "Transport",
        "Automobile",
        "Ride",
        "Sun",
        "Star",
        "Solar",
        "Light",
        "Daystar",
        "Radiance",
        "President",
        "Leader",
        "Executive",
        "Commander",
        "Head",
        "Chief",
        "Spider",
        "Witch",
        "Squirrel",
        "Robotics",
        "Moon",
        "Spacesuit",
        "Astronaut",
        "Rocketship",
        "Meteorite",
        "Alien",
        "Laser",
        "Jetpack",
        "Time Machine",
        "Galaxy",
        "Spaceship",
        "Asteroid",
        "Comet",
        "Black Hole",
        "Nebula",
        "Starship",
        "Supernova",
        "Constellation",
        "Spacecraft",
        "Exoplanet",
        "Extraterrestrial",
        "Astronomy",
        "Spacewalk",
        "Gravity",
        "Cosmos",
        "Satellite",
        "Telescope",
        "Solar System",
        "UFO",
        "Cosmonaut",
        "Orbit",
        "Interstellar",
        "Stellar",
        "Interplanetary",
        "Aurora",
        "Milky Way",
        "Big Bang",
        "Cosmic",
        "Astrology",
        "Astrophysics",
        "Space Shuttle",
        "Lunar",
        "Space Station",
        "Intergalactic",
        "Space Exploration",
        "Rocket Launch",
        "Celestial",
        "Space Probe",
        "Black Matter",
        "Space Odyssey",
        "Space Agency",
        "Space Travel",
        "Space Telescope",
        "Space Race",
        "Space Adventure",
        "Space Colony",
        "Space Mission",
        "Spacecraft",
        "Spaceport",
        "Spacewalk",
        "Stardust",
        "Spacewalk",
        "Stardust",
        "Electric Mouse",
        "Fire Lizard",
        "Train",
        "Locomotive",
        "Bullet",
        "Sponge",
        "Rainbow",
        "Jet Fighter",
        "Transforming Robot",
        "Ape",
        "Akita",
        "Beagle",
        "Corgi",
        "Dalmatian",
        "English Bulldog",
        "French Bulldog",
        "German Shepherd",
        "Husky",
        "Irish Setter",
        "Labrador Retriever",
        "Maltese",
        "Newfoundland",
        "Poodle",
        "Rottweiler",
        "Saint Bernard",
        "Shih Tzu",
        "Siberian Husky",
        "Tibetan Mastiff",
        "Vizsla",
        "Weimaraner",
        "Xoloitzcuintli",
        "Yorkshire Terrier",
        "Zuchon"
    ];

//    $nouns = [
//        "Dog", "Cat", "House", "Car", "Tree", "Book", "Table", "Chair", "Phone", "Computer",
//        "Door", "Window", "Sky", "Ocean", "Mountain", "River", "Sun", "Moon", "Star", "Bird",
//        "Fish", "Flower", "Garden", "Bridge", "Road", "Street", "City", "Country", "Planet", "Earth",
//        "Mars", "Jupiter", "Saturn", "Mercury", "Venus", "Uranus", "Neptune", "Pluto", "Apple", "Banana",
//        "Orange", "Grapes", "Strawberry", "Pineapple", "Watermelon", "Kiwi", "Lemon", "Lime", "Peach",
//        "Pear", "Cherry", "Apricot", "Mango", "Coconut", "Avocado", "Pomegranate", "Melon", "Blueberry",
//        "Raspberry", "Blackberry", "Cranberry", "Gooseberry", "Blackcurrant", "Fig", "Date", "Guava",
//        "Lychee", "Passionfruit", "Tangerine", "Plum", "Rhubarb", "Persimmon", "Nectarine", "Currant", "Quince",
//        "Penguin", "Elephant", "Lion", "Tiger", "Giraffe", "Bear", "Wolf", "Fox", "Rabbit", "Squirrel",
//        "Deer", "Zebra", "Kangaroo", "Monkey", "Gorilla", "Rhino", "Hippo", "Crocodile", "Alligator", "Turtle",
//        "Snake", "Lizard", "Frog", "Toad", "Bat", "Owl", "Eagle", "Hawk", "Falcon", "Seagull", "Duck",
//        "Goose", "Swan", "Pelican", "Pigeon", "Parrot", "Peacock", "Flamingo", "Sparrow", "Robin", "Bluejay",
//        "Cardinal", "Finch", "Canary", "Cockatoo", "Cheetah", "Leopard", "Panther", "Jaguar", "Hyena", "Dolphin",
//        "Whale", "Shark", "Octopus", "Squid", "Jellyfish", "Starfish", "Crab", "Lobster", "Shrimp", "Prawn",
//        "Bee", "Butterfly", "Dragonfly", "Ant", "Spider", "Scorpion", "Mosquito", "Fly", "Ladybug", "Beetle",
//        "Moth", "Caterpillar", "Grasshopper", "Cricket", "Wasp", "Hornet", "Cicada", "Firefly", "Centipede", "Millipede",
//        "Mantis", "Tarantula", "Panda", "Koala", "Walrus", "Seal", "Otter", "Alien", "Spaceship", "Robot", "Cyborg", "Laser", "Galaxy", "Exoplanet", "Teleportation", "Time machine", "Warp drive",
//        "Android", "Hologram", "Nanobot", "Clone", "Droid", "Stargate", "Hovercraft", "Alienware", "Raygun", "Forcefield",
//        "Hyperdrive", "Alien", "Spaceship", "Robot", "Cyborg", "Laser", "Galaxy", "Exoplanet", "Teleportation", "Time machine",
//        "Warp drive", "Android", "Hologram", "Nanobot", "Clone", "Droid", "Stargate", "Hovercraft", "Alienware", "Raygun",
//        "Forcefield", "Hyperdrive", "Alien", "Spaceship", "Robot", "Cyborg", "Laser","Dragon", "Wizard", "Elf", "Dwarf", "Sword", "Castle", "Magic", "Fairy", "Troll", "Knight",
//        "Unicorn", "Phoenix", "Goblin", "Mermaid", "Centaur", "Griffin", "Gargoyle", "Enchantment", "Wizardry", "Orc",
//        "Witch", "Giant", "Potion", "Scroll", "Sorcerer", "Mage", "Frost", "Fire", "Thunder", "Storm",
//        "Forest", "Mountain", "Valley", "Cave", "Treasure", "Adventure", "Quest", "Elixir", "Wand", "Crystal",
//        "Amulet", "Artifact", "Eagle", "Phoenix", "Kingdom", "Realm", "Map", "Compass", "Portal", "Scepter", "Druid", "Serpent", "Frostbite", "Grimoire", "Valkyrie", "Hydra", "Behemoth", "Chimera", "Labyrinth",
//        "Pegasus", "Direwolf", "Shadow", "Whisper", "Chalice", "Phoenix", "Falcon", "Fable", "Whimsy", "Fortune",
//        "Destiny", "Eclipse", "Oracle", "Mystic", "Wraith", "Crown", "Crescent", "Sable", "Wyvern", "Throne",
//        "Glacier", "Volcano", "Siren", "Aurora", "Harmony", "Symphony", "Rune", "Scepter", "Druid", "Serpent",
//        "Frostbite", "Grimoire", "Valkyrie", "Hydra", "Behemoth", "Chimera", "Labyrinth", "Car", "House", "Phone", "Computer", "Table", "Chair", "Book", "Dog", "Cat", "Tree",
//        "River", "Mountain", "Ocean", "Sun", "Moon", "Star", "Bird", "Fish", "Flower", "Garden",
//        "Street", "City", "Country", "Planet", "Sky", "Cloud", "Bridge", "Road", "Door", "Window",
//        "Desk", "Lamp", "Couch", "Pen", "Paper", "Bag", "Shoes", "Hat", "Shirt", "Pants", "Jacket",
//        "Socks", "Glasses", "Watch", "Wallet", "Key", "Knife", "Plate", "Cup", "Spoon", "Fork", "Bike", "Train", "Plane", "Boat", "Bus", "Truck", "Subway", "Motorcycle", "Helicopter", "Rocket",
//        "Building", "Apartment", "Streetlight", "Traffic", "School", "Hospital", "Library", "Park", "Beach", "Lake",
//        "Forest", "Camping", "Picnic", "Office", "Meeting", "Conference", "Presentation", "Event", "Concert", "Movie",
//        "Music", "Art", "Painting", "Sculpture", "Photograph", "Exhibition", "Restaurant", "Cafe", "Bar", "Grocery",
//        "Market", "Supermarket", "Shopping", "Mall", "Bank", "ATM", "Airport", "Station", "Hotel"
//    ];

    $nouns = [
        "Apple",
        "Banana",
        "Car",
        "Dog",
        "Elephant",
        "Fish",
        "Guitar",
        "House",
        "Ice Cream",
        "Jacket",
        "Kite",
        "Lamp",
        "Monkey",
        "Notebook",
        "Orange",
        "Piano",
        "Quilt",
        "Rain",
        "Sun",
        "Table",
        "Umbrella",
        "Violin",
        "Watch",
        "Xylophone",
        "Yacht",
        "Zebra",
        "Ball",
        "Cat",
        "Door",
        "Eagle",
        "Frog",
        "Globe",
        "Hat",
        "Ink",
        "Jug",
        "Kangaroo",
        "Lemon",
        "Mug",
        "Nest",
        "Octopus",
        "Penguin",
        "Queen",
        "Rose",
        "Socks",
        "Tree",
        "Umbrella",
        "Violin",
        "Whale",
        "Xylophone",
        "Yak",
        "Zoo",
        "Aeroplane",
        "Bicycle",
        "Car",
        "Dune Buggy",
        "Electric Scooter",
        "Ferry",
        "Glider",
        "Helicopter",
        "Icebreaker",
        "Jet",
        "Kayak",
        "Limo",
        "Moped",
        "Nautical",
        "Oar",
        "Plane",
        "Quad Bike",
        "Racing Car",
        "Sailboat",
        "Tank",
        "Unicycle",
        "Van",
        "Wagon",
        "X-Country Ski",
        "Yacht",
        "Zeppelin",
        "Barge",
        "Cable Car",
        "Dirt Bike",
        "E-Scooter",
        "Forklift",
        "Golf Cart",
        "Hovercraft",
        "Ice Skate",
        "Jet Ski",
        "Kart",
        "Lawnmower",
        "Monorail",
        "Off-Roader",
        "Pedal Boat",
        "Quadcopter",
        "Rudder",
        "Sedan",
        "Tandem Bike",
        "Unimog",
        "Vespa",
        "Windsurfer",
        "X-Ray Vehicle",
        "Yawl",
        "Zamboni",
        "Amulet",
        "Basilisk",
        "Centaur",
        "Dragon",
        "Elf",
        "Fairy",
        "Goblin",
        "Halfling",
        "Imp",
        "Jinn",
        "Kobold",
        "Lich",
        "Mermaid",
        "Necromancer",
        "Orc",
        "Phoenix",
        "Quasit",
        "Rogue",
        "Sorcerer",
        "Treant",
        "Unicorn",
        "Vampire",
        "Werewolf",
        "Xorn",
        "Yeti",
        "Zombie",
        "Beholder",
        "Chimera",
        "Druid",
        "Ettin",
        "Frost Giant",
        "Gargoyle",
        "Harpy",
        "Illithid",
        "Jabberwock",
        "Kraken",
        "Lamia",
        "Manticore",
        "Naga",
        "Owlbear",
        "Pegasus",
        "Quickling",
        "Rakshasa",
        "Sphinx",
        "Troll",
        "Umber Hulk",
        "Valkyrie",
        "Wraith",
        "Xorn",
        "Yeti",
        "Zaratan",
        "Android",
        "Bionic",
        "Cyborg",
        "Droid",
        "Exosuit",
        "Futuristic",
        "Galaxy",
        "Hologram",
        "Ion Cannon",
        "Laser",
        "Meteor",
        "Nanobot",
        "Orbital",
        "Photon",
        "Quantum",
        "Robot",
        "Spaceship",
        "Teleporter",
        "UFO",
        "Virtual Reality",
        "Warp Drive",
        "Zerg",
        "Alien",
        "Blaster",
        "Cybernetic",
        "Energy Sword",
        "Force Field",
        "Gravity Well",
        "Hyperlapse",
        "Interstellar",
        "Jetpack",
        "Kaiju",
        "Mind Control",
        "Nebula",
        "Omnitool",
        "Plasma Rifle",
        "Quantum Computer",
        "Replicant",
        "Stargate",
        "Time Machine",
        "Universal Translator",
        "Vortex Manipulator",
        "Wormhole",
        "X-Ray Vision",
        "Yttrium-powered",
        "Zap Gun",
        "Augmentation",
        "Bionics",
        "Cyberdeck",
        "Datajack",
        "Enhancement",
        "Firmware",
        "Gig",
        "Hacker",
        "Interface",
        "Killer",
        "Lifelog",
        "Matrix",
        "Neon",
        "Overlay",
        "Punk",
        "Quadrant",
        "Razor Girl",
        "Synth",
        "Transhuman",
        "Underground",
        "Virtuality",
        "Warez",
        "Xenon",
        "Yakuza",
        "Zero Day",
        "AI",
        "Black Market",
        "Cyberspace",
        "Dystopia",
        "Electro",
        "Firmware",
        "Grid",
        "Hacktivist",
        "Implant",
        "Junkyard",
        "Kaiju",
        "Limb",
        "Megacorp",
        "Nanotech",
        "Overclock",
        "Pulse",
        "Quantum",
        "Rebellion",
        "Street Samurai",
        "Tech",
        "Urban",
        "Virus",
        "Wetware",
        "Xenograft",
        "Yotta",
        "Zettabyte",
        "Monkey Butler",
        "Ninja Hedgehog",
        "Antelope",
        "Bear",
        "Cat",
        "Dog",
        "Elephant",
        "Fox",
        "Giraffe",
        "Horse",
        "Iguana",
        "Jaguar",
        "Kangaroo",
        "Lion",
        "Monkey",
        "Newt",
        "Octopus",
        "Penguin",
        "Quokka",
        "Rabbit",
        "Sheep",
        "Tiger",
        "Umbrellabird",
        "Vulture",
        "Walrus",
        "Xerus",
        "Yak",
        "Zebra",
        "Alpaca",
        "Bison",
        "Cheetah",
        "Dolphin",
        "Eagle",
        "Falcon",
        "Gorilla",
        "Hedgehog",
        "Ibex",
        "Jellyfish",
        "Koala",
        "Lemur",
        "Moose",
        "Nightingale",
        "Owl",
        "Panda",
        "Quail",
        "Raccoon",
        "Squirrel",
        "Toucan",
        "Uakari",
        "Viper",
        "Wolf",
        "X-ray Tetra",
        "Yabby",
        "Zebu",
        "Cape",
        "Dynamo",
        "Emblem",
        "Flash",
        "Gadget",
        "Hero",
        "Invisibility",
        "Justice",
        "Lair",
        "Mask",
        "Nemesis",
        "Origin",
        "Power",
        "Quiver",
        "Rescue",
        "Shield",
        "Tornado",
        "Utility Belt",
        "Villain",
        "Web",
        "X-ray Vision",
        "Yin",
        "Zap",
        "Artifact",
        "Costume",
        "Doomsday",
        "Energy",
        "Flight",
        "Gadget",
        "Heroine",
        "Inferno",
        "Jetpack",
        "Kick",
        "Lasso",
        "Mask",
        "Night",
        "Orbit",
        "Power",
        "Quasar",
        "Radiance",
        "Speed",
        "Teleportation",
        "Unity",
        "Wings",
        "Xenon",
        "Yield",
        "Zephyr",
        "President",
        "Creature",
        "Critter",
        "Beastie",
        "Monster",
        "Entity",
        "Fiend",
        "Minion",
        "Sprite",
        "Demon",
        "Spirit",
        "Mascot",
        "Familiar",
        "Pet",
        "Animal",
        "Companion",
        "Guardian",
        "Guardian Spirit",
        "Fey",
        "Apparition",
        "Phantom",
        "Wraith",
        "Specter",
        "Spectral Being",
        "Eidolon",
        "Shade",
        "Shapeshifter",
        "Chimera",
        "Hybrid",
        "Avatar",
        "Totem",
        "Divine Creature",
        "Ethereal Being",
        "Supernatural Being",
        "Mythical Creature",
        "Legendary Creature",
        "Spiritual Entity",
        "Magical Creature",
        "Enchanted Being",
        "Imaginary Creature",
        "Fantasy Creature",
        "Elemental",
        "Otherworldly Being",
        "Celestial Creature",
        "Arcane Being",
        "Mystical Being",
        "Shadow Being",
        "Dark Entity",
        "Light Being",
        "Mystical Entity",
        "Fabled Creature"
    ];

    $nouns += $nouns1;

    $components = [];

    // Ensure attribute values are within expected ranges
    $level = max(1, min($level, count($levelDescriptors)));
    $hpIndex = max(0, min(floor(($hp - 50) / 30), count($hpDescriptors) - 1));
    $attackIndex = max(0, min(floor(($attackStrength - 20) / 20), count($attackDescriptors) - 1));


    // Adjust the probability of including a proper noun to achieve the desired average name length
    $includeProperNoun = 4; // 25% chance of including a proper noun
//    $includeProperNoun = rand(0, 4); // 25% chance of including a proper noun

    if ($includeProperNoun === 0) {
        $properNames = ["Erik", "Robin", "Denise", "Jasmyne", "Klinton", "Bryant", "Lucas", "Tzar", "Alice", "Burt", "Bob", "Charlie", "Diana", "Eleanor", "Felix", "Grace", "Henry", "Isabelle", "Jack", "John", "Mary", "David", "Sarah", "Michael", "Emily", "Christopher", "Emma", "Daniel", "Olivia", "Matthew", "Sophia", "Andrew", "Ava", "James", "Isabella", "Joseph", "Mia", "William", "Charlotte", "Alexander", "Abigail", "Anthony", "Madison", "Nicholas", "Elizabeth", "Ryan", "Ella", "Joshua", "Grace", "Daniel", "Chloe", "Jonathan", "Natalie", "Samuel", "Lily", "Tyler", "Hannah", "Nathan", "Sofia", "Benjamin", "Avery", "Robert", "Amelia", "Brandon", "Evelyn", "Christian", "Victoria", "Gabriel", "Samantha", "Elijah", "Anna", "Cameron", "Aria", "Jackson", "Layla", "Kevin", "Scarlett", "Dylan", "Zoe", "Austin", "Alexa", "Logan", "Audrey", "Mason", "Aubrey", "Evan", "Brooklyn", "Caleb", "Claire", "Luke", "Riley", "Jason", "Leah", "Connor", "Mila", "Isaac", "Penelope", "Adam", "Stella", "Jack", "Lucy", "Owen", "Aurora", "Isaiah", "Savannah", "Jordan", "Aaliyah", "Julian", "Nora", "Hunter", "Addison", "Isabel", "Levi", "Skylar", "Nicholas", "Camila", "Carson", "Haley", "Charles", "Bella"];

        $expandedProperNames = [];
        for ($i = 0; $i < 10 * count($properNames); $i++) {
            $expandedProperNames[] = $properNames[$i % count($properNames)] . ($i / count($properNames));
        }

        $components[] = $properNames[array_rand($properNames)];
    } else {
        $adjectiveDescriptor = $adjectives[array_rand($adjectives)];
        $adjectiveDescriptor2 = $adjectives2[array_rand($adjectives2)];
        $noun = $adjectiveDescriptor2 . ' ' . $adjectiveDescriptor . ' ' . $nouns[array_rand($nouns)];
        $components[] = $noun;
    }

    // Select descriptors based on attributes
    $components[] = $levelDescriptors[$level - 1];
    $components[] = $hpDescriptors[$hpIndex];
    $components[] = $attackDescriptors[$attackIndex];

    // Join the name components and return
    $name = implode(" ", $components);

    return ['name' => $name, 'noun' => $noun];
}

$randomNumber = mt_rand(1, 100);
$borderRarity = 0;

switch (true) {
    case $randomNumber <= 60:
        $borderRarity = 0; // Common (60%)
        break;
    case $randomNumber <= 90:
        $borderRarity = 1; // Uncommon (30%)
        break;
    case $randomNumber <= 95:
        $borderRarity = 2; // Rare (15%)
        break;
    default:
        $borderRarity = 3; // Legendary (5%)
}


// Generate a random card
$randomCard = generateRandomCard($borderRarity);

// Prepare SQL statement with placeholders
$sql = "INSERT INTO trading_cards (name, level, hp, attack_strength, ability1, ability2, username,creator_id,owner_id,border_rarity,image_url,dustGenerated) VALUES (?, ?, ?, ?, ?, ?, ?,?,?,?,?,?)";

// Set the generated_by value (replace with actual user ID)
$generatedBy = $_SESSION['login_info'][0]['user_name'] . '#' . $_SESSION['login_info'][0]['id']; // For example, the ID of the user who generated the card
$generatedByID = $_SESSION['login_info'][0]['id']; // For example, the ID of the user who generated the card


// Prepare and bind parameters
$stmt = $conn->prepare($sql);
$stmt->bind_param("siiisssiiisi", $randomCard['shortname'], $randomCard['level'], $randomCard['hp'], $randomCard['attack_strength'], $randomCard['ability1'], $randomCard['ability2'], $generatedBy, $generatedByID, $generatedByID, $borderRarity, $randomCard['filepath'], $dustGenerated);


// Execute the statement
if ($stmt->execute()) {
//    echo 'New record created successfully<br /><a href="index.php">Return home.</a>';
    header('Location: dashboard.php?prompt=' . $randomCard['prompt']);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
