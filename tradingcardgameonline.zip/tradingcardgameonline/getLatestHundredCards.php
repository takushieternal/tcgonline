<?php
/**
 * Created by Bryant Frankford
 * nathanielfrankford@gmail.com
 * Date: 2/3/24
 * Time: 11:00 PM
 */

// Redirect to HTTPS if not already
if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

//// Start session
//session_start();
//
//// Redirect to index if not logged in
//if(!isset($_SESSION['login_info'])){
//    header("Location: index.php");
//    exit();
//}

// Database connection parameters
$servername = "localhost";
$username = "ijteuute_bryant";
$password = "f7qfxs[pEMy$";
$dbname = "ijteuute_tradingcardgameonline";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL statement with parameterized query
$sql =<<<EOQ
SELECT 
    users.user_name, 
    trading_cards.*, 
    COUNT(favorited_cards.id) AS like_count,
    MAX(CASE WHEN favorited_cards.user_id = ? THEN favorited_cards.toggle_status ELSE 0 END) AS user_favorite
FROM 
    trading_cards
LEFT JOIN 
    favorited_cards ON trading_cards.id = favorited_cards.favorited_card_id AND favorited_cards.toggle_status = 1
JOIN 
    users ON users.id = trading_cards.owner_id
WHERE 
    trading_cards.isDust = 0
GROUP BY 
    trading_cards.id
ORDER BY 
    trading_cards.id DESC
LIMIT 12;
EOQ;

// Prepare statement
$stmt = $conn->prepare($sql);

// Bind parameter
$stmt->bind_param("i", $_SESSION['login_info'][0]['id']);

// Execute statement
$stmt->execute();

// Get result
$result = $stmt->get_result();

// Initialize an array to store card data
$cardData = array();

// Check if there are results
if ($result->num_rows > 0) {
    // Loop through each row and add card data to the array
    while($row = $result->fetch_assoc()) {
        $cardData[] = array(
            "id" => $row["id"],
            "like_count" => $row["like_count"],
            "user_favorite" => $row["user_favorite"],
            "username" => $row["user_name"],
            "name" => $row["name"],
            "level" => $row["level"],
            "hp" => $row["hp"],
            "attack_strength" => $row["attack_strength"],
            "ability1" => $row["ability1"],
            "ability2" => $row["ability2"],
            "signature" => $row["username"],
            "borderRarity" => $row["border_rarity"],
            "image_url" => $row["image_url"],
            "was_purchased" => $row["was_purchased"],
            "owner_id" => $row["owner_id"],
            "experience" => $row["experience"],
            "user_favorite" => $row["user_favorite"] // Add user_favorite column
        );
    }
}

// Close statement
$stmt->close();

// Close MySQL connection
$conn->close();

// Convert the card data array to JSON format
$jsonData = json_encode($cardData);

// Output the JSON data
echo $jsonData;
?>
