<?php
    /**
     * Created by Bryant Frankford
     * nathanielfrankford@gmail.com
     * Date: 2/3/24
     * Time: 11:00 PM
     * To change this template use File | Settings | File Templates.
     */
    if($_SERVER["HTTPS"] != "on")
    {
        header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
        exit();
    }

    session_start();

    if(!isset($_SESSION['login_info'])){
        header("Location: index.php");
        die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secret Mini Game!</title>
    <link rel="stylesheet" href="css/flappyCard.css">
</head>
<body>
<div id="game-container">
    <div id="bird"></div>
    <div id="pipe-top" class="pipe pipe-top"></div>
    <div id="pipe-bottom" class="pipe pipe-bottom"></div>
    <div id="counter-container">
        <div id="counter">0</div>
        <button id="reset-btn">Reset Game</button>
    </div>
</div>

<script src="js/jquery.js"></script>
<script src="js/flappyCard.js"></script>
</body>
</html>
