<?php
include 'db.php';

// Check if cardId is provided in the POST data
if (isset($_POST['cardId'])) {
    // Get card information based on the cardId
    $cardId = $_POST['cardId'];
    $card = executeSelectQuery("SELECT id, name FROM trading_cards WHERE id = ?", [$cardId]);

    if ($card) {
        // For demonstration purposes, let's assume the user has a default deck with deckId = 1
        $deckId = 1;

        // Insert the card into the deck
        $success = executeNonQuery("INSERT INTO deck_cards (deck_id, card_id) VALUES (?, ?)", [$deckId, $cardId]);

        if ($success) {
            // Return the card information as JSON
            echo json_encode($card);
        } else {
            echo "Failed to add the card to the deck.";
        }
    } else {
        echo "Card not found.";
    }
} else {
    echo "Card ID not provided.";
}
?>
