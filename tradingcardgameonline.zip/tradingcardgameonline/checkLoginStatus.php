<?php
session_start();

// Establish a connection to the database (include your existing connection code here)

// Function to check if the user is logged in
function checkLoggedIn() {
    if (isset($_SESSION['login_info']) && $_SESSION['login_info'] == true) {
        return 1;
    } else {
        return 0;
    }
}

// Check if the user is logged in and return the result
echo checkLoggedIn();
?>
