<?php
session_start();
require_once 'db.php';
include 'cardDraw.php';

// Function to get the latest relevant game state for a player
function getLatestRelevantGameState($player_id) {
    global $dbo;
    $sql = "SELECT gs.game_id, gs.has_drawn_card, gs.winner_id, gs.player1_id, gs.player2_id, gs.game_id,
               IF(gs.player1_id = :player_id, gs.player1_hand, gs.player2_hand) AS player_hand,
               IF(gs.player1_id = :player_id, gs.player1_section, gs.player2_section) AS section,
               IF(gs.player1_id = :player_id, gs.player1_discard, gs.player2_discard) AS discard,
               IF(gs.player1_id = :player_id, gs.player2_discard, gs.player1_discard) AS opponent_discard,
               gs.turn,
               JSON_LENGTH(gs.player1_hand) AS player_hand_count,
               JSON_LENGTH(gs.player1_deck) AS player_deck_count,
               JSON_LENGTH(gs.player2_hand) AS opponent_hand_count,
               JSON_LENGTH(gs.player2_deck) AS opponent_deck_count,
               gs.game_status,
               gs.last_updated,
               CASE
                   WHEN :player_id = gs.player1_id THEN gs.player2_id
                   ELSE gs.player1_id
               END AS other_player_id,
               u1.user_name AS player1_name,
               u2.user_name AS player2_name,
               CASE
                   WHEN gs.turn = gs.player1_id THEN u1.user_name
                   ELSE u2.user_name
               END AS current_turn_user_name
        FROM game_state gs
        LEFT JOIN users u1 ON gs.player1_id = u1.id
        LEFT JOIN users u2 ON gs.player2_id = u2.id
        WHERE gs.player1_id = :player_id OR gs.player2_id = :player_id
        ORDER BY gs.last_updated DESC
        LIMIT 1";

    $params = array(':player_id' => $player_id);
    $gameState = executeSelectQuery($sql, $params);

    return $gameState ? $gameState[0] : null;
}

// Function to draw a card for the current player
function drawCardForCurrentPlayer($game_id, $player_id) {
    // Fetch the latest relevant game state using the provided player ID
    $latestGameState = getLatestRelevantGameState($player_id);

    // Ensure game state exists
    if ($latestGameState) {
        // Fetch the current player's ID from game state
        $current_player_turn = $latestGameState['turn'];

        // Draw a card for the current player
        if ($current_player_turn == $latestGameState['player1_id']) {
            drawCardForPlayer1($game_id);
        } elseif ($current_player_turn == $latestGameState['player2_id']) {
            drawCardForPlayer2($game_id);
        }
    }
}

// Function to get the current player's turn from game_state
function getCurrentPlayerTurn($game_id) {
    // Fetch the turn from game_state
    global $dbo;
    $sql = "SELECT turn FROM game_state WHERE game_id = :game_id";
    $params = array(':game_id' => $game_id);
    $result = executeSelectQuery($sql, $params);
    if (!empty($result)) {
        return $result[0]['turn'];
    } else {
        return null;
    }
}

// Main code execution starts here
if (isset($_SESSION['login_info'])) {
    // Get the player's ID from session
    $player_id = $_SESSION['login_info'][0]['id'];

    // Get the latest relevant game state for the player
    $latestGameState = getLatestRelevantGameState($player_id);

    // Check if the game state exists
    if ($latestGameState) {
        // Check if the turn needs to be toggled
        $newTurn = ($latestGameState['turn'] == $latestGameState['player1_id']) ? $latestGameState['player2_id'] : $latestGameState['player1_id'];

        // Get the current timestamp
        $currentTimestamp = time();

        // Check if the last updated time is within the past 180 seconds
        $lastUpdatedTimestamp = strtotime($latestGameState['last_updated']);
        if (($currentTimestamp - $lastUpdatedTimestamp) >= 180) {
            // Update the turn in the database
            $sql = "UPDATE game_state SET turn = :new_turn WHERE game_id = :game_id";
            $params = array(':new_turn' => $newTurn, ':game_id' => $latestGameState['game_id']);
            executeNonQuery($sql, $params);

            // Draw a card for the current player
            drawCardForCurrentPlayer($latestGameState['game_id'], $player_id);

            // Update the 'last_updated' timestamp
            $sql = "UPDATE game_state SET last_updated = CURRENT_TIMESTAMP WHERE game_id = :game_id";
            $params = array(':game_id' => $latestGameState['game_id']);
            executeNonQuery($sql, $params);
        }

        // Fetch the updated game state
        $updatedGameState = getLatestRelevantGameState($_SESSION['login_info'][0]['id']);

        // Send the updated game state as JSON response
        echo json_encode($updatedGameState);

    } else {
        // If no game state is found, send an error response
        echo json_encode(array('error' => 'No game state found.'));
    }
} else {
    // If session login info does not exist, send an error response
    echo json_encode(array('error' => 'User not authenticated.'));
}
?>
