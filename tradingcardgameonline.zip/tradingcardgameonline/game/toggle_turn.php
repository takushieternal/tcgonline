<?php
session_start();
require_once 'db.php';

include 'cardDraw.php';

$gameId = $_POST['game_id'];

// Function to draw a card for the current player
function drawCardForCurrentPlayer($game_id, $current_player_id, $player1_id, $player2_id) {
    // Fetch the current player's ID from game_state
    $current_player_turn = getCurrentPlayerTurn($game_id);

    // Draw a card for the current player
    if ($current_player_turn == $player1_id) {
        drawCardForPlayer2($game_id);
    } elseif ($current_player_turn == $player2_id) {
        drawCardForPlayer1($game_id);
    } else {
        return "Invalid player ID.";
    }
}

// Function to get the current player's turn from game_state
function getCurrentPlayerTurn($game_id) {
    // Fetch the turn from game_state
    global $dbo;
    $sql = "SELECT turn FROM game_state WHERE game_id = :game_id";
    $params = array(':game_id' => $game_id);
    $result = executeSelectQuery($sql, $params);
    if (!empty($result)) {
        return $result[0]['turn'];
    } else {
        return null;
    }
}

// Check if session login info exists
if (isset($_SESSION['login_info'])) {
    // Get the player's ID from session
    $playerId = $_SESSION['login_info'][0]['id'];

// Fetch the game state from the database based on game_id
    $sql = "SELECT game_id, turn, player1_id, player2_id FROM game_state WHERE game_id = :game_id";
    $params = array(':game_id' => $gameId);
    $gameState = executeSelectQuery($sql, $params);

    // Check if game state exists
    if ($gameState) {
        $gameId = $gameState[0]['game_id'];
        $currentTurn = $gameState[0]['turn'];
        $player1Id = $gameState[0]['player1_id'];
        $player2Id = $gameState[0]['player2_id'];

        // Check if it's the player's turn
        if ($currentTurn == $playerId) {
            // Toggle the turn to the other player
            // Example usage:
            $currentPlayerId = $_SESSION['login_info'][0]['id']; // Assuming you have the current player's ID stored in session

            drawCardForCurrentPlayer($gameId, $currentPlayerId, $player1Id, $player2Id);

            $newTurn = ($playerId == $player1Id) ? $player2Id : $player1Id;

            // Update the turn in the database
            $sql = "UPDATE game_state SET turn = :new_turn, has_drawn_card = 0, last_updated = CURRENT_TIMESTAMP WHERE game_id = :game_id";
            $params = array(':new_turn' => $newTurn, ':game_id' => $gameId);
            executeNonQuery($sql, $params);

            // Return success message
//            echo "Turn toggled successfully.";
        } else {
            // Return message indicating it's not the player's turn
            echo "It's not your turn.";
        }
    } else {
        // Return error message if no game state found
        echo "No game state found.";
    }
} else {
    // Return error message if user not authenticated
    echo "User not authenticated.";
}
?>