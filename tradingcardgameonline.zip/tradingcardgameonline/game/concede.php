<?php
session_start();
require_once 'db.php';

// Check if the user is authenticated
if (isset($_SESSION['login_info'])) {
    // Get the user ID
    $userId = $_SESSION['login_info'][0]['id'];

    // Check if the game ID is provided in the POST request
    if (isset($_POST['game_id'])) {
        // Get the game ID from the POST request
        $gameId = $_POST['game_id'];

        // Retrieve the game state from the database
        $sql = "SELECT player1_id, player2_id FROM game_state WHERE game_id = :game_id";
        $params = array(':game_id' => $gameId);
        $gameState = executeSelectQuery($sql, $params);

        // Check if the game state exists
        if ($gameState) {
            // Determine the opponent ID
            $opponentId = ($gameState[0]['player1_id'] == $userId) ? $gameState[0]['player2_id'] : $gameState[0]['player1_id'];

            // Update game state to mark the opponent as the winner
            $sql = "UPDATE game_state SET winner_id = :opponent_id, game_status = 'completed' WHERE game_id = :game_id AND (player1_id = :opponent_id OR player2_id = :opponent_id)";
            $params = array(':opponent_id' => $opponentId, ':game_id' => $gameId);
            executeNonQuery($sql, $params);

            // Send success response
            echo "Game conceded successfully. Opponent is the winner.";
        } else {
            // Send error response if game state is not found
            echo "Failed to concede game. Game state not found.";
        }
    } else {
        // Send error response if game ID is not provided
        echo "Failed to concede game. Game ID is missing.";
    }
} else {
    // Send error response if user is not authenticated
    echo "Failed to concede game. User not authenticated.";
}
?>
