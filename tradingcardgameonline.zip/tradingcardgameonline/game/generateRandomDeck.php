<?php
require_once 'db.php';

// Function to get 30 random card IDs from the trading_cards table
function getRandomCardIds() {
    global $dbo;
    $sql = "SELECT id FROM trading_cards ORDER BY RAND() LIMIT 30";
    $cardIds = executeSelectQuery($sql);
    return $cardIds;
}

// Function to insert the deck list into the card_decks table
function insertDeckList($cardIds) {
    global $dbo;
    // Convert the card IDs into an array
    $cardIdArray = array_column($cardIds, 'id');
    // Convert the array into JSON format
    $deckListJson = json_encode($cardIdArray);
    // Insert the deck list into the card_decks table
    $sql = "INSERT INTO card_decks (deck_list, owner_id) VALUES (:deck_list, 2)";
    $params = array(':deck_list' => $deckListJson);
    executeNonQuery($sql, $params);
}

// Get 30 random card IDs
$randomCardIds = getRandomCardIds();

// Insert the deck list into the card_decks table
insertDeckList($randomCardIds);

echo "Deck list inserted successfully.";
?>
