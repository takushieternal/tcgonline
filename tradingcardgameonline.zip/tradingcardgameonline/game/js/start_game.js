$(document).ready(function () {
    var counter = 0;
    var turnCounter = 30;
    var gameOver = true;

    function updateGame() {
        $('#headTitle').html('Game - ' + counter * 5 + ' Seconds');
        if (gameOver) {
            getLatestGameState();
        }
    }

    function concedeGame(gameId) {
        // Confirmation dialog to confirm conceding the game
        var confirmation = confirm("Are you sure you want to concede the game?");

        // If user confirms, proceed with conceding the game
        if (confirmation) {
            // AJAX POST request to concede.php
            $.post("concede.php", { game_id:gameId }, function (data, status) {
                // Check if request was successful
                if (status === "success") {
                    // Display response from concede.php
                    alert(data);
                } else {
                    // If request fails, display error message
                    alert("Failed to concede game.");
                }
            });
        }
    }

    $(document).on('click', '#concedeButton', function () {
        var gameId = $('body').attr('data-game_id');
        concedeGame(gameId);
        getLatestGameState();
    });

    $(document).on('click', '#passTurnButton', function () {
        toggleTurn();
        getLatestGameState();
    });

    // Function to toggle turn
    function toggleTurn() {
        var gameId = $('body').attr('data-game_id');

        // AJAX post request to toggle_turn.php
        $.post("toggle_turn.php", {game_id:gameId}, function (data, status) {
            // Check if the request is successful
            if (status === "success") {
                // Display the response message
                if (data) {
                    alert(data);
                }
            } else {
                // Display an error message if the request fails
                alert("Failed to toggle turn.");
            }
        });
    }

    // Function to fetch card data
    function fetchCardData(cardId) {
        console.log('Fetching: '+cardId);

        $.get("../GetCardById.php?cardid=" + cardId, function(data, status) {
            // Check if the request is successful
            if (status === "success") {
                // Parse the JSON data received from the server
                var cardData = JSON.parse(data);

                // Output the card data to the screen
                if (cardData.length > 0) {
                    // Loop through each card data and display it
                    $.each(cardData, function(index, card) {
                        $('#displayCardBox').append("<div>ID: " + card.id + "<br>Name: " + card.name + "<br>Username: " + card.username + "</div><br>");
                    });
                } else {
                    $('#displayCardBox').text("No card data found for the specified ID.");
                }
            } else {
                // Display an error message if the request fails
                $('#displayCardBox').text("Failed to fetch card data.");
            }
        });
    }

    // Function to ping the server for the latest game state
    function getLatestGameState() {
        counter++;
        // AJAX post request to get_game_state.php
        $.post("get_game_state.php", function (data, status) {
            // Check if the request is successful
            if (status === "success") {
                // Parse the JSON response
                var gameState = JSON.parse(data);
                // Check if game state exists
                if (gameState) {
                    if (gameState['winner_id'] === null) {
                        console.log("No winner");
                    } else {
                        // Do something if myVariable is not null
                        console.log("Winner found");

                        var victoryStatus = '';

                        if (gameState['winner_id'] == gameState['other_player_id']) {
                            //loser
                            victoryStatus = 'Defeated';
                        } else {
                            //winner
                            victoryStatus = 'Victory';
                        }

                        $('body').append('<div class="victoryStatus">' + victoryStatus + "</div>")
                        gameOver = false;
                    }
                    // Display game state data
                    console.log(gameState);
                    $('#cardHandBox').html(gameState['player_hand']);

                    if ($('body').attr('data-playerHand') !== gameState['player_hand']) {
                        $('body').attr('data-playerHand', gameState['player_hand']);

                        var playerHand = gameState['player_hand'];

                        // Convert playerHand to an array if it's not already one
                        if (!Array.isArray(playerHand)) {
                            playerHand = [playerHand];
                        }

                        $.each(playerHand, function (index, value) {
                            $('#displayCardBox').empty();
                            $.each(JSON.parse(value), function (index, element) {
                                // Perform operations on each element
                                fetchCardData(element);
                            });

                        });

                    }

                    $('body').attr('data-currentTurn', gameState['turn']);
                    $('body').attr('data-game_id', gameState['game_id']);
                    $('#turnName').html('Turn: ' + gameState['current_turn_user_name']);

                    // Update UI with game state data
                    // For example:
                    // $("#turn").text("Turn: " + gameState.turn);
                } else {
                    console.log("No game state found.");
                }
            } else {
                console.log("Failed to retrieve game state.");
            }
        });
    }

    // Call the function initially
    getLatestGameState();
    // Poll the server every 5 seconds for the latest game state
    setInterval(updateGame, 4000); // Corrected function call


});
