<?php
require_once 'db.php'; // Include the database connection file

// Function to shuffle the JSON array in player1_deck
function shufflePlayer1Deck($game_id) {
    global $dbo;

    // Fetch player1_deck from game_state
    $player1_deck = getPlayerDeckFromGameState2($game_id, 'player1');

    // Shuffle the PHP array
    shuffle($player1_deck);

    // Convert the shuffled PHP array back to a JSON string
    $shuffled_json = json_encode($player1_deck);

    // Update game_state with the shuffled player1_deck
    updatePlayerDeckInGameState($game_id, $shuffled_json, 'player1');
}

// Function to shuffle the JSON array in player2_deck
function shufflePlayer2Deck($game_id) {
    global $dbo;

    // Fetch player2_deck from game_state
    $player2_deck = getPlayerDeckFromGameState2($game_id, 'player2');

    // Shuffle the PHP array
    shuffle($player2_deck);

    // Convert the shuffled PHP array back to a JSON string
    $shuffled_json = json_encode($player2_deck);

    // Update game_state with the shuffled player2_deck
    updatePlayerDeckInGameState($game_id, $shuffled_json, 'player2');
}

// Function to fetch player deck from game_state based on game_id and player
function getPlayerDeckFromGameState2($game_id, $player) {
    global $dbo;
    $deck_column = $player . '_deck';

    // Prepare the SQL query
    $sql = "SELECT $deck_column FROM game_state WHERE game_id = :game_id";

    // Prepare the statement
    $stmt = $dbo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':game_id', $game_id, PDO::PARAM_STR);

    // Execute the query
    $stmt->execute();

    // Fetch the result
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if result is not empty and return the player deck as a PHP array
    if (!empty($result[$deck_column])) {
        return json_decode($result[$deck_column], true);
    } else {
        return array();
    }
}

// Function to update game_state with new deck_list based on player_id
function updatePlayerDeckInGameState($game_id, $deck_list_json, $player) {
    global $dbo;
    $deck_column = $player . '_deck';

    // Prepare the SQL query
    $sql = "UPDATE game_state SET $deck_column = :deck_list WHERE game_id = :game_id";

    // Prepare the statement
    $stmt = $dbo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':deck_list', $deck_list_json, PDO::PARAM_STR);
    $stmt->bindParam(':game_id', $game_id, PDO::PARAM_STR);

    // Execute the query
    $stmt->execute();
}

//// Example usage:
//$game_id = "your_game_id_here";
//
//// Call the function to shuffle player1_deck
//shufflePlayer1Deck($game_id);
//
//// Call the function to shuffle player2_deck
//shufflePlayer2Deck($game_id);
?>
