<?php
if ($_SERVER["HTTPS"] != "on") {
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

if (!isset($_SESSION['login_info'])) {
    header("Location: ../index.php");
    exit(); // Stop further execution
}

require_once 'db.php'; // Include the database connection file
include 'cardDraw.php';
include 'shuffleDeckLogic.php';

// Function to create a new game state
function createNewGameState($player_id) {
    global $dbo;
    $sql = "INSERT INTO game_state (game_id, player1_id, turn, game_status) VALUES (:game_id, :player_id, :turn, :game_status)";
    $game_id = uniqid(); // Generate a unique game ID
    $turn = 0; // Set the initial turn to 0
    $game_status = 'ongoing'; // Set the game status to ongoing
    $params = array(':game_id' => $game_id, ':player_id' => $player_id, ':turn' => $turn, ':game_status' => $game_status);
    return executeNonQuery($sql, $params);
}

// Function to update an existing game state with player2_id and set initial turn
function updateGameState($player_id, $game_id) {
    global $dbo;
    // Select a random player id for initial turn
    $initial_turn_player_id = rand(0, 1) === 0 ? $player_id : getOtherPlayerId($game_id, $player_id);
    $sql = "UPDATE game_state SET player2_id = :player_id, turn = :initial_turn_player_id, last_updated = CURRENT_TIMESTAMP WHERE game_id = :game_id AND game_status = 'ongoing'";
    $params = array(':player_id' => $player_id, ':initial_turn_player_id' => $initial_turn_player_id, ':game_id' => $game_id);
    return executeNonQuery($sql, $params);
}

// Function to get the id of the other player in the game
function getOtherPlayerId($game_id, $player_id) {
    global $dbo;
    $sql = "SELECT player1_id, player2_id FROM game_state WHERE game_id = :game_id";
    $params = array(':game_id' => $game_id);
    $result = executeSelectQuery($sql, $params);
    if (!empty($result)) {
        return ($result[0]['player1_id'] == $player_id) ? $result[0]['player2_id'] : $result[0]['player1_id'];
    }
    return null;
}

// Function to check if a game state exists with empty player2_id and different player1_id
function findGameWithEmptyPlayer2($player_id) {
    global $dbo;
    $sql = "SELECT * FROM game_state WHERE player2_id IS NULL AND player1_id != :player_id AND game_status = 'ongoing' LIMIT 1";
    $params = array(':player_id' => $player_id);
    return executeSelectQuery($sql, $params);
}

// Function to check if player 1 or player 2 already exists in any ongoing game state
function findPlayerExistingGame($player_id) {
    global $dbo;
    $sql = "SELECT * FROM game_state WHERE (player1_id = :player_id OR player2_id = :player_id) AND game_status = 'ongoing' LIMIT 1";
    $params = array(':player_id' => $player_id);
    return executeSelectQuery($sql, $params);
}

// Function to fetch deck_list by owner_id from card_decks
function getDeckListByOwnerId($owner_id) {
    global $dbo;
    $sql = "SELECT deck_list FROM card_decks WHERE owner_id = :owner_id";
    $params = array(':owner_id' => $owner_id);
    $result = executeSelectQuery($sql, $params);
    return !empty($result) ? $result[0]['deck_list'] : null;
}

// Function to update game state with player's deck_list
function updateGameStateDeckList($game_id, $player_id, $deck_list) {
    global $dbo;
    $deck_column = ($player_id == 1) ? 'player1_deck' : 'player2_deck';
    $sql = "UPDATE game_state SET $deck_column = :deck_list WHERE game_id = :game_id";
    $params = array(':deck_list' => $deck_list, ':game_id' => $game_id);
    return executeNonQuery($sql, $params);
}

// Get the player's ID from the session
$player_id = $_SESSION['login_info'][0]['id'];

// Check if player 1 or player 2 is already in any ongoing game state
$existing_game = findPlayerExistingGame($player_id);

if (!empty($existing_game)) {
    // If player 1 or player 2 is already in an ongoing game state, don't create a new game
    echo "Player rejoined an existing game!";
} else {
    // Check if there's any game missing player2_id or if Player 1 or Player 2 is rejoining a game
    $missing_game = findGameWithEmptyPlayer2($player_id);

    if (!empty($missing_game)) {
        // If a game is missing player2_id, join that game as Player 2
        $game_id = $missing_game[0]['game_id'];
        $update_result = updateGameState($player_id, $game_id);
        if ($update_result) {
            echo "Joined as Player 2 successfully!";
            // Fetch deck_list from card_decks for both players
            $player1_deck_list = getDeckListByOwnerId($_SESSION['login_info'][0]['id']);
            $player2_deck_list = getDeckListByOwnerId($missing_game[0]['player1_id']);
            // Update game state with both players' deck_lists
            $update_player1_result = updateGameStateDeckList($game_id, 1, $player1_deck_list);
            $update_player2_result = updateGameStateDeckList($game_id, 2, $player2_deck_list);

            //Shuffle Decks before drawing cards
            shufflePlayer1Deck($game_id);
            shufflePlayer2Deck($game_id);

            for ($i = 0; $i < 5; $i++) {
                // Loop body
                drawCardForPlayer1($game_id);
                drawCardForPlayer2($game_id);
            }

            if ($update_player1_result && $update_player2_result) {
                echo "Both players' deck lists updated successfully!";
            } else {
                echo "Failed to update both players' deck lists.";
            }
        } else {
            echo "Failed to join as Player 2.";
        }
    } else {
        // If no game is missing player2_id, create a new game state with player 1's ID
        $create_result = createNewGameState($player_id);
        if ($create_result) {
            echo "New game created successfully!";
        } else {
            echo "Failed to create a new game.";
        }
    }
}
?>
<html>
<head>
    <title id="headTitle">
        Game
    </title>
    <link rel="stylesheet" href="css/start_game.css">

    <script src="js/jquery.js"></script>
    <script src="js/start_game.js"></script>
</head>
<body data-currentTurn="">
<div id="turnInfo">
    <div id="turnCounter"></div>
    <div id="turnName"></div>
    <div id="passTurnButton" class="pushButtons">Pass Turn</div>
    <div id="concedeButton" class="pushButtons">Concede Game</div>
    <div id="cardHandBox"></div>
</div>
<div id="displayCardBox"></div>
</body>
</html>