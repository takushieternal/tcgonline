<?php
require_once 'db.php'; // Include the database connection file

// Function to get player1_id from game_state
function getPlayer2Id($game_id) {
    global $dbo;
    $sql = "SELECT player2_id FROM game_state WHERE game_id = :game_id";
    $stmt = $dbo->prepare($sql);
    $stmt->bindParam(':game_id', $game_id, PDO::PARAM_STR);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['player2_id'];
}

function getPlayer1Id($game_id) {
    global $dbo;
    $sql = "SELECT player1_id FROM game_state WHERE game_id = :game_id";
    $stmt = $dbo->prepare($sql);
    $stmt->bindParam(':game_id', $game_id, PDO::PARAM_STR);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['player1_id'];
}

// Function to draw a card from player1_deck and put it into player1_hand
function drawCardForPlayer1($game_id)
{
    // Fetch player1_deck from game_state
    $player1_deck = getPlayerDeckFromGameState($game_id, 'player1');
    // Fetch player1_hand from game_state
    $player1_hand = getPlayerHandFromGameState($game_id, 'player1');


    if (!empty($player1_deck)) {
        // Draw a card from player1_deck
        $card = array_shift($player1_deck);
        array_push($player1_hand, $card);

        // Update game_state with the new player1_deck and player1_hand
        updateGameStateDeckAndHand($game_id, $player1_deck, $player1_hand, 'player1');

        return $card;
    } else {

        // Get the game ID from the POST request
        $gameId = $game_id;

        // Retrieve the game state from the database
        $sql = "SELECT player1_id, player2_id FROM game_state WHERE game_id = :game_id";
        $params = array(':game_id' => $gameId);
        $gameState = executeSelectQuery($sql, $params);

        // Check if the game state exists
        if ($gameState) {
            // Determine the opponent ID
            $player2_id = getPlayer2Id($gameId);
            $opponentId = ($gameState[0]['player1_id'] == $_SESSION['login_info'][0]['id']) ? $gameState[0]['player2_id'] : $gameState[0]['player1_id'];

            // Update game state to mark the opponent as the winner
            $sql = "UPDATE game_state SET winner_id = :opponent_id, game_status = 'completed' WHERE game_id = :game_id AND (player1_id = :opponent_id OR player2_id = :opponent_id)";
            $params = array(':opponent_id' => $player2_id, ':game_id' => $gameId);
            executeNonQuery($sql, $params);

            // Send success response
//            echo "Game conceded successfully. Opponent is the winner.";
        } else {
            // Send error response if game state is not found
            echo "Failed to concede game. Game state not found.";
        }
        return "Cannot draw more cards from player1_deck. It's empty.";

    }
}

// Function to draw a card from player2_deck and put it into player2_hand
function drawCardForPlayer2($game_id)
{
    // Fetch player2_deck from game_state
    $player2_deck = getPlayerDeckFromGameState($game_id, 'player2');
    // Fetch player2_hand from game_state
    $player2_hand = getPlayerHandFromGameState($game_id, 'player2');

    if (!empty($player2_deck)) {
        // Draw a card from player2_deck
        $card = array_shift($player2_deck);
        // Put the drawn card into player2_hand
        array_push($player2_hand, $card);
        // Update game_state with the new player2_deck and player2_hand
        updateGameStateDeckAndHand($game_id, $player2_deck, $player2_hand, 'player2');
        return $card;
    } else {
        // Get the game ID from the POST request
        $gameId = $game_id;

        // Retrieve the game state from the database
        $sql = "SELECT player1_id, player2_id FROM game_state WHERE game_id = :game_id";
        $params = array(':game_id' => $gameId);
        $gameState = executeSelectQuery($sql, $params);

        // Check if the game state exists
        if ($gameState) {
            // Determine the opponent ID
            $player1_id = getPlayer1Id($gameId);
//            $opponentId = ($gameState[0]['player1_id'] == $_SESSION['login_info'][0]['id']) ? $gameState[0]['player2_id'] : $gameState[0]['player1_id'];

            // Update game state to mark the opponent as the winner
            $sql = "UPDATE game_state SET winner_id = :opponent_id, game_status = 'completed' WHERE game_id = :game_id AND (player1_id = :opponent_id OR player2_id = :opponent_id)";
            $params = array(':opponent_id' => $player1_id, ':game_id' => $gameId);
            executeNonQuery($sql, $params);

            // Send success response
//            echo "Game conceded successfully. Opponent is the winner.";
        } else {
            // Send error response if game state is not found
            echo "Failed to concede game. Game state not found.";
        }

        return "Cannot draw more cards from player2_deck. It's empty.";
    }
}


// Function to fetch player deck from game_state based on game_id and player
function getPlayerDeckFromGameState($game_id, $player)
{
    global $dbo;
    $deck_column = $player . '_deck';

    // Prepare the SQL query
    $sql = "SELECT $deck_column FROM game_state WHERE game_id = :game_id";

    // Prepare the statement
    $stmt = $dbo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':game_id', $game_id, PDO::PARAM_STR);

    // Execute the query
    $stmt->execute();

    // Fetch the result
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if result is not empty and return the player deck
    if (!empty($result[$deck_column])) {
        return json_decode($result[$deck_column], true);
    } else {
        return null;
    }
}

// Function to fetch player hand from game_state based on game_id and player
function getPlayerHandFromGameState($game_id, $player)
{
    global $dbo;
    $hand_column = $player . '_hand';

    // Prepare the SQL query
    $sql = "SELECT $hand_column FROM game_state WHERE game_id = :game_id";

    // Prepare the statement
    $stmt = $dbo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':game_id', $game_id, PDO::PARAM_STR);

    // Execute the query
    $stmt->execute();

    // Fetch the result
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if result is not empty and return the player hand
    if (!empty($result[$hand_column])) {
        return json_decode($result[$hand_column], true);
    } else {
        return array();
    }
}


// Function to update game_state with new deck_list and hand_list based on player_id
function updateGameStateDeckAndHand($game_id, $deck_list, $hand_list, $player)
{
    global $dbo;
    $deck_column = $player . '_deck';
    $hand_column = $player . '_hand';

    $sql = "UPDATE game_state SET $deck_column = :deck_list, $hand_column = :hand_list WHERE game_id = :game_id";
    $params = array(':deck_list' => json_encode($deck_list), ':hand_list' => json_encode($hand_list), ':game_id' => $game_id);
    return executeNonQuery($sql, $params);
}


?>
