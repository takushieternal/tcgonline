$(document).ready(function() {
    // Use event delegation to capture dynamically added elements
    console.log('index.js loaded');

    $(document).on('submit', '.loginForm', function(event) {
        event.preventDefault(); // Prevent the default form submission
        console.log(event);

        // Execute reCAPTCHA verification
        grecaptcha.enterprise.ready(function() {
            grecaptcha.enterprise.execute('6LcvWGwpAAAAAE9o5Z4sk8CVJgtwKoXupmjdf_NU', { action: 'login' })
                .then(function(token) {
                    // Once reCAPTCHA verification is successful, submit the form
                    $('.loginForm')[0].submit();
                })
                .catch(function(error) {
                    console.error('reCAPTCHA verification failed:', error);
                    // Handle reCAPTCHA verification failure
                });
        });
    });
});