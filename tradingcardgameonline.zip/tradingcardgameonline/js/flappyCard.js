$(document).ready(function() {
    var gravity = 0.5;
    var velocity = 0;
    var lift = -10;
    var bird = $('#bird');
    var gameContainer = $('#game-container');
    var counter = $('#counter');
    var resetButton = $('#reset-btn');
    var jumpCount = 0;
    var gameLoop;
    var gameOver = false;
    var pipeInterval = 10000; // Interval in milliseconds between each new pipe
    var lastPipeTime = 0;

    function flap() {
        if (!gameOver) {
            velocity += lift;
            jumpCount++;
            counter.text(jumpCount);
        }
    }

    function update() {
        if (!gameOver) {
            velocity += gravity;
            bird.css('top', bird.position().top + velocity + 'px');

            if (bird.position().top < 0 || bird.position().top + bird.height() > gameContainer.height()) {
                // Game over
                clearInterval(gameLoop);
                gameOver = true;
                alert('Game Over! Your score: ' + jumpCount);
                resetButton.show(); // Show reset button
            }

            $('.pipe').each(function() {
                var pipe = $(this);
                var pipeLeft = parseInt(pipe.css('left'));

                // Move the pipe to the left
                pipe.css('left', pipeLeft - 6 + 'px');

                // Check for collision
                if (checkCollision(pipe)) {
                    gameOver = true;
                    clearInterval(gameLoop);
                    alert('Game Over! Your score: ' + jumpCount);
                    resetButton.show();
                }

                // Remove pipes that are out of the game container
                if (pipeLeft + pipe.width() < 0) {
                    pipe.remove();
                }
            });

            // Generate new pipes
            if (Date.now() - lastPipeTime > pipeInterval) {
                generatePipes();
                lastPipeTime = Date.now();
            }
        }
    }

    function generatePipes() {
        // Adjust pipe gap and interval based on viewport width
        var pipeGap = window.innerWidth < 768 ? 125 : 200; // Decrease gap for smaller screens
        var pipeInterval = window.innerWidth < 768 ? 1500 : 1500; // Decrease interval for smaller screens

        var windowHeight = gameContainer.height();
        var pipeHeight = Math.floor(Math.random() * (windowHeight - pipeGap)); // Random height for upper pipe

        var pipeTop = $('<div class="pipe pipe-top"></div>').css({
            'left': '100%',
            'height': pipeHeight + 'px'
        });

        var pipeBottom = $('<div class="pipe pipe-bottom"></div>').css({
            'left': '100%',
            'top': (pipeHeight + pipeGap) + 'px',
            'height': (windowHeight - pipeHeight - pipeGap) + 'px'
        });

        gameContainer.append(pipeTop, pipeBottom);

        // Adjust last pipe time based on viewport width
        lastPipeTime = Date.now() + pipeInterval - (window.innerWidth < 768 ? 500 : 0);
    }



    function checkCollision(pipe) {
        var birdLeft = bird.position().left;
        var birdRight = bird.position().left + bird.width();
        var birdTop = bird.position().top;
        var birdBottom = bird.position().top + bird.height();
        var pipeLeft = pipe.position().left;
        var pipeRight = pipe.position().left + pipe.width();
        var pipeTop = pipe.position().top;
        var pipeBottom = pipe.position().top + pipe.height();

        // Check collision with the solid parts of the pipe
        return (
            // Check if the bird's right edge is to the left of the pipe's left edge
            birdRight > pipeLeft &&
                // Check if the bird's left edge is to the right of the pipe's right edge
                birdLeft < pipeRight &&
                // Check if the bird's top edge is below the top of the pipe
                birdTop < pipeTop + pipe.height() &&
                // Check if the bird's bottom edge is above the bottom of the pipe
                birdBottom > pipeTop
            );
    }


    function resetGame() {
        jumpCount = 0;
        counter.text(jumpCount);
        bird.css('top', '50%');
        velocity = 0;
        gameOver = false;
        resetButton.hide(); // Hide reset button
        $('.pipe').remove(); // Remove all pipes
        startGame();
    }

    function startGame() {
        // Generate the first pipe
        generatePipes();

        gameLoop = setInterval(update, 30);
    }

    $(document).on('keydown touchstart', function(e) {
        if (e.type === 'keydown' && e.keyCode === 32 || e.type === 'touchstart') { // Spacebar key or touch event
            flap();
        }
    });

    resetButton.on('click', function() {
        resetGame();
    });

    startGame();
});
