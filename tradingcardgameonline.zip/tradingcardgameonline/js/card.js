$(document).ready(function() {
    console.log('card.js');
    // Wait for all resources to be loaded before resizing cards
    $(window).on('load', function() {
        resizeCards('.card');
    });
});

// Resize cards function
function resizeCards(selector) {
    // Get the tallest height among all elements with the provided selector
    var maxHeight = 0;
    $(selector).each(function() {
        var currentHeight = $(this).height();
        if (currentHeight > maxHeight) {
            maxHeight = currentHeight;
            console.log(maxHeight);
        }
    });

    // Set the height of all elements with the provided selector to the tallest height
    $(selector).height(maxHeight);
}