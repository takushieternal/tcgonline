// Function to handle accepting a trade
function acceptTrade(tradeId) {
    $.post('accept_decline_trade.php', { action: 'accept', trade_id: tradeId }, function(response) {
        alert(response);
        // Reload page after trade status update
        location.reload();
    });
}

// Function to handle declining a trade
function declineTrade(tradeId) {
    $.post('accept_decline_trade.php', { action: 'decline', trade_id: tradeId }, function(response) {
        alert(response);
        // Reload page after trade status update
        location.reload();
    });
}
