$(document).ready(function() {
    console.log('autobattle loaded test');

    var attackId = $('#attackerDetails').attr('data-id');
    var defendId = $('#defenderDetails').attr('data-id');

    // Fetch data from PHP file using $.post
    $.post('GetCardById.php?cardid='+attackId, function(data) {
        // Call function to display cards using received data
        displayCards(data, '.left-cards-container');
    }, 'json')
        .fail(function(jqxhr, textStatus, error) {
            console.error("Error fetching card data:", textStatus, error);
        });


    $.post('GetCardById.php?cardid='+defendId, function(data) {
        // Call function to display cards using received data
        displayCards(data, '.left-cards-container');
    }, 'json')
        .fail(function(jqxhr, textStatus, error) {
            console.error("Error fetching card data:", textStatus, error);
        });

    function displayCards(data, containerSelector) {
        // Loop through each card data
        data.forEach(function(cardData) {
            // Create card element
            var cardId = cardData.id;
            var ownerId = cardData.owner_id;
            var ownerName = cardData.username;
            var isRainbow = 0;

            if(cardData.hp == 200 || cardData.attack_strength == 100){
                isRainbow = 1;
            }

            var card = $('<div data-cardid="'+cardId+'">').addClass('card');

            if(cardData.favorite > 0){
                card.addClass('starred');
            }

            if(cardData.borderRarity == 2){
                card.addClass('gold-border');
            } else if(cardData.borderRarity == 0){
                card.addClass('gray-border');
            } else if(cardData.borderRarity == 3){
                card.addClass('red-border');
            } else if(cardData.borderRarity == 1){
                card.addClass('black-border');
            }

            // Create card header
            var was_purchased = cardData.was_purchased;

            var cardHeader = $('<div>').addClass('card-header').text(cardData.name);

            if(isRainbow > 0){
                cardHeader.addClass('rainbow-text');
            }
            
            if(was_purchased > 0){
                cardHeader.addClass('goldText');
            }

            // Create card body
            var cardBody = $('<div>').addClass('card-body');
            var cardImage = $('<img>').addClass('cardImage').attr('src', cardData.image_url);
            var level = $('<p>').text('Level: ' + cardData.level + '('+cardData.experience+')');
            var hp = $('<p>').html('<i class="fas heart fa-heart"></i> ' + cardData.hp);
            var attackStrength = $('<p>').html('<i class="fas fa-fist-raised"></i> ' + cardData.attack_strength);
            var ability1 = $('<p class="'+cardData.ability1+'">').text(cardData.ability1);
            var ability2 = $('<p class="'+cardData.ability2+'">').text(cardData.ability2);

            if(cardData.level >= 4 && cardData.attack_strength > 75 && cardData.hp >= 120){
                card.addClass('cardGlow');
            }

            // Append card body elements
            cardBody.append(cardImage, level, hp, attackStrength, ability1, ability2);

            // Create card footer
            var cardFooter = $('<div>').addClass('card-footer').html('<a href="https://tradingcardgameonline.com/viewProfile.php?userid='+ownerId+'">' + ownerName +'</a>');

            // Append card header, body, and footer to card
            card.append(cardHeader, cardBody, cardFooter);

            // Append card to the specified container
            $(containerSelector).append(card);
        });
    }
});
