$(document).ready(function() {
    console.log('dashboard.js loaded');

    var user_id = $('#login_info').attr('data-login');

    var location = 'getCollectionById.php?userid='+user_id;

    const urlSearchParams = new URLSearchParams(window.location.search);

    const value = urlSearchParams.get('userid');

    $(document).on('click', '.card', function() {
        var cardId = $(this).attr('data-cardid');
        var ownerId = value;

        // Make a POST request to check if the user is logged in
        $.post('checkLoginStatus.php', function(response) {
            if (response == 1) {
                // Open a dialog box
                $('<div class="dialog-text">Make trade offer?</div>').dialog({
                    modal: true,
                    title: 'User is logged in',
                    width: '50%', // Set the width to 50% of the screen width
                    height: 'auto', // Set height to auto to adjust according to content
                    position: { // Center the dialog box horizontally and vertically
                        my: 'center',
                        at: 'center',
                        of: window
                    },
                    buttons: {
                        Yes: function() {
                            window.location.href = 'tradeMakeOffer.php?ownerId='+ownerId+'&cardId='+cardId;
                        },
                        No: function(){
                            $(this).dialog('close');
                        }
                    }
                });
            } else {
                // User is not logged in
                console.log('');
                // Open a dialog box
                $('<div class="dialog-text">Must be logged in to trade.</div>').dialog({
                    modal: true,
                    title: 'User is not logged in',
                    width: '50%', // Set the width to 50% of the screen width
                    height: 'auto', // Set height to auto to adjust according to content
                    position: { // Center the dialog box horizontally and vertically
                        my: 'center',
                        at: 'center',
                        of: window
                    },
                    buttons: {
                        Login: function() {
                            window.location.href= 'index.php';
                            $(this).dialog('close');
                        },
                        Close: function(){
                            $(this).dialog('close');
                        }
                    }
                });
            }
        }).fail(function(xhr, status, error) {
                // Handle errors
                console.error('Error:', error);
            });
    });

    $(document).on('input','#searchCardName', function(){
        // Get the value typed by the user
        var searchText = $(this).val().toLowerCase();

        // Loop through each card
        $('.card').each(function() {
            // Get the card name and convert it to lowercase
            var cardName = $(this).find('.card-header').text().toLowerCase();

            // Check if the card name contains the search text
            if (cardName.includes(searchText)) {
                // Show the card if it matches the search text
                $(this).show();
            } else {
                // Hide the card if it doesn't match the search text
                $(this).hide();
            }
        });
    });

    //#searchCardName
    $('.content-container').append('<div class="searchCardNameBox"><input type="text" placeholder="Search Cards By Name" class="searchCardNameText" id="searchCardName" /></div>');

// Fetch data from PHP file using $.post
    $.post(location, function(data) {
        // Call function to display cards using received data
        displayCards(data);
    }, 'json')
        .fail(function(jqxhr, textStatus, error) {
            console.error("Error fetching card data:", textStatus, error);
        });

});

// Function to display cards from JSON data
function displayCards(data) {
    // Loop through each card data
    data.forEach(function(cardData) {
        // Create card element
        var cardId = cardData.id;
        var ownerId = cardData.owner_id;
        var creatorId = cardData.creator_id;

        var card = $('<div data-cardownerid="'+ownerId+'" data-cardid="'+cardId+'">').addClass('card');

        var isRainbow = 0;

        if(cardData.hp == 200 || cardData.attack_strength == 100){
            isRainbow = 1;
        }

        if(cardData.favorite > 0){
            card.addClass('starred');
        }

        if(cardData.borderRarity == 2){
            card.addClass('gold-border');
        } else if(cardData.borderRarity == 0){
            card.addClass('gray-border');
        } else if(cardData.borderRarity == 3){
            card.addClass('red-border');
        } else if(cardData.borderRarity == 1){
            card.addClass('black-border');
        }

        // Create card header
        var was_purchased = cardData.was_purchased;
        var cardHeader = $('<div>').addClass('card-header').text(cardData.name);

        if(isRainbow > 0){
            cardHeader.addClass('rainbow-text');
        }

        if(was_purchased > 0){
            cardHeader.addClass('goldText');
        }

        // Create card body
        var cardBody = $('<div>').addClass('card-body');
        var cardImage = $('<div>').html('<img class="cardImage" src="'+cardData.image_url+'" /> ');
        var level = $('<p>').text('Level: ' + cardData.level + '('+cardData.experience+')');
        var hp = $('<p>').html('<i class="fas heart fa-heart"></i> ' + cardData.hp);
        var attackStrength = $('<p>').html('<i class="fas fa-fist-raised"></i> ' + cardData.attack_strength);
        var ability1 = $('<p class="'+cardData.ability1+'">').html(cardData.ability1);
        var ability2 = $('<p class="'+cardData.ability2+'">').html(cardData.ability2);

        if(cardData.level >= 4 && cardData.attack_strength > 75 && cardData.hp >= 120){
            card.addClass('cardGlow');
        }

        // Append card body elements
        cardBody.append(cardImage,level, hp, attackStrength, ability1, ability2);

        // Create card footer
        var cardFooter = $('<div>').addClass('card-footer').html('Generated By <a style="margin-left: 0.15em;" href="https://tradingcardgameonline.com/viewProfile.php?userid='+creatorId+'">' + cardData.signature+'</a>');

        // Append card header, body, and footer to card
        card.append(cardHeader, cardBody, cardFooter);

        // Append card to content container
        $('.content-container').append(card);
    });
}
