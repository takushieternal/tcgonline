$(document).ready(function() {
    // Handle clicking on a card to initiate trade
    $('.card').click(function() {
        var card_id = $(this).data()['cardId']; // Update to 'data-id' to match database column name

        $('#card-id').val(card_id);
    });


});
