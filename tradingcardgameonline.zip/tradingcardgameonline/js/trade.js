$(document).ready(function() {
    // Handle form submission for initiating trades
    $('#trade-form').submit(function(event) {
        event.preventDefault();
        var receiver_id = $('#receiver-id').val();
        var card_id = $('#card-id').val();
        var sender_id = $('#login_info').attr('public_id');

        $.post('initiate_trade.php', { sender_id: sender_id, receiver_id: receiver_id, card_id: card_id }, function(response) {
            alert(response);
            // Reload page after trade initiation
            location.reload();
        });
    });

    // Handle clicking on a card to initiate trade
    $('.card').click(function() {
        var card_id = $(this).data()['cardId']; // Update to 'data-id' to match database column name

        $('#card-id').val(card_id);
    });
});
