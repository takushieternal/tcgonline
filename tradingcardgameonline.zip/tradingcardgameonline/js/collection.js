$(document).ready(function() {
    // Event delegation to handle click on dynamically added cards
    $(document).on('click', '.collectionClass', function() {
        $(this).toggleClass('starred');
        var cardid = $(this).attr('data-cardid');
        console.log(cardid);
        toggleFavorite(cardid);
    });

    function toggleFavorite(cardId) {
        $.post("toggle_favorite.php", { cardId: cardId }, function(data) {
            console.log(data); // Output server response to console
            // You can perform additional actions based on server response if needed
        });
    }

});
