$(document).ready(function() {
    $('.card').click(function() {
        var card_id = $(this).data()['cardId']; // Update to 'data-id' to match database column name

        $('#card-id').val(card_id);


    });

    $(document).on('input','#searchCardName', function(){
        // Get the value typed by the user
        var searchText = $(this).val().toLowerCase();

        // Loop through each card
        $('.card').each(function() {
            // Get the card name and convert it to lowercase
            var cardName = $(this).find('.card-header').text().toLowerCase();

            // Check if the card name contains the search text
            if (cardName.includes(searchText)) {
                // Show the card if it matches the search text
                $(this).show();
            } else {
                // Hide the card if it doesn't match the search text
                $(this).hide();
            }
        });
    });

});