$(document).ready(function() {
    console.log('dashboard.js loaded');

    // Function to continuously scroll the content
    function scrollContent() {
        var containerWidth = $('.scroll-container').width();
        var contentWidth = $('.scroll-content').width();
        var animationSpeed = (containerWidth + contentWidth) * 25; // Adjust speed as needed
        $('.scroll-content').animate({left: -contentWidth}, animationSpeed, 'linear', function() {
            // Reset position when animation completes
            $(this).animate({left: containerWidth}, 0);
            // Call the scrollContent function recursively
            scrollContent();
        });
    }

    // Start the initial animation
    scrollContent();

    // Event delegation to handle dynamically added elements
    $(document).on("click", ".card", function(){
        var $footer = $(this).find('.card-footer');
        var $thumbsUp = $footer.find('.likeStatus');

        // Get the favorited card ID and user ID
        var favorited_card_id = $(this).attr('data-cardid');

//        $('.content-container').attr('data-collection','on');

        if($('.content-container').attr('data-collection') !== 'on'){
        // Make a POST request to favorite_toggle.php
        $.post("favorite_toggle.php", { favorited_card_id: favorited_card_id })
            .done(function(data) {
                // Handle the response if needed
                console.log("Favorite toggled successfully!");
            })
            .fail(function() {
                // Handle errors if any
                console.log("Error toggling favorite.");
            });

        // If thumbs-up icon exists, remove it, else append it
        if ($thumbsUp.length) {
            $thumbsUp.remove();
        } else {
            $footer.prepend('<i class="fas likeStatus fa-heart" style="color:red;"></i>');
        }
        }
    });

    // Flag to prevent multiple simultaneous AJAX requests
    var isLoading = false;

    // Function to debounce scroll events
    function debounce(func, delay) {
        var timeout;
        return function() {
            var context = this;
            var args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                timeout = null;
                func.apply(context, args);
            }, delay);
        };
    }

    // Function to handle scroll events with debounce
    var handleScroll = debounce(function() {
        // Check if loading is already in progress
        if (isLoading) return;

        // Check if the user has scrolled to the bottom of the page
        if (($(window).scrollTop() + $(window).height()) >= ($(document).height() - 100)) {
            // User has scrolled to the bottom of the page
            console.log("Bottom of the page reached!");

            // Retrieve the data-collection attribute value from .content-container element
            var collection = $('.content-container').attr('data-collection');

            // Check if data-collection attribute is not set to 'on' and loading is not in progress
            if(collection !== 'on'){
                // Set loading state to true
                isLoading = true;

                // Get the ID of the last card in the container
                var lastCardId = $('.card:last').attr('data-cardid');

                // Construct the URL for fetching the next set of data
                var location = 'getNext50byid.php?lastid='+ lastCardId;

                // Append the loading div to the container after a short delay
                $('.content-container').append('<div id="loading" class="loadingNotice">Loading Please Wait</div>');

                // Send an AJAX POST request to fetch the next set of data
                $.post(location, function(data) {
                    // Call function to display cards using received data
                    displayCards(data);

                    // Reset the scroll listener after new elements are added
                    $(window).off('scroll').on('scroll', handleScroll);
                }, 'json')
                    .fail(function(jqxhr, textStatus, error) {
                        // Log error if fetching data fails
                        console.error("Error fetching card data:", textStatus, error);
                    })
                    .always(function() {
                        // Set loading state to false when AJAX request is complete
                        isLoading = false;
                    });
            }
        }
    }, 250); // Debounce delay in milliseconds

    // Attach scroll event listener to the window with debounce
    $(window).on('scroll resize', handleScroll);


    $(document).on('click', '.swap-button', function(){
        var cards = $('.content-container .card'); // Select all cards
        $('.content-container').append(cards.get().reverse()); // Reverse the order and append back
    });

    $(document).on('input','#searchCardName', function(){
        // Get the value typed by the user
        var searchText = $(this).val().toLowerCase();

        // Loop through each card
        $('.card').each(function() {
            // Get the card name and convert it to lowercase
            var cardName = $(this).find('.card-header').text().toLowerCase();

            // Check if the card name contains the search text
            if (cardName.includes(searchText)) {
                // Show the card if it matches the search text
                $(this).show();
            } else {
                // Hide the card if it doesn't match the search text
                $(this).hide();
            }
        });
    });

    $('#leaderBoardButton').click(function(){
        console.log('test');
        $('.content-container').empty();
        $('.content-container').append('<div class="collectionNav"><input class="searchCardName" id="searchCardName" type="text" placeholder="Search Card Name" id="collectionSearch" /> </div><button class="swap-button">Reverse Order</button>');

        $.post('leaderBoard.php', function(data) {
            // Call function to display cards using received data

            displayCards(data);
        }, 'json')
            .fail(function(jqxhr, textStatus, error) {
                console.error("Error fetching card data:", textStatus, error);
            });
    });

    $(document).on('change', '#filter-dropdown', function() {
        var selectedRarity = $(this).val();
        if (selectedRarity === 'default') {
            $('.card').show();
        } else {
            $('.card').hide();
            $('.card[border-rarity="' + selectedRarity + '"]').show();
        }
    });

    $("#collectionButton").click(function() {
        // Your code to execute when the element is clicked
        // For example, you can show an alert
        // Check if the user agent contains 'Mobile' or 'Tablet'

        $('.content-container').attr('data-collection','on');
        var isMobileDevice = /Mobile|Tablet/i.test(navigator.userAgent);

        if (isMobileDevice) {
            console.log("User is using a mobile device.");
            // Add your mobile-specific code here
            $('.nav-links').hide();
        } else {
            console.log("User is not using a mobile device.");
            // Add your desktop-specific code here
        }

        $('.content-container').empty();
        $('.navDiv').empty();
        $('.nav-links').hide();

        var filterDropdown = '<select class="filter-dropdown" id="filter-dropdown"><option value="default">Show All</option><option value="0">Common</option><option value="1">Uncommon</option><option value="2">Rare</option><option value="3">Legendary</option></select>';

        $('.navDiv').append('<div class="collectionNav"><div class="copylink" id="copylink">Click To Copy Profile Link</div></div>');
        $('.navDiv').append('<div class="collectionNav"><input class="searchCardName" id="searchCardName" type="text" placeholder="Search Card Name" id="collectionSearch" />'+filterDropdown+'<button class="swap-button">Swap Card Order</button></div>');        $.post('getCollection.php', function(data) {
            // Call function to display cards using received data
            displayCards(data,'collectionClass');
        }, 'json')
            .fail(function(jqxhr, textStatus, error) {
                console.error("Error fetching card data:", textStatus, error);
            });
    });

    // Event delegation for dynamically added buttons
    $("html").on("click", "#copylink", function(){
        var userid = $('#dashboardbody').attr('data-userid');
        var textToCopy = "https://tradingcardgameonline.com/viewProfile.php?userid="+userid;

        // Create a temporary input element
        var tempInput = $("<input>");

        // Assign the text to copy to the input element's value
        tempInput.val(textToCopy);

        // Append the input element to the body
        $("body").append(tempInput);

        // Select the text within the input element
        tempInput.select();

        // Copy the selected text to clipboard
        document.execCommand("copy");

        // Remove the temporary input element
        tempInput.remove();

        // Provide some visual feedback or notification
        alert("Text copied to clipboard");
    });

    const urlSearchParams = new URLSearchParams(window.location.search);

    const value = urlSearchParams.get('cardMax');

    const value2 = urlSearchParams.get('notEnoughDust');

    if(value == 'yes'){
        alert('Max Cards Generated(5). Please, wait until a full day has passed.');
    }

    if(value2 == 'true'){
        alert('Not enough premium dust.');
    }

    // Fetch data from PHP file using $.post
    $.post('getLatestHundredCards.php', function(data) {
        // Call function to display cards using received data
        displayCards(data);
    }, 'json')
        .fail(function(jqxhr, textStatus, error) {
            console.error("Error fetching card data:", textStatus, error);
        });

});

// Function to display cards from JSON data
function displayCards(data, isCollection ) {

    isCollection = typeof isCollection !== 'undefined' ? isCollection : '';

    // Loop through each card data
    data.forEach(function(cardData) {
        // Create card element
        var cardId = cardData.id;
        var card = $('<div data-cardid="'+cardId+'">').addClass('card').addClass(isCollection);

        card.attr('border-rarity',cardData.borderRarity);

        var ownerId = cardData.owner_id;
        var ownerName = cardData.username;
        var like_count = cardData.like_count;
        var user_favorite = cardData.user_favorite;
        var displayHeart = '';
        var isRainbow = 0;

        if(cardData.hp == 200 || cardData.attack_strength == 100){
            isRainbow = 1;
        }

        if(user_favorite > 0){
            displayHeart = '<i class="fas likeStatus fa-heart" style="color:red;"></i>';
        }

        if(cardData.favorite > 0){
            card.addClass('starred');
        }

        if(cardData.borderRarity == 2){
            card.addClass('gold-border');
        } else if(cardData.borderRarity == 0){
            card.addClass('gray-border');
        } else if(cardData.borderRarity == 3){
            card.addClass('red-border');
        } else if(cardData.borderRarity == 1){
            card.addClass('black-border');
        }

        // Create card header
        var was_purchased = cardData.was_purchased;
        var cardHeader = $('<div>').addClass('card-header').text(cardData.name);

        if(isRainbow > 0){
            cardHeader.addClass('rainbow-text');
        }


        if(was_purchased > 0){
            cardHeader.addClass('goldText');
        }



        // Create card body
        var cardBody = $('<div>').addClass('card-body');
        var cardImage = $('<div>').html('<img class="cardImage" src="'+cardData.image_url+'" /> ');
        var level = $('<p>').text('Level: ' + cardData.level + '('+cardData.experience+')');
        var hp = $('<p>').html('<i class="fas heart fa-heart"></i> ' + cardData.hp);
        var attackStrength = $('<p>').html('<i class="fas fa-fist-raised"></i> ' + cardData.attack_strength);
        var ability1 = $('<p class="'+cardData.ability1+'">').text(cardData.ability1);
        var ability2 = $('<p class="'+cardData.ability2+'">').text(cardData.ability2);

        if(cardData.level >= 4 && cardData.attack_strength > 75 && cardData.hp >= 120){
            card.addClass('cardGlow');
        }


        // Append card body elements
        cardBody.append(cardImage,level, hp, attackStrength, ability1, ability2);

        // Create card footer
        var cardFooter = $('<div>').addClass('card-footer').html(displayHeart+like_count+' | <a href="https://tradingcardgameonline.com/viewProfile.php?userid='+ownerId+'">' + ownerName+'#'+ownerId+'</a> ');

        // Append card header, body, and footer to card
        card.append(cardHeader, cardBody, cardFooter);

        // Append card to content container
        $('.content-container').append(card);
    });

    if ($('#loading').length) {
        // Element with id 'loading' exists
        $('#loading').remove();
    }



}


// Resize cards function
function resizeCards(selector) {
    // Get the tallest height among all elements with the provided selector
    var maxHeight = 0;
    $(selector).each(function() {
        var currentHeight = $(this).height();
        if (currentHeight > maxHeight) {
            maxHeight = currentHeight;
            console.log(maxHeight);
        }
    });

    // Set the height of all elements with the provided selector to the tallest height
    $(selector).height(maxHeight);
}