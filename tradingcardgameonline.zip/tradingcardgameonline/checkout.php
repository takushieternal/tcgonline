<?php
// Include Stripe PHP library
require_once 'php/stripe-php-13.10.0/init.php';

// Set your secret key
\Stripe\Stripe::setApiKey('sk_test_51Neih5FMIcKhWBHak6Lb2ZWy31Bov4L1zTme2m0eUNErQF3H0faCOHvFjEFNKRm5iEMb5jn0eSlyq748CrylHbBL00qYOGTIUy');

// Get the amount from the form
$amount = $_POST['stripe_amount'];

// Create a PaymentIntent
try {
    $paymentIntent = \Stripe\PaymentIntent::create([
        'amount' => $amount,
        'currency' => 'usd',
        'payment_method_types' => ['card'],
    ]);

    // Return a success message
    echo "Payment successful. PaymentIntent ID: " . $paymentIntent->id;
} catch (Exception $e) {
    // Return an error message
    echo "Error: " . $e->getMessage();
}
?>
