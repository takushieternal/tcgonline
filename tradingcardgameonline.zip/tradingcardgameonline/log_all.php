<?php

// Function to get visitor IP address
function getIPAddress() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

// Function to parse browser information from user agent string
function getBrowser($user_agent) {
    $browser = "Unknown";
    if (preg_match('/Edge/i', $user_agent)) {
        $browser = "Edge";
    } elseif (preg_match('/Firefox/i', $user_agent)) {
        $browser = "Firefox";
    } elseif (preg_match('/Chrome/i', $user_agent)) {
        $browser = "Chrome";
    } elseif (preg_match('/Safari/i', $user_agent) && !preg_match('/Chrome/i', $user_agent)) {
        $browser = "Safari";
    }
    return $browser;
}

function getOS($user_agent) {
    $os_platform = "Unknown";

    if (preg_match('/windows|win32/i', $user_agent)) {
        $os_platform = "Windows";
    } elseif (preg_match('/macintosh|mac os x/i', $user_agent)) {
        $os_platform = "Mac OS X";
    } elseif (preg_match('/linux/i', $user_agent)) {
        $os_platform = "Linux";
    } elseif (preg_match('/iphone/i', $user_agent)) {
        $os_platform = "iPhone";
    } elseif (preg_match('/ipod/i', $user_agent)) {
        $os_platform = "iPod";
    } elseif (preg_match('/ipad/i', $user_agent)) {
        $os_platform = "iPad";
    } elseif (preg_match('/android/i', $user_agent)) {
        $os_platform = "Android";
    } elseif (preg_match('/blackberry/i', $user_agent)) {
        $os_platform = "BlackBerry";
    } elseif (preg_match('/webos/i', $user_agent)) {
        $os_platform = "WebOS";
    }

    return $os_platform;
}


// Get visitor IP address
$ip = getIPAddress();

// Get visitor location based on IP using freegeoip.app
$locationData = json_decode(file_get_contents("https://freegeoip.app/json/$ip"), true);

// Extract location data
$country = isset($locationData['country_name']) ? $locationData['country_name'] : null;
$city = isset($locationData['city']) ? $locationData['city'] : null;

// Get browser data
$user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : null;
$browser = getBrowser($user_agent);

// Get operating system data
$os = getOS($user_agent);

// Get page name
$page_name = basename($_SERVER['PHP_SELF']); // Gets the file name of the current script

// Insert visitor data into the VisitorLogs table
if(isset($_SESSION['login_info'][0]['id'])){
    $username = $_SESSION['login_info'][0]['user_name'];
    $userId = $_SESSION['login_info'][0]['id'];
} else{
    $username = 'Not logged in';
    $userId = null;
}
$sql = "INSERT INTO VisitorLogs (visit_time, ip_address, country, city, browser, os, page_name,user_name,user_id) VALUES (NOW(), ?, ?, ?, ?, ?, ?,?,?)";
$params = [$ip, $country, $city, $browser, $os, $page_name, $username,$userId];

// Execute the query
executeNonQuery($sql, $params);
?>
