<?php

// Replace 'YOUR_API_KEY' with your actual API key
$apiKey = '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';

$prompts = array(
    "Do battle here",
    "get owner_id here"
);

$responses = getChatGPTResponses($prompts);

print_r($responses);

function getChatGPTResponses($prompts) {
    global $apiKey;

    $url = 'https://api.openai.com/v1/completions';

    $responses = array();

    foreach ($prompts as $prompt) {
        $data = array(
            'model' => 'gpt-3.5-turbo-0125', // Change to the desired model if needed
            'prompt' => $prompt,
            'temperature' => 0.7,
            'max_tokens' => 150
        );

        $headers = array(
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey
        );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        curl_close($ch);

        $responseData = json_decode($response, true);

        if (isset($responseData['choices'][0]['text'])) {
            $responses[] = $responseData['choices'][0]['text'];
        } else {
            $responses[] = "Error: No response from ChatGPT";
        }
    }

    return $responses;
}

