<?php
/**
 * Created by Bryant Frankford
 * nathanielfrankford@gmail.com
 * Date: 2/3/24
 * Time: 11:00 PM
 * To change this template use File | Settings | File Templates.
 */
if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

if(!isset($_SESSION['login_info'])){
    header("Location: index.php");
    die();
}

// Include your database connection file
include 'db.php';

$ownerId = $_SESSION['login_info'][0]['id'];

$dustAmount = 5;

function fetchCardById($card_id) {
    global $dbo;

    // Prepare the SQL statement with a parameterized query
    $sql = "SELECT * FROM trading_cards WHERE id = :card_id";
    $params = array(':card_id' => $card_id);

    // Execute the parameterized SELECT query
    $result = executeSelectQuery($sql, $params);

    // Return the fetched card (if any)
    return !empty($result) ? $result[0] : null;
}

// Example usage: Fetch a card with card_id = 1
$card_id = $_POST['card_id'];
$card = fetchCardById($card_id);

// Output the fetched card information
if ($card) {
    $rarity = $card['border_rarity'];

    if($rarity <1){
        $dustAmount = 5;
    } elseif($rarity == 1){
        $dustAmount = 10;
    } elseif($rarity == 2){
        $dustAmount = 15;
    } elseif($rarity == 3){
        $dustAmount = 20;
    }

    // Add other card attributes as needed
} else {
    echo "No card found with the specified ID.";
}

// Initialize the boolean variable to false
$hasResults = false;

// Check if $_POST['card_id'] is set and not empty
if(isset($_POST['card_id'])) {
    // Sanitize the input to prevent SQL injection
    $card_id = intval($_POST['card_id']);

    // Prepare the SQL query to fetch trading card details along with the trade request information
    $query = "SELECT tc.*, tr.*
              FROM trading_cards tc
              LEFT JOIN trade_requests tr ON (tc.id = tr.desired_card_id OR tc.id = tr.card_id)
              WHERE tr.acceptedTrade = 0 and tc.id = :card_id";

    try {
        // Prepare the statement
        $statement = $dbo->prepare($query);

        // Bind the parameter
        $statement->bindParam(':card_id', $card_id, PDO::PARAM_INT);

        // Execute the statement
        $statement->execute();

        // Fetch all rows as an associative array
        $result = $statement->fetchAll(PDO::FETCH_ASSOC);

        // Check if rows were returned
        if ($result) {
            $hasResults = false;
            // Output the result (you can further process this result as needed)
//            echo json_encode($result);
        } else {
            $hasResults = true;
//            echo "No matching records found.";
        }
    } catch(PDOException $e) {
        // Handle errors
        echo "Error: " . $e->getMessage();
    }
} else {
    // Handle case where $_POST['card_id'] is not set or empty
    echo "No card ID provided.";
}

// Check if the card_id is provided through POST request
if(isset($_POST['card_id']) && $hasResults) {
    // Sanitize the input to prevent SQL injection
    $card_id = $_POST['card_id'];

    try {
        // Prepare and execute the update query for users table
        $update_users_query = "UPDATE users 
                               INNER JOIN trading_cards ON users.id = trading_cards.owner_id
                               SET users.dust = users.dust + ?
                               WHERE trading_cards.id = ? and trading_cards.owner_id = ?";
        $update_users_statement = $dbo->prepare($update_users_query);
        $update_users_statement->execute(array($dustAmount ,$card_id, $ownerId));

        // Prepare and execute the update query for trading_cards table
        $update_cards_query = "UPDATE trading_cards 
                               SET isDust = 1 ,
                                   date_dust_generated = CURRENT_TIMESTAMP
                               WHERE id = ? and owner_id = ?";

        $loginId = $_SESSION['login_info'][0]['id'];
        $update_cards_statement = $dbo->prepare($update_cards_query);
        $update_cards_statement->execute(array($card_id, $loginId));

        header('Location: dust.php');
    } catch (PDOException $e) {
        echo "Error updating database: " . $e->getMessage();
    }
} else {
    echo "No card_id provided. Or card is involved with a trade.";
}
?>
