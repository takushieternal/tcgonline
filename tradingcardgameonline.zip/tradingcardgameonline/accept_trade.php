<?php
// Start the session
session_start();

// Include the database connection file
include 'db.php';

// Check if the receiver ID is provided in the session and trade ID is provided in the query string
if (!isset($_SESSION['login_info']) || !isset($_GET['trade_id'])) {
    header("Location: index.php");
    exit();
}

// Get the receiver ID from the session
$receiverId = $_SESSION['login_info'][0]['id'];

// Get the trade ID from the query string and sanitize it
$tradeId = filter_input(INPUT_GET, 'trade_id', FILTER_SANITIZE_NUMBER_INT);

if($_GET['action'] == 'accept'){
    $action = 1;
} else{
    $action = null;
}

// Verify if the receiver ID matches the logged-in user's ID
if ($receiverId) {
    try {
        // Retrieve the trade request details using prepared statements
        $sql = "SELECT receiver_id, desired_card_id, secondOwnerId, card_id FROM trade_requests WHERE id = :trade_id";
        $stmt = $dbo->prepare($sql);
        $stmt->bindParam(':trade_id', $tradeId, PDO::PARAM_INT);
        $stmt->execute();
        $tradeDetails = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($tradeDetails) {
            $desiredCardId = $tradeDetails['desired_card_id'];
            $secondOwnerId = $tradeDetails['secondOwnerId'];
            $cardId = $tradeDetails['card_id'];

            if($_GET['action'] == 'accept'){

            // Update the owner_id for the desired card
            $sqlUpdateReceiver = "UPDATE trading_cards SET owner_id = :receiver_id WHERE id = :desired_card_id";
            $stmtUpdateReceiver = $dbo->prepare($sqlUpdateReceiver);
            $stmtUpdateReceiver->bindParam(':receiver_id', $receiverId, PDO::PARAM_INT);
            $stmtUpdateReceiver->bindParam(':desired_card_id', $cardId, PDO::PARAM_INT);
            $stmtUpdateReceiver->execute();

            // Update the owner_id for the offered card
            $sqlUpdateSecondOwner = "UPDATE trading_cards SET owner_id = :secondOwnerId WHERE id = :card_id";
            $stmtUpdateSecondOwner = $dbo->prepare($sqlUpdateSecondOwner);
            $stmtUpdateSecondOwner->bindParam(':secondOwnerId', $secondOwnerId, PDO::PARAM_INT);
            $stmtUpdateSecondOwner->bindParam(':card_id', $desiredCardId, PDO::PARAM_INT);
            $stmtUpdateSecondOwner->execute();
            }

//            echo "Owner IDs updated successfully.";
        } else {
            echo "Error: Trade request not found.";
        }

        try {
            // Update the acceptedTrade column based on the action
            $sqlUpdateTrade = "UPDATE trade_requests SET acceptedTrade = :action WHERE (desired_card_id = :trade_id or card_id = :card_id or desired_card_id = :card_id or card_id = :trade_id)";
            $stmtUpdateTrade = $dbo->prepare($sqlUpdateTrade);
            $stmtUpdateTrade->bindParam(':action', $action, PDO::PARAM_STR);
            $stmtUpdateTrade->bindParam(':trade_id', $desiredCardId, PDO::PARAM_INT);
            $stmtUpdateTrade->bindParam(':card_id', $cardId, PDO::PARAM_INT);
            $stmtUpdateTrade->execute();

            if($stmtUpdateTrade->rowCount() > 0) {
//                echo "Trade request $action successfully.";
                header('Location: tradesView.php');
            } else {
                echo 'Error updating trade request. (Card probably is not available anymore) <a href="dashboard.php">Return home.</a>';
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Error: Receiver ID not provided.";
}
?>
