<?php

namespace Stripe\Exception\OAuth;

/**
 * The base interface for all Stripe OAuth exceptions.
 */
interface ExceptionInterface extends \Stripe\Exception\ExceptionInterface
{
}
