<?php
//if($_SERVER["HTTPS"] != "on")
//{
//    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
//    exit();
//}
/**
 * Created by Bryant N Frankford
 * nathanielfrankford@gmail.com
 */
session_start();
session_destroy();
header('Location: index.php');
die();