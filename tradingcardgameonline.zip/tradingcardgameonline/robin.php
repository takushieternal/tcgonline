<?php
/**
 * Created by JetBrains PhpStorm.
 * User: natha
 * Date: 4/7/24
 * Time: 2:41 PM
 * To change this template use File | Settings | File Templates.
 */


for ($i = 1; $i <= 10; $i++) {
    echo $i . " "; // Output the current number followed by a space
}

?>
<html>
<head>
    <title>Never Gonna Give You Up</title>
</head>
<body>
</body>
</html>