<?php
/**
 * Created by JetBrains PhpStorm.
 * User: natha
 * Date: 2/5/24
 * Time: 1:49 PM
 * To change this template use File | Settings | File Templates.
 */
include 'db.php'; // Include the database connection script

// Check if trade_id, user_id, and action are provided via POST request
if (isset($_POST['trade_id'], $_POST['user_id'], $_POST['action'])) {
    $trade_id = $_POST['trade_id'];
    $user_id = $_POST['user_id'];
    $action = $_POST['action'];

    // Fetch trade details from the database
    $sql = "SELECT * FROM trades WHERE id = ?";
    $trade = executeSelectQuery($sql, array($trade_id));

    if (!empty($trade)) {
        $trade = $trade[0];

        // Check if the user is involved in the trade
        if ($user_id == $trade['sender_id'] || $user_id == $trade['receiver_id']) {
            // Update trade status based on user action
            $status = ($action == 'accept') ? 'accepted' : 'declined';
            $sql = "UPDATE trades SET status = ? WHERE id = ?";
            $success = executeNonQuery($sql, array($status, $trade_id));

            // Return success or failure response
            if ($success) {
                echo 'Trade request ' . $action . 'ed successfully.';
            } else {
                echo 'Error: Failed to process trade request.';
            }
        } else {
            echo 'Error: User is not involved in the trade.';
        }
    } else {
        echo 'Error: Trade not found.';
    }
} else {
    // Handle error if required parameters are not provided
    echo 'Error: Missing parameters.';
}
?>
