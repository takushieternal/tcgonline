<?php
// Include database connection
session_start();

include_once "db.php";

// Check if the request is sent via POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the data from the POST request
    $favorited_card_id = $_POST['favorited_card_id'];
    $user_id = $_SESSION['login_info'][0]['id'];

    // Check if the favorite entry already exists
    $query = "SELECT * FROM favorited_cards WHERE favorited_card_id = :favorited_card_id AND user_id = :user_id";
    $params = array(':favorited_card_id' => $favorited_card_id, ':user_id' => $user_id);
    $result = executeSelectQuery($query, $params);

    if (count($result) > 0) {
        // If the entry exists, toggle the status
        $toggle_status = $result[0]['toggle_status'] == 1 ? 0 : 1;
        $query = "UPDATE favorited_cards SET toggle_status = :toggle_status WHERE favorited_card_id = :favorited_card_id AND user_id = :user_id";
        $params = array(':toggle_status' => $toggle_status, ':favorited_card_id' => $favorited_card_id, ':user_id' => $user_id);
        executeNonQuery($query, $params);
    } else {
        // If the entry doesn't exist, insert a new one with toggle status 1
        $toggle_status = 1;
        $query = "INSERT INTO favorited_cards (toggle_status, favorited_card_id, user_id) VALUES (:toggle_status, :favorited_card_id, :user_id)";
        $params = array(':toggle_status' => $toggle_status, ':favorited_card_id' => $favorited_card_id, ':user_id' => $user_id);
        executeNonQuery($query, $params);
    }
}
?>
