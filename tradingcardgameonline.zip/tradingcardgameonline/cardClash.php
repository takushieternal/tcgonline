<?php
/**
 * Created by Bryant Frankford
 * nathanielfrankford@gmail.com
 * Date: 2/3/24
 * Time: 11:00 PM
 * To change this template use File | Settings | File Templates.
 */
if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start(); // Start the session
include 'db.php'; // Include the database connection script
if(!isset($_SESSION['login_info'])){
    header("Location: index.php");
    die();
}
// Fetch cards associated with the user
if (isset($_SESSION['login_info'][0]['id'])) {
    $user_id = $_SESSION['login_info'][0]['id'];
//    $sql = "SELECT u.user_name, tc.* FROM trading_cards tc join users u on tc.owner_id = u.id WHERE owner_id = ? AND isDust = 0 ORDER BY experience desc, favorite desc, border_rarity desc, id DESC";
    $sql =<<<EOQ
SELECT u.user_name, tc.*
FROM trading_cards tc
JOIN users u ON tc.owner_id = u.id
WHERE owner_id = ?
AND isDust = 0
AND (
    SELECT COUNT(*)
    FROM card_usage cu
    WHERE cu.card_id = tc.id
    AND cu.battle_timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
) <= 4
ORDER BY tc.level desc, tc.experience desc, tc.id DESC;
EOQ;

    $cards = executeSelectQuery($sql, array($user_id));
} else {
    // Redirect to login page or handle session error
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head id="login_info" public_id=<?php echo $_SESSION['login_info'][0]['id'] ?>>
    <meta charset="UTF-8">
    <title>Card Clash</title>

    <link rel="icon" type="image/png" href="images/favicon.png" />

    <link rel="stylesheet" href="css/card.css">
    <link rel="stylesheet" href="css/trade.css">
    <link rel="stylesheet" href="css/cardClash.css">
    <link rel="stylesheet" href="css/fontawesome-free-6.5.1-web/css/all.css">
    <script src="css/fontawesome-free-6.5.1-web/js/fontawesome.js"></script>

</head>
<body>
<div class="topNavGiftCards">
    <form id="trade-form" method="post" action="autobattle.php">
<!--        <label for="receiver-id">Giftable Cards - Receiver ID:</label>-->
<!--        <input type="text" id="receiver-id" name="receiver_id" required>-->
        <label for="card-id" class="cardId">Card ID:</label>
        <input type="text" class="cardIdInput" id="card-id" name="card_id" required>
        <button class="homeButton" type="submit">Card Clash</button>
        <a class="homeButton" href="dashboard.php">Return home.</a>
    </form>
</div>

<div id="card-container">
    <!-- Cards will be dynamically loaded here -->
    <div class="searchNav">
        <input id="searchCardName" class="searchCardName" type="text" placeholder="Search Card Name" />
    </div>
    <?php foreach ($cards as $card): ?>
    <div class="<?php
            if($card['level'] >= 4 && $card['attack_strength'] > 75 && $card['hp'] >= 120){
                $glowclass = 'cardGlow';
            } else{
                $glowclass = '';
            }

            if($card['attack_strength'] == 100 || $card['hp'] == 200){
                $rainbowclass = ' rainbow-text';
            } else {
                $rainbowclass = '';
            }

        if ($card['border_rarity'] == 0) {
            $cardBorder = 'gray-border';
        } elseif ($card['border_rarity'] == 1) {
            $cardBorder = 'black-border';
        } elseif($card['border_rarity'] == 3){
            $cardBorder = 'red-border';
        } elseif ($card['border_rarity'] == 2) {
            $cardBorder = 'gold-border';
        }
        echo $cardBorder;
        ?> card <?php echo $glowclass; ?>" data-rarity="<?php
        echo $card['border_rarity'];
        ?>"
         data-card-id="<?php echo $card['id']; ?>">
        <div class="card-header <?php if($card['was_purchased'] > 0)echo 'goldText'; echo $rainbowclass; ?>"><h3><?php echo $card['name']; ?></h3></div>
    <div class="card-body">
        <?php echo '<img class="cardImage" src="'.$card['image_url'].'" />'; ?>
        <p>Level: <?php echo $card['level'].'('.$card['experience'].')'; ?></p>

        <p><i class="fas heart fa-heart"></i>  <?php echo $card['hp']; ?></p>

        <p><i class="fas fa-fist-raised"></i> <?php echo $card['attack_strength']; ?></p>
        <?php if (!empty($card['ability1'])): ?>
        <p class="<?php echo $card['ability1']; ?>"><?php echo $card['ability1']; ?></p>
        <?php endif; ?>
        <?php if (!empty($card['ability2'])): ?>
        <p class="<?php echo $card['ability2']; ?>"><?php echo $card['ability2']; ?></p>
            </div>
                <div class="card-footer">
                    <?php echo $card['user_name']; ?>
                </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>
<script src="js/jquery.js"></script>
<script src="js/cardClash.js"></script>
<script src="js/card.js"></script>

<script>
    // Get the height of the fixed navigation bar
    const navHeightEm = document.querySelector('.topNavGiftCards').offsetHeight / parseFloat(getComputedStyle(document.documentElement).fontSize);

    // Set the margin-top of the content below to prevent it from being hidden behind the fixed header
    document.getElementById('card-container').style.marginTop = navHeightEm + 'em';
</script>

</body>
</html>
