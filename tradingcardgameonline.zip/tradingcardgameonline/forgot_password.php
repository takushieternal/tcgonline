<?php
session_start();
require_once('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Check if email exists in the database
    $user = executeSelectQuery("SELECT * FROM users WHERE email = ?", array($email));

    if ($user) {
        // Generate a unique token
        $token = bin2hex(random_bytes(32));

        // Store the token in the database
        executeNonQuery("UPDATE users SET reset_token = ? WHERE email = ?", array($token, $email));

        // Send an email with the password reset link
        $reset_link = "https://tradingcardgameonline.com/reset_password.php?token=$token";
        // Send email logic here
        // Example: mail($email, "Password Reset", "Click the following link to reset your password: $reset_link");
        $to = $email;
        $subject = "Change Password";
        $message = "A password change has been requested. Click the following link to reset your password: ".$reset_link;
        // Set up the "no-reply" email address
        $from = "noreply@example.com";
        $headers = "From: $from\r\n";
        $headers .= "Reply-To: $from\r\n";
        $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

// Send email
        if (mail($to, $subject, $message, $headers)) {
//            echo "Email sent successfully.";
        } else {
            echo "Email sending failed.";
        }

        // Redirect user to a confirmation page
        header("Location: password_reset_confirmation.php");
        exit();
    } else {
        $error_message = "Email address not found.";
    }
}
?>
<html>
<head>
    <title>Forgot Password</title>
    <link rel="icon" type="image/png" href="images/favicon.png" />

</head>
<body>
<h2>Forgot Password</h2>
<form method="post" action="">
    <input type="email" name="email" placeholder="Enter your email" required>
    <input type="submit" value="Reset Password">
</form>
<p><a href="index.php">Return home.</a></p>
<?php if(isset($error_message)) { echo $error_message; } ?>
</body>
</html>
