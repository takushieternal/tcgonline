<?php
// Include the database connection script
include 'db.php';

session_start();

// Check if the user is logged in
if (!isset($_SESSION['login_info'])) {
    header("Location: index.php");
    die();
}

// Check if the necessary parameters are provided via POST request
if (isset($_POST['action'], $_POST['trade_id'])) {
    $action = $_POST['action'];
    $trade_id = $_POST['trade_id'];

    // Retrieve trade details
    $sql_trade_details = "SELECT sender_id, receiver_id, card_id FROM trades WHERE id = ?";
    $trade_details = executeSelectQuery($sql_trade_details, array($trade_id));

    // Get the current user ID
    $current_user_id = $_SESSION['login_info'][0]['id'];

    // Update the status of the trade based on the action and user role
    if ($action === 'accept') {
        // If the current user is the recipient, update the trade status and card owner
        if ($current_user_id == $trade_details[0]['receiver_id']) {
            // Update the trade status to accepted
            $status = 'accepted';
            $sql_trade = "UPDATE trades SET status = ? WHERE id = ?";
            $success_trade = executeNonQuery($sql_trade, array($status, $trade_id));

            if ($success_trade) {
                // Check if the current user is the recipient of the trade
                if ($current_user_id == $trade_details[0]['receiver_id']) {
                    // Update the owner of the card to the recipient
                    $sql_update_owner = "UPDATE trading_cards SET owner_id = ? WHERE id = ?";
                    $success_update_owner = executeNonQuery($sql_update_owner, array($trade_details[0]['receiver_id'], $trade_details[0]['card_id']));

                    if ($success_update_owner) {
                        echo 'Trade request accepted successfully.';
                    } else {
                        echo 'Error: Failed to update card owner.';
                    }
                } else {
                    echo 'Error: You are not the recipient of this trade.';
                }
            } else {
                echo 'Error: Failed to update trade status.';
            }
        } else {
            echo 'Error: Only the recipient can accept this trade.';
        }
    } elseif ($action === 'decline') {
        // If the current user is the sender, allow them to decline the trade
        if ($current_user_id == $trade_details[0]['sender_id']) {
            $status = 'declined';
            $sql = "UPDATE trades SET status = ? WHERE id = ?";
            $success = executeNonQuery($sql, array($status, $trade_id));

            if ($success) {
                echo 'Trade request declined successfully.';
            } else {
                echo 'Error: Failed to decline trade request.';
            }
        } else {
            echo 'Error: Only the sender can decline this trade.';
        }
    } else {
        echo 'Error: Invalid action.';
    }
} else {
    // Handle error if required parameters are not provided
    echo 'Error: Missing parameters.';
}
?>
