<?php
// Stability.ai API endpoint URL
$url = 'https://grpc.stability.ai:443/your-endpoint'; // Replace 'your-endpoint' with the actual endpoint

// API key
$apiKey = 'sk-aFdLIEog22VNfJ3p69EHtyzpscg3LLGHEqHD1JKnGVus14c3'; // Your Stability.ai API key

// Set up headers
$headers = array(
    'Authorization: Bearer ' . $apiKey,
);

// Set up options for GET request
$options = array(
    'http' => array(
        'method' => 'GET',
        'header' => implode("\r\n", $headers),
    ),
);

// Create context for GET request
$context = stream_context_create($options);

// Make GET request and capture response
$response = file_get_contents($url, false, $context);

// Output response
var_dump($response);
?>
