<?php
// Your Stability AI API key
$apiKey = 'sk-aFdLIEog22VNfJ3p69EHtyzpscg3LLGHEqHD1JKnGVus14c3';

// API endpoint URL
$apiUrl = 'https://api.stability.ai/v1/user/balance';

// Initialize cURL session
$curl = curl_init();

// Set cURL options
curl_setopt_array($curl, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json',
    ],
]);

// Execute the request
$response = curl_exec($curl);

// Check for errors
if ($response === false) {
    echo 'Error: ' . curl_error($curl);
} else {
    // Decode the JSON response
    $responseData = json_decode($response, true);

    // Check if the response contains credits information
    if (isset($responseData['credits'])) {
        // Extract and display the credits amount
        $credits = floor($responseData['credits']);
        if ($credits < 1000) {
            echo 'Unable to power AI generation (Too many concurrent requests). Please try again later. <a href="dashboard.php">Return Home</a>';

            $to = 'nathanielfrankford@gmail.com';
            $subject = 'Out of credits on stability.ai';
            $message = 'https://platform.stability.ai/ to buy more.';

            $from = "noreply@tradingcardgameonline.com";
            $headers = "From: $from\r\n";
            $headers .= "Reply-To: $from\r\n";
            $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

// Send email
            if (mail($to, $subject, $message, $headers)) {
//            echo "Email sent successfully.";
            } else {
                echo "Email sending failed.";
            }

            exit();
        }

    } else {
        echo 'Unable to power AI generation. Please try again later. <a href="dashboard.php">Return Home</a>';
        $to = 'nathanielfrankford@gmail.com';
        $subject = 'Out of credits on stability.ai';
        $message = 'https://platform.stability.ai/ to buy more.';

        $from = "noreply@tradingcardgameonline.com";
        $headers = "From: $from\r\n";
        $headers .= "Reply-To: $from\r\n";
        $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

// Send email
        if (mail($to, $subject, $message, $headers)) {
//            echo "Email sent successfully.";
        } else {
            echo "Email sending failed.";
        }
    }
}

// Close cURL session
curl_close($curl);
?>
