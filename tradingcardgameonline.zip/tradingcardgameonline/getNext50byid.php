<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['login_info'])) {
    header("Location: index.php");
    die();
}

// Check for HTTPS
if ($_SERVER["HTTPS"] != "on") {
    // Redirect to HTTPS
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

// Database connection parameters
$servername = "localhost";
$username = "ijteuute_bryant";
$password = "f7qfxs[pEMy$";
$dbname = "ijteuute_tradingcardgameonline";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize lastid
$lastid = isset($_GET['lastid']) ? intval($_GET['lastid']) : 0;

// Prepare SQL query
$sql =<<<EOQ
SELECT
    users.user_name,
    trading_cards.*,
    COUNT(favorited_cards.id) AS like_count,
    MAX(CASE WHEN favorited_cards.user_id = ? THEN favorited_cards.toggle_status ELSE 0 END) AS user_favorite
FROM
    trading_cards
LEFT JOIN
    favorited_cards ON trading_cards.id = favorited_cards.favorited_card_id AND favorited_cards.toggle_status = 1
JOIN
    users ON users.id = trading_cards.owner_id
WHERE
    trading_cards.isDust = 0
AND
    trading_cards.id < ?
GROUP BY
    trading_cards.id
ORDER BY
    trading_cards.id DESC
LIMIT 10;
EOQ;

// Prepare statement
$stmt = $conn->prepare($sql);

// Check if preparation succeeded
if (!$stmt) {
    die("Preparation failed: " . $conn->error);
}

// Bind parameters
$stmt->bind_param("ii", $_SESSION['login_info'][0]['id'], $lastid);

// Execute statement
if (!$stmt->execute()) {
    die("Execution failed: " . $stmt->error);
}

// Get result
$result = $stmt->get_result();

// Initialize an array to store card data
$cardData = array();

// Fetch and store card data
while ($row = $result->fetch_assoc()) {
    $cardData[] = array(
        "id" => $row["id"],
        "like_count" => $row["like_count"],
        "user_favorite" => $row["user_favorite"],
        "username" => $row["user_name"],
        "name" => $row["name"],
        "level" => $row["level"],
        "hp" => $row["hp"],
        "attack_strength" => $row["attack_strength"],
        "ability1" => $row["ability1"],
        "ability2" => $row["ability2"],
        "signature" => $row["username"],
        "borderRarity" => $row["border_rarity"],
        "image_url" => $row["image_url"],
        "was_purchased" => $row["was_purchased"],
        "owner_id" => $row["owner_id"],
        "experience" => $row["experience"]
    );
}

// Close statement
$stmt->close();

// Close MySQL connection
$conn->close();

// Convert the card data array to JSON format
$jsonData = json_encode($cardData);

// Output the JSON data
echo $jsonData;
?>
