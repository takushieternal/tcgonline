<?php
/**
 * Created by Bryant Frankford
 * nathanielfrankford@gmail.com
 * Date: 2/3/24
 * Time: 11:00 PM
 * To change this template use File | Settings | File Templates.
 */
if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

if(!isset($_SESSION['login_info'])){
    header("Location: index.php");
    die();
}

// Establish connection to MySQL database
$servername = "localhost";
$username = "ijteuute_bryant";
$password = "f7qfxs[pEMy$";
$dbname = "ijteuute_tradingcardgameonline";

/// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind the parameterized query
//$sql = 'SELECT u.user_name, tc.* FROM trading_cards tc join users u on tc.owner_id = u.id WHERE owner_id = ? and isDust = 0 ORDER BY favorite desc, border_rarity desc,experience desc, id ASC';

$sql =<<<EOQ
SELECT
    u.user_name,
    tc.*,
    (SELECT COUNT(*) FROM favorited_cards fc WHERE fc.favorited_card_id = tc.id AND fc.toggle_status = 1) AS total_likes
FROM
    trading_cards tc
JOIN
    users u ON tc.owner_id = u.id
WHERE
    tc.owner_id = ?
    AND tc.isDust = 0
ORDER BY
    tc.favorite desc,
    tc.border_rarity DESC,
    tc.experience DESC,
    total_likes DESC,
    tc.id DESC

EOQ;


$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $owner_id); // Assuming owner_id is a string, use "i" for integer if it's an integer

// Set the value of the parameter
$owner_id = $_SESSION['login_info'][0]['id']; // Replace "your_owner_id" with the actual value

// Execute the query
$stmt->execute();

// Get the result set
$result = $stmt->get_result();

// Initialize an array to store card data
$cardData = array();

// Check if there are results
if ($result->num_rows > 0) {
    // Loop through each row and add card data to the array
    while ($row = $result->fetch_assoc()) {
        $cardData[] = array(
            "id" => $row["id"],
            "like_count" => $row["total_likes"],
            "username" => $row["user_name"],
            "name" => $row["name"],
            "level" => $row["level"],
            "hp" => $row["hp"],
            "attack_strength" => $row["attack_strength"],
            "ability1" => $row["ability1"],
            "ability2" => $row["ability2"],
            "signature" => $row["username"],
            "borderRarity" => $row["border_rarity"],
            "image_url" => $row["image_url"],
            "image_url" => $row["image_url"],
            "was_purchased" => $row["was_purchased"],
            "favorite" => $row["favorite"],
            "experience" => $row["experience"],
            "owner_id" => $row["owner_id"]
        );
    }
}

// Close prepared statement
$stmt->close();

// Close MySQL connection
$conn->close();

// Convert the card data array to JSON format
$jsonData = json_encode($cardData);

// Output the JSON data
echo $jsonData;
?>