<?php
// API endpoint and API key
$api_endpoint = 'https://api.stability.ai/v2alpha/generation/image-to-video';
$api_key = 'sk-aFdLIEog22VNfJ3p69EHtyzpscg3LLGHEqHD1JKnGVus14c3';

// Command prompt
$command_prompt = 'Your command prompt here'; // Replace this with your actual command prompt

// Construct API request URL with query parameters
$api_url = $api_endpoint . '?api_key=' . urlencode($api_key) . '&prompt=' . urlencode($command_prompt);

// Make API request to generate the video
$response = file_get_contents($api_url);

// Check if API request was successful
if ($response === false) {
    $error = error_get_last();
    echo "Error: API request failed - " . $error['message'];
    exit;
}

// Decode JSON response
$response_data = json_decode($response, true);

// Check for errors in the API response
if (isset($response_data['error'])) {
    echo "Error: " . $response_data['error'];
    exit;
}

// Retrieve the URL of the generated video
$video_url = $response_data['video_url'];

// Optionally, you can download the video file
$video_filename = 'generated_video.mp4';
file_put_contents($video_filename, file_get_contents($video_url));

// Output the path to the generated video
echo "Generated video file: $video_filename";
?>
