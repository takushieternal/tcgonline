<?php
/**
 * Created by Bryant N Frankford
 * nathanielfrankford@gmail.com
 */

//No SSL Certificate
if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

if(isset($_SESSION['login_info'])){
    header("Location: dashboard.php");
}


include 'db.php';

include 'log_all.php';


try {
    // Prepare the SQL query to count the total number of rows in the trading_cards table
    $query = "SELECT COUNT(*) AS total_rows FROM trading_cards";

    // Prepare the statement
    $statement = $dbo->prepare($query);

    // Execute the statement
    $statement->execute();

    // Fetch the result as an associative array
    $result = $statement->fetch(PDO::FETCH_ASSOC);

    // Output the total number of rows
    $totalRows = $result['total_rows'];
} catch(PDOException $e) {
    // Handle errors
    echo "Error: " . $e->getMessage();
}

?>
<html>
<head>
    <title>Log In</title>
    <script src="js/jquery.js"></script>
    <script src="js/index.js"></script>
<!--    <script src="js/dashboard.js"></script>-->
    <script src="https://www.google.com/recaptcha/enterprise.js?render=6LcvWGwpAAAAAE9o5Z4sk8CVJgtwKoXupmjdf_NU"></script>
    <link rel="stylesheet" href="css/index.css?ver=<?php echo rand(0,100); ?>"/>
    <link rel="stylesheet" href="css/card.css?ver=<?php echo rand(0,100); ?>"/>

    <link rel="stylesheet" href="css/fontawesome-free-6.5.1-web/css/all.css">
    <script src="css/fontawesome-free-6.5.1-web/js/fontawesome.js"></script>

    <link rel="icon" type="image/png" href="images/favicon.png" />

</head>
<body>
<div class="mainContainer">
<!--    <div class="cardContainer content-container">-->
<!---->
<!--    </div>-->
    <div class="formDiv">
        <div class="counterBox suggested3d-filled-gradient">
<!--            <h2>--><?php //echo $totalRows; ?><!-- Cards Generated!</h2>-->
            Trading Card Game Online<br />Open Beta
        </div>
        <div class="logoBox">
            <form action="verifyLogin.php" class="loginForm" method="post">
                <input name="email" class="emailInput" autofocus type="email" placeholder="email" autofocus required/>
                <input name="password" class="passwordInput" type="password" placeholder="***********" required/>
                <input type="submit" class="submitButton" value="Login"/>
            </form><br />
            <div class="bottomNav">
                <div class="registerLink"><a href="register.php">Register</a></div>
                <div class="forgotPasswordLink"><a href="forgot_password.php">Forgot Password</a></div><br />
                <div class="copyright">© Copyright 2024 - Frankford v0.1.0</div>
            </div>
        </div>

    </div>
</div>
</body>
</html>