<?php
session_start();
require_once('db.php');

?>
<html>
    <head>
        <title>Password Reset</title>
        <link rel="icon" type="image/png" href="images/favicon.png" />

    </head>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are set
    if (isset($_POST['token']) && isset($_POST['new_password']) && isset($_POST['confirm_password'])) {
        $token = $_POST['token'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        // Validate the new password
        if ($new_password !== $confirm_password) {
            echo "Passwords do not match.";
            exit;
        }

        // Check if the token exists in the database
        $user = executeSelectQuery("SELECT * FROM users WHERE reset_token = ?", array($token));

        if ($user) {
            // Update the password for the user
            // Hash the new password (using md5 - not recommended for production use)
            $hashed_password = md5($new_password);
            executeNonQuery("UPDATE users SET password = ?, reset_token = NULL WHERE reset_token = ?", array($hashed_password, $token));
            echo "Password reset successfully.";
            echo '<a href="index.php">Return home</a>';
        } else {
            // Invalid token
            echo "Invalid token.";
            echo '<a href="index.php">Return home</a>';
        }
    } else {
        // Missing required fields
        echo "Missing required fields.";
        echo '<a href="index.php">Return home</a>';
    }
} else {
    // Invalid request method
    echo "Invalid request method.";
    echo '<a href="index.php">Return home</a>';
}
?>

