<?php
session_start();
require_once('db.php');

// Check if the token is provided in the URL
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['token'])) {
    $token = $_GET['token'];

    // Check if the token exists in the database
    $user = executeSelectQuery("SELECT * FROM users WHERE reset_token = ?", array($token));

    if ($user) {
        // Valid token, allow user to reset password
        // Display password reset form
        ?>
    <html>
    <head>
        <title>Reset Password</title>
        <link rel="icon" type="image/png" href="images/favicon.png" />

    </head>
    <body>
    <h2>Reset Your Password</h2>
    <form method="post" action="process_reset_password.php">
        <input type="hidden" name="token" value="<?php echo $token; ?>">
        <input type="password" name="new_password" placeholder="Enter new password" required>
        <input type="password" name="confirm_password" placeholder="Confirm new password" required>
        <input type="submit" value="Reset Password">
    </form>
    </body>
    </html>
    <?php
    } else {
        // Invalid token
        echo "Invalid token.";
    }
} else {
    // Token not provided in the URL
    echo "Token not provided.";
}
?>
