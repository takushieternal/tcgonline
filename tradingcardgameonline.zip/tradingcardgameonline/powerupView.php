<?php
/**
 * Created by Bryant Frankford
 * nathanielfrankford@gmail.com
 * Date: 2/3/24
 * Time: 11:00 PM
 * To change this template use File | Settings | File Templates.
 */

include 'db.php';

if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

session_start();

if(!isset($_SESSION['login_info'])){
    header("Location: index.php");
    die();
}

$firstOwnerId = $_GET['ownerId'];
$firstCardId = $_GET['cardId'];
$secondOwnerId = $_SESSION['login_info'][0]['id'];

// Fetch cards associated with the user
if (isset($_SESSION['login_info'][0]['id'])) {
    $user_id = $_SESSION['login_info'][0]['id'];
    $sql = "SELECT * FROM trading_cards WHERE owner_id = ? and isDust = 0 and level < 5 ORDER BY favorite desc, border_rarity desc, id ASC";
    $cards = executeSelectQuery($sql, array($user_id));
} else {
    // Redirect to login page or handle session error
    header("Location: login.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head id="login_info" public_id=<?php echo $_SESSION['login_info'][0]['id'] ?>>
    <meta charset="UTF-8">
    <title>Power-Up Cards</title>

    <link rel="icon" type="image/png" href="images/favicon.png" />

    <script src="js/jquery.js"></script>

    <link rel="stylesheet" href="css/card.css">
    <link rel="stylesheet" href="css/trade.css">
    <link rel="stylesheet" href="css/powerupView.css">
    <link rel="stylesheet" href="css/tradeMakeOffer.css">
    <link rel="stylesheet" href="css/fontawesome-free-6.5.1-web/css/all.css">
    <script src="css/fontawesome-free-6.5.1-web/js/fontawesome.js"></script>

</head>
<body>
<div class="topNavGiftCards">
    <form id="trade-form" method="post" action="powerupCard.php">
<!--        <div class="controls"><label class="receiverId" for="receiver-id">Receiver ID:</label><input readonly="readonly" class="receiverIdInput" value="--><?php //echo $firstOwnerId; ?><!--" type="text" id="receiver-id" name="receiver_id" required></div>-->
<!--        <div class="controls"><label for="desired-card-id" class="originalCardId">Desired Card ID:</label><input type="text" class="cardIdInput" readonly="readonly" value="--><?php //echo $firstCardId; ?><!--" id="desired-card-id" name="desired-card_id" required></div>-->
        <div class="controls"><label for="card-id" class="cardId">Power-Up Card ID:</label><input type="text" class="cardIdInput" id="card-id" name="cardId" required></div>
        <div class="controls"><button class="homeButton" type="submit">Level Up(10Đ)</button><a class="homeButton" href="dashboard.php">Return home.</a></div>
    </form>
</div>

<div id="card-container">
    <div class="explanation">
        For 10 dust per level you can level up your cards to a maximum level of 5. For each level gained the card will grow by 5 points in strength and HP, however, both are capped at 100 and 200 respectively.
    </div>
    <div class="searchNav">
        <input id="searchCardName" class="searchCardName" type="text" placeholder="Search Card Name" />
    </div>
    <!-- Cards will be dynamically loaded here -->
    <?php foreach ($cards as $card): ?>
    <div class="<?php
        if($card['level'] >= 4 && $card['attack_strength'] > 75 && $card['hp'] >= 120){
            $glowclass = 'cardGlow';
        } else{
            $glowclass = '';
        }

        if($card['attack_strength'] == 100 || $card['hp'] == 200){
            $rainbowclass = ' rainbow-text';
        } else {
            $rainbowclass = '';
        }

        if ($card['border_rarity'] == 0) {
            $cardBorder = 'gray-border';
        } elseif ($card['border_rarity'] == 1) {
            $cardBorder = 'black-border';
        } elseif($card['border_rarity'] == 3){
            $cardBorder = 'red-border';
        } elseif ($card['border_rarity'] == 2) {
            $cardBorder = 'gold-border';
        }
        echo $cardBorder;
        ?> card <?php echo $glowclass; ?>" data-rarity="<?php
        echo $card['border_rarity'];
        ?>"
         data-card-id="<?php echo $card['id']; ?>">
        <div class="card-header <?php if($card['was_purchased'] > 0){echo 'goldText';} echo $rainbowclass; ?>"><h3><?php echo $card['name']; ?></h3></div>
    <div class="card-body">
        <?php echo '<img class="cardImage" src="'.$card['image_url'].'" />'; ?>
        <p>Level: <?php echo $card['level'].'('.$card['experience'].')'; ?></p>

        <p><i class="fas heart fa-heart"></i> <?php echo $card['hp']; ?></p>

        <p><i class="fas fa-fist-raised"></i> <?php echo $card['attack_strength']; ?></p>
        <?php if (!empty($card['ability1'])): ?>
        <p class="<?php echo $card['ability1']; ?>"><?php echo $card['ability1']; ?></p>
        <?php endif; ?>
        <?php if (!empty($card['ability2'])): ?>
        <p class="<?php echo $card['ability2']; ?>"><?php echo $card['ability2']; ?></p>
            </div>
                <div class="card-footer">
                    Generated By<br /><?php echo $card['username']; ?>
                </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>
<script src="js/jquery.js"></script>
<script src="js/powerupView.js"></script>

<script>
    // Get the height of the fixed navigation bar
    const navHeightEm = document.querySelector('.topNavGiftCards').offsetHeight / parseFloat(getComputedStyle(document.documentElement).fontSize);

    // Set the margin-top of the content below to prevent it from being hidden behind the fixed header
    document.getElementById('card-container').style.marginTop = navHeightEm + 'em';
</script>

</body>
</html>
