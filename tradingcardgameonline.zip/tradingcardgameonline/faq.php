<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - Trading Card Game</title>
    <link rel="stylesheet" type="text/css" href="js/datatables/datatables.css">
    <link rel="stylesheet" href="css/faq.css">

    <link rel="icon" type="image/png" href="images/favicon.png" />

</head>
<body>

<h1>Frequently Asked Questions</h1>

<table id="faq-table" class="display">
    <thead>
    <tr>
        <th>Question</th>
        <th>Answer</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>What determines a card's rarity?</td>
        <td>Ultimately a combination of stat rolls, abilities, and dust level can effect the "rarity" of a card.</td>
    </tr>
    <tr>
        <td>How do I play the this game?</td>
        <td>Currently the way to play is by clicking on the "Card Clash" link on the dashboard. This will take you to your collection where you will select a card to do battle with a random other card you don't own! Collect experience on each card to rank up in the leaderboard.</td>
    </tr>
    <tr>
        <td>Can I trade my cards?</td>
        <td>Yes! To trade cards simply find the profile of the card you wish to own(by clicking the name on the bottom of the card).When there click the card you wish to trade for and select make offer. Then choose a card from your collection to offer in exchange for your card.</td>
    </tr>
    <tr>
        <td>Is this game free to play?</td>
        <td>YES! Players only need one card to play and you earn five free cards per day just by logging in. Support the site by buying gold bordered</td>
    </tr>
    <tr>
        <td>What is dust and how do I get it?</td>
        <td>Dust is obtained by "dusting" cards you own. Use this dust to generate more cards or revive dusted cards (20 dust). Premium dust is obtained by purchasing it with real life money. Spend premium dust on cards with gold-text in the title.</td>
    </tr>
    <tr>
        <td>What are dust values of the cards?</td>
        <td>Common(grey-border): 5 dust, Uncommon(blue-border): 10 dust, Rare(gold-border): 15 dust, Legendary(red-border): 20 dust</td>
    </tr>
    <tr>
        <td>Why is my card blurry?</td>
        <td>Very rarely there are "misprint" cards.</td>
    </tr>
    <tr>
        <td>Why is my card glowing?</td>
        <td>That card is extra strong! It had great stats!</td>
    </tr>
    <tr>
        <td>How to get dust?</td>
        <td>Get dust in a few ways. First make sure to clash with your cards in "Card Clash"! Wins net you 3 dust, even on defense! One by dusting cards you don't want. If someone goes to the dustyard and revives a card you dusted you will receive 5 dust.</td>
    </tr>
    <tr>
        <td>Where's the super secret mini game?</td>
        <td><a href="flappyCard.php">Right here!</a></td>
    </tr>
    <tr>
        <td>Why do I need to verify my email address to generate cards?</td>
        <td>Security and to cut down on spam.</td>
    </tr>
    <tr>
        <td>How does powering up cards work?</td>
        <td>For 10 dust per level you can level up your cards to a maximum level of 5. For each level gained the card will grow by 5 points in strength and HP, however, both are capped at 100 and 200 respectively.</td>
    </tr>
    <!-- Add more questions and answers as needed -->
    </tbody>
</table>
<div>
    <a class="homeButton" href="dashboard.php">Return Home</a>
</div>

<script src="js/jquery.js"></script>
<script src="js/datatables/datatables.js"></script>
<script>
    $(document).ready(function() {
        $('#faq-table').DataTable();
    });
</script>

</body>
</html>
