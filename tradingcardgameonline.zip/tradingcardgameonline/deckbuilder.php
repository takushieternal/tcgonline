<?php
/**
 * Created by JetBrains PhpStorm.
 * User: natha
 * Date: 2/8/24
 * Time: 10:45 PM
 * To change this template use File | Settings | File Templates.
 */

session_start();

$user_id = $_SESSION['login_info'][0]['id'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deck Builder</title>
    <!-- Include jQuery -->
    <link rel="stylesheet" href="css/card.css">
    <link rel="stylesheet" href="css/deckbuilder.css">

    <script src="js/jquery.js"></script>

    <link rel="icon" type="image/png" href="images/favicon.png" />
    <!-- Include deckbuilder.js -->
    <script src="js/deckbuilder.js"></script>
</head>
<body id="login_info" data-login="<?php echo $user_id; ?>">
<div class="container">
    <div class="menu">
        <ul>
            <li>Menu Item 1</li>
            <li>Menu Item 2</li>
            <li>Menu Item 3</li>
            <!-- Add more menu items as needed -->
        </ul>
    </div>
    <div id="cardContainer" class="content"></div>
</div>
</body>
</html>
