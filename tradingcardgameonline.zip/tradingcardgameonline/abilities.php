<?php

// Function to apply abilities during battle
function applyAbilities(&$attacker, &$defender, $abilityOrder)
{
    foreach ($abilityOrder as $ability) {
        // Check if the attacker has the current ability
        if ($attacker[$ability]) {
            // Apply the ability's effect for the attacker
            switch ($attacker[$ability]) {
                // Add cases for each ability and their effects
                // Example:
                // case 'Lightning':
                //     $damage = rand(10, 20);
                //     $defender['hp'] -= $damage;
                //     echo "<p class='ability-effect'>{$attacker['name']} used Lightning! {$defender['name']} takes {$damage} damage.</p>";
                //     break;
                // Add similar cases for other abilities
                case 'Lightning':
                    $damage = rand(10, 250);
                    $defender['hp'] -= $damage;
                    echo "<p class='ability-effect'>{$attacker['name']} used Lightning! {$defender['name']} takes {$damage} damage.</p>";
                    break;
                case 'Fireball':
                    $damage = rand(50, 75);
                    $defender['hp'] -= $damage;
                    echo "<p class='ability-effect'>{$attacker['name']} used Fireball! {$defender['name']} takes {$damage} damage.</p>";
                    break;
                case 'Healing':
                    $heal = rand(85, 200);
                    $attacker['hp'] += $heal;
                    echo "<p class='ability-effect'>{$attacker['name']} used Healing! Restored {$heal} HP.</p>";
                    break;
                case 'Shadow':
                    // Decrease the defender's attack strength
                    $defender['attack_strength'] *= 0.8;
                    echo "<p class='ability-effect'>{$attacker['name']} used Shadow! {$defender['name']}'s attack strength decreased.</p>";
                    break;
                case 'Ice':
                    $freezeChance = rand(1, 10);
                    if ($freezeChance <= 5) {
                        // Freeze the defender for one turn
                        echo "<p class='ability-effect'>{$attacker['name']} used Ice! {$defender['name']} is frozen and cannot attack.</p>";
                    }
                    break;
                case 'Earthquake':
                    // Deal damage and reduce defender's attack strength
                    $damage = rand(15, 85);
                    $defender['hp'] -= $damage;
                    $defender['attack_strength'] *= 0.75;
                    echo "<p class='ability-effect'>{$attacker['name']} used Earthquake! {$defender['name']} takes {$damage} damage and has reduced attack strength.</p>";
                    break;
                case 'Wind':
                    // Increase attacker's attack strength
                    $attacker['attack_strength'] *= 1.35;
                    echo "<p class='ability-effect'>{$attacker['name']} used Wind! {$attacker['name']}'s attack strength increased.</p>";
                    break;
                case 'Poison':
                    // Poison the defender, causing damage over time
                    $damageOverTime = rand(25, 80);
                    $defender['poison_damage'] = $damageOverTime;
                    echo "<p class='ability-effect'>{$attacker['name']} used Poison! {$defender['name']} is poisoned and takes <span class=\"damage\">{$damageOverTime}</span> poison damage.</p>";
                    break;
                case 'Teleportation':
                    // Chance to dodge next attack
                    $teleportChance = rand(1, 10);
                    if ($teleportChance <= 3) {
                        // Set a flag indicating that the attacker dodged the next attack
                        $attacker['dodged_attack'] = true;
                        echo "<p class='ability-effect'>{$attacker['name']} used Teleportation! Dodged the next attack.</p>";
                    }
                    break;
                case 'Barrier':
                    // Increase attacker's defense
                    $attacker['defense'] = 3;
                    $attacker['dodged_attack'] = true;

                    echo "<p class='ability-effect'>{$attacker['name']} used Barrier! Stopped the next attack.</p>";
                    break;
                default:
                    // No valid ability found
                    break;
            }
            // Remove the used ability from the attacker
            $attacker[$ability] = '';
            break; // Exit the loop after the first ability is applied
        } else if ($defender[$ability]) {
            // Apply the ability's effect for the defender
            switch ($defender[$ability]) {
                // Add cases for each defender ability and their effects
                // Example:
                // case 'Lightning':
                //     $damage = rand(10, 20);
                //     $attacker['hp'] -= $damage;
                //     echo "<p class='ability-effect'>{$defender['name']} used Lightning! {$attacker['name']} takes {$damage} damage.</p>";
                //     break;
                // Add similar cases for other defender abilities
                case 'Lightning':
                    $damage = rand(10, 250);
                    $attacker['hp'] -= $damage;
                    echo "<p class='ability-effect'>{$attacker['name']} used Lightning! {$defender['name']} takes {$damage} damage.</p>";
                    break;
                case 'Fireball':
                    $damage = rand(50, 75);
                    $attacker['hp'] -= $damage;
                    echo "<p class='ability-effect'>{$attacker['name']} used Fireball! {$defender['name']} takes {$damage} damage.</p>";
                    break;
                case 'Healing':
                    $heal = rand(85, 200);
                    $defender['hp'] += $heal;
                    echo "<p class='ability-effect'>{$attacker['name']} used Healing! Restored {$heal} HP.</p>";
                    break;
                case 'Shadow':
                    // Decrease the defender's attack strength
                    $attacker['attack_strength'] *= 0.8;
                    echo "<p class='ability-effect'>{$attacker['name']} used Shadow! {$defender['name']}'s attack strength decreased.</p>";
                    break;
                case 'Ice':
                    $freezeChance = rand(1, 10);
                    if ($freezeChance <= 5) {
                        // Freeze the defender for one turn
                        echo "<p class='ability-effect'>{$attacker['name']} used Ice! {$defender['name']} is frozen and cannot attack.</p>";
                    }
                    break;
                case 'Earthquake':
                    // Deal damage and reduce defender's attack strength
                    $damage = rand(15, 85);
                    $attacker['hp'] -= $damage;
                    $attacker['attack_strength'] *= 0.75;
                    echo "<p class='ability-effect'>{$attacker['name']} used Earthquake! {$defender['name']} takes {$damage} damage and has reduced attack strength.</p>";
                    break;
                case 'Wind':
                    // Increase attacker's attack strength
                    $defender['attack_strength'] *= 1.2;
                    echo "<p class='ability-effect'>{$attacker['name']} used Wind! {$attacker['name']}'s attack strength increased.</p>";
                    break;
                case 'Poison':
                    // Poison the defender, causing damage over time
                    $damageOverTime = rand(25, 80);
                    $attacker['poison_damage'] = $damageOverTime;
                    echo "<p class='ability-effect'>{$attacker['name']} used Poison! {$defender['name']} is poisoned and takes {$damageOverTime} damage per turn.</p>";
                    break;
                case 'Teleportation':
                    // Chance to dodge next attack
                    $teleportChance = rand(1, 10);
                    if ($teleportChance <= 3) {
                        echo "<p class='ability-effect'>{$attacker['name']} used Teleportation! Dodged the next attack.</p>";
                        $attacker['dodged_attack'] = true; // Set flag to indicate that the attacker dodged the next attack
                    }
                    break;
                case 'Barrier':
                    // Increase attacker's defense
                    $defender['defense'] = 3;
                    $attacker['dodged_attack'] = true;
                    echo "<p class='ability-effect'>{$attacker['name']} used Barrier! {$attacker['name']}'s defense increased.</p>";
                    break;
                default:
                    // No valid ability found
                    break;
            }
            // Remove the used ability from the defender
            $defender[$ability] = '';
            break; // Exit the loop after the first ability is applied
        }
    }
}

// Function to apply abilities during battle

?>
