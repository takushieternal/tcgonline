<?php
/**
 * Created by Bryant Frankford
 * nathanielfrankford@gmail.com
 * Date: 2/3/24
 * Time: 11:00 PM
 * To change this template use File | Settings | File Templates.
 */
if($_SERVER["HTTPS"] != "on")
{
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

if(!isset($_SESSION['login_info'])){
    header("Location: index.php");
    die();
}

// Define the getUsername function
function getUsername($userId, $dbo) {
    // Query the database to fetch the username associated with the given user ID
    $sql = "SELECT user_name FROM users WHERE id = ?";
    $stmt = $dbo->prepare($sql);
    $stmt->execute([$userId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if a username was found
    if ($result) {

        return $result['user_name']; // Return the fetched username
    } else {
        return 'Unknown User'; // Return a default message if no username is found
    }
}
