<?php
// Start the session to get the user ID
session_start();

// Include the db.php file
include 'db.php';

// Function to update user and trading card
function updateUserAndTradingCard($cardId) {
    global $dbo;

    // Check if user ID is set in the session
    if (!isset($_SESSION['login_info'][0]['id'])) {
        echo "User ID not found in session.";
        return;
    }

    $userId = $_SESSION['login_info'][0]['id'];

    // Begin the transaction
    $dbo->beginTransaction();

    try {
        // Check if the user has at least 10 dust
        $checkDustStmt = $dbo->prepare("SELECT dust FROM users WHERE id = ?");
        $checkDustStmt->execute([$userId]);
        $userData = $checkDustStmt->fetch(PDO::FETCH_ASSOC);

        // Check if the user has at least 10 dust
        if ($userData['dust'] >= 10) {
            // Check if the card's level is 4 or less
            $checkCardStmt = $dbo->prepare("SELECT id, level, hp, attack_strength FROM trading_cards WHERE id = ? and owner_id = ? AND level <= 4");
            $checkCardStmt->execute([$cardId,$userId]);
            $cardData = $checkCardStmt->fetch(PDO::FETCH_ASSOC);

            // If a card with level 4 or less is found, update both user and card
            if ($cardData) {
                // Update dust in the users table
                $updateUserStmt = $dbo->prepare("UPDATE users SET dust = dust - 10 WHERE id = ?");
                $updateUserStmt->execute([$userId]);

                // Update card in the trading_cards table
                $updateCardStmt = $dbo->prepare("UPDATE trading_cards SET level = level + 1, hp = LEAST(hp + 5, 200), attack_strength = LEAST(attack_strength + 5, 100) WHERE id = ?");
                $updateCardStmt->execute([$cardData['id']]);

                // Commit the transaction
                $dbo->commit();
//                echo "User and trading card updated successfully!";
            } else {
                echo "<h1>No card with level 4 or less found.</h1>";
            }
        } else {
            echo "<h1>User does not have at least 10 dust.</h1>";
        }
    } catch (PDOException $e) {
        // Rollback the transaction on error
        $dbo->rollback();
        echo "Error: " . $e->getMessage();
    }
}

$cardId = $_POST['cardId'];

// Call the function to update user and trading card
updateUserAndTradingCard($cardId);
header('Location: powerupView.php');
?>
